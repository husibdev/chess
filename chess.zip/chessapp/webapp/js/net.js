import { tg } from "./util.js";
const listeners = {};
let ws = null, retry = 0, closed = false, status = "off", initStr = "", lang = "en";
const queue = [];
export const net = {
  on(type, fn) { (listeners[type] = listeners[type] || []).push(fn); },
  emit(type, data) { (listeners[type] || []).forEach((f) => f(data)); },
  get status() { return status; },
  init() {
    const dev = new URLSearchParams(location.search).get("dev");
    initStr = (tg && tg.initData) || (dev ? "dev:" + (parseInt(dev, 10) || 1) + ":" + (new URLSearchParams(location.search).get("name") || "Dev" + dev) : "");
    return initStr;
  },
  setLang(l) { lang = l; },
  connect() {
    closed = false;
    const proto = location.protocol === "https:" ? "wss:" : "ws:";
    ws = new WebSocket(proto + "//" + location.host + "/ws");
    ws.onopen = () => ws.send(JSON.stringify({ t: "hello", init: initStr, lang }));
    ws.onmessage = (e) => {
      let m; try { m = JSON.parse(e.data); } catch (x) { return; }
      if (m.t === "hello_ok") { status = "on"; retry = 0; while (queue.length) ws.send(queue.shift()); }
      if (m.t === "hello_err") { closed = true; status = "off"; }
      net.emit(m.t, m); net.emit("*", m);
    };
    ws.onclose = () => {
      if (status === "on") net.emit("offline");
      status = "off";
      if (closed) return;
      setTimeout(() => net.connect(), Math.min(5000, 800 + retry++ * 700));
    };
    ws.onerror = () => {};
  },
  reconnectNow() { if (ws && ws.readyState === 1) return; closed = false; retry = 0; net.connect(); },
  send(obj) {
    const s = JSON.stringify(obj);
    if (ws && ws.readyState === 1 && status === "on") ws.send(s);
    else if (obj.t !== "move") queue.push(s);
  },
  async rest(path, opts = {}) {
    const r = await fetch(path, { ...opts, headers: { "X-Init-Data": initStr, ...(opts.headers || {}) } });
    if (!r.ok) throw new Error(String(r.status));
    return r.json();
  },
};
