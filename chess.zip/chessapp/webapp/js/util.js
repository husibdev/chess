import { t } from "./i18n.js";
export const tg = window.Telegram && window.Telegram.WebApp ? window.Telegram.WebApp : null;

export function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  for (const k in attrs || {}) {
    const v = attrs[k];
    if (v == null || v === false) continue;
    if (k === "class") el.className = v;
    else if (k === "html") el.innerHTML = v;
    else if (k.startsWith("on")) el.addEventListener(k.slice(2), v);
    else if (k === "style" && typeof v === "object") Object.assign(el.style, v);
    else el.setAttribute(k, v === true ? "" : v);
  }
  for (const c of kids.flat()) if (c != null && c !== false) el.append(c.nodeType ? c : document.createTextNode(c));
  return el;
}
export const $ = (s, r = document) => r.querySelector(s);
export const haptic = {
  tap() { try { tg && tg.HapticFeedback.impactOccurred("light"); } catch (e) {} },
  ok() { try { tg && tg.HapticFeedback.notificationOccurred("success"); } catch (e) {} },
  err() { try { tg && tg.HapticFeedback.notificationOccurred("error"); } catch (e) {} },
  warn() { try { tg && tg.HapticFeedback.notificationOccurred("warning"); } catch (e) {} },
};
export function fmtClock(ms) {
  ms = Math.max(0, ms);
  if (ms < 10000) { const s = ms / 1000; return "0:" + s.toFixed(1).padStart(4, "0"); }
  const s = Math.ceil(ms / 1000), m = Math.floor(s / 60), r = s % 60;
  if (m >= 60) return Math.floor(m / 60) + ":" + String(m % 60).padStart(2, "0") + ":" + String(r).padStart(2, "0");
  return m + ":" + String(r).padStart(2, "0");
}
export function fmtDur(sec) {
  sec = Math.max(0, Math.floor(sec));
  const d = Math.floor(sec / 86400), hh = Math.floor((sec % 86400) / 3600), m = Math.floor((sec % 3600) / 60);
  if (d) return d + "d " + hh + "h";
  if (hh) return hh + ":" + String(m).padStart(2, "0") + "h";
  return m + ":" + String(sec % 60).padStart(2, "0");
}
export function tcLabel(tc) { return tc.base ? (tc.base / 60) + "+" + tc.inc : "∞"; }
const COLORS = ["#5B6CFF", "#E4577A", "#18A999", "#E08A1E", "#8E5BD9", "#2E9BD6", "#C9553D"];
export function avatar(u, cls = "") {
  const el = h("div", { class: "av " + cls + (u && u.champ ? " champ" : "") });
  if (u && u.bot) { el.textContent = "🤖"; el.style.background = "#3a3f6e"; return el; }
  if (u && u.photo) el.style.backgroundImage = `url("${u.photo.replace(/"/g, "")}")`;
  else { el.textContent = ((u && u.name) || "?").trim().charAt(0).toUpperCase(); el.style.background = COLORS[(u ? u.id : 0) % COLORS.length]; }
  return el;
}
const STAR = '<svg class="star" viewBox="0 0 24 24"><path d="M12 2l2.9 6.6 7.1.6-5.4 4.7 1.7 7-6.3-3.8-6.3 3.8 1.7-7L2 9.2l7.1-.6z"/></svg>';
export function nameEl(u) {
  const c = u && u.champ ? " champ" + (u.champ === 1 ? " r1" : "") : "";
  const el = h("span", { class: "nm" + c });
  if (u && u.champ) el.insertAdjacentHTML("beforeend", STAR);
  el.append(h("span", { class: "t" }, (u && u.name) || "?"));
  if (u && u.bot) el.append(h("span", { class: "bot-tag" }, t("lv_" + (u.level || "normal"))));
  return el;
}
export function toast(msg, ms = 2400) {
  const el = h("div", { class: "toast" }, msg);
  $("#toasts").append(el);
  setTimeout(() => el.remove(), ms);
}
export function sheet(content, { center = false, onClose } = {}) {
  const scrim = h("div", { class: "scrim" + (center ? " center" : "") });
  const box = h("div", { class: center ? "dialog" : "sheet" }, content);
  scrim.append(box);
  const close = () => { scrim.remove(); onClose && onClose(); };
  scrim.addEventListener("pointerdown", (e) => { if (e.target === scrim && !center) close(); });
  $("#layer").append(scrim);
  return { close, el: box, scrim };
}
export function confirmBox(text, yes, no) {
  return new Promise((res) => {
    const s = sheet(h("div", { class: "stack" }, h("h2", {}, text),
      h("div", { class: "row" }, h("button", { class: "btn sec sp", onclick: () => { s.close(); res(false); } }, no || t("no")),
        h("button", { class: "btn bad sp", onclick: () => { s.close(); res(true); } }, yes || t("yes")))), { center: true });
  });
}
