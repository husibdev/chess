import { h, $, avatar, nameEl, toast } from "./util.js";
import { Board } from "./board.js";
import { t } from "./i18n.js";
import { net } from "./net.js";
import { boardSize } from "./game.js";
import { sfx } from "./sound.js";

export async function openAnalysis(gid, onBack) {
  document.body.classList.add("ingame");
  const sc = $("#screen"); sc.className = "nopad"; sc.innerHTML = "";
  const root = h("div", { class: "an" }); sc.append(root);
  const back = () => { document.body.classList.remove("ingame"); onBack(); };
  const status = h("div", { class: "card", style: { width: "100%", maxWidth: "420px", textAlign: "center" } }, t("analyzing"));
  root.append(h("div", { class: "row", style: { width: "100%", maxWidth: "420px" } }, h("button", { class: "btn sec", onclick: back }, "‹ " + t("back")), h("h2", {}, t("analysis"))), status);
  let info;
  try { info = await net.rest("/api/game/" + gid); } catch (e) { toast("Error"); return back(); }
  let data = null;
  try {
    let r = await net.rest("/api/analysis/" + gid);
    if (r.status === "done") data = r.data;
    else {
      const s = await net.rest("/api/analysis/" + gid, { method: "POST" });
      if (s.status === "error") { toast(t("err_" + (s.code || "busy"))); return back(); }
      if (s.status === "done") r = await net.rest("/api/analysis/" + gid), data = r.data;
      while (!data) {
        await new Promise((res) => setTimeout(res, 700));
        if (!root.isConnected) return;
        r = await net.rest("/api/analysis/" + gid);
        if (r.status === "done") data = r.data;
        else if (r.status === "error" || r.status === "none") { toast(t("err_busy")); return back(); }
        else status.textContent = t("analyzing") + " " + (r.total ? Math.round(100 * r.done / r.total) + "%" : "");
      }
    }
  } catch (e) { toast("Error"); return back(); }
  status.remove();
  render(root, info, data, back);
}

function evText(d, i) {
  const m = d.mates[i];
  if (m !== null && m !== undefined) return (m > 0 ? "#" : "-#") + Math.abs(m);
  const v = d.evals[i] / 100; return (v > 0 ? "+" : "") + v.toFixed(1);
}
function evPct(d, i) { return 100 / (1 + Math.exp(-0.00368208 * Math.max(-1000, Math.min(1000, d.evals[i])))); }

function render(root, info, d, back) {
  const you = info.you; let idx = d.moves.length;
  const B = new Board({}); B.setFlipped(you === "b");
  document.documentElement.style.setProperty("--bs", (boardSize(380) - 24) + "px");
  const evi = h("i"), evb = h("div", { class: "evb" }, evi), evt = h("div", { class: "evt" });
  const bw = h("div", { class: "bw" }, evb, B.el);
  const info1 = h("div", { class: "accs" },
    ...["w", "b"].map((c) => h("div", { class: "card" }, nameEl(info.players[c]), h("div", { class: "sub" }, t("accuracy")),
      h("h2", {}, d.acc[c] == null ? "–" : d.acc[c] + "%"),
      h("div", { class: "sub" }, `✓${d.counts[c].best}  ?!${d.counts[c].inaccuracy}  ?${d.counts[c].mistake}  ??${d.counts[c].blunder}`))));
  const graph = h("div", { style: { width: "100%", maxWidth: "420px" } });
  const list = h("div", { class: "mlist" });
  const hint = h("div", { class: "sub", style: { minHeight: "20px", textAlign: "center" } });
  const btns = {};
  const go = (n, snd) => { idx = Math.max(0, Math.min(d.moves.length, n)); show(snd); };
  const ctl = h("div", { class: "ctl" },
    btns.f = h("button", { class: "btn sec", onclick: () => go(0) }, "⏮"), btns.p = h("button", { class: "btn sec", onclick: () => go(idx - 1) }, "◀"),
    btns.n = h("button", { class: "btn", onclick: () => go(idx + 1, true) }, "▶"), btns.l = h("button", { class: "btn sec", onclick: () => go(d.moves.length) }, "⏭"));
  root.append(h("div", { class: "row", style: { width: "100%", maxWidth: "420px" } }, h("button", { class: "btn sec", onclick: back }, "‹ " + t("back"))), bw, evt, ctl, hint, info1, graph, list);
  // eval grafigi
  const W = 420, H = 90, n = d.evals.length, X = (i) => (n > 1 ? (i / (n - 1)) * W : 0), Y = (i) => H - (evPct(d, i) / 100) * H;
  let pts = d.evals.map((_, i) => X(i) + "," + Y(i)).join(" ");
  const svg = `<svg class="chart" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none"><rect width="${W}" height="${H}" fill="rgba(128,128,160,.15)" rx="8"/><polygon points="0,${H} ${pts} ${W},${H}" fill="#f2f2f2" opacity=".92"/><line x1="0" x2="${W}" y1="${H / 2}" y2="${H / 2}" stroke="#7C8CFF" stroke-dasharray="3"/><line id="cur" x1="0" x2="0" y1="0" y2="${H}" stroke="#FF6B7A" stroke-width="2"/></svg>`;
  graph.innerHTML = svg;
  graph.addEventListener("pointerdown", (e) => { const b = graph.getBoundingClientRect(); go(Math.round(((e.clientX - b.left) / b.width) * (n - 1))); });
  const cur = graph.querySelector("#cur");
  // yurishlar ro'yxati
  const cells = [];
  for (let i = 0; i < d.moves.length; i++) {
    if (i % 2 === 0) list.append(h("div", { class: "n" }, i / 2 + 1 + "."));
    const j = d.judg[i], mark = j === "blunder" ? "??" : j === "mistake" ? "?" : j === "inaccuracy" ? "?!" : "";
    const b = h("button", { class: mark ? "j-" + j : j === "best" ? "j-best" : "", onclick: () => go(i + 1) }, d.sans[i] + mark);
    cells.push(b); list.append(b);
  }
  function show(snd) {
    const fen = d.fens[idx], last = idx ? d.moves[idx - 1] : null;
    if (snd && idx > 0 && B.fen && d.fens[idx - 1] === B.fen) { const r = B.applyMove(d.moves[idx - 1], fen, false); sfx[r.capture ? "capture" : "move"](); }
    else B.setPosition(fen, { last });
    const turn = fen.split(" ")[1];
    B.markCheck(fen, /[+#]/.test(idx ? d.sans[idx - 1] : ""));
    evi.style.height = evPct(d, idx) + "%"; evt.textContent = evText(d, idx);
    cells.forEach((c, i) => c.classList.toggle("cur", i === idx - 1));
    cur.setAttribute("x1", X(idx)); cur.setAttribute("x2", X(idx));
    const best = d.best[idx];
    const played = idx < d.moves.length ? d.moves[idx] : null;
    B.setArrow(best && best !== played && idx < d.moves.length ? best : null);
    hint.textContent = idx < d.moves.length && best && best !== played && d.judg[idx] ? t("engineBest") + " " + best.slice(0, 2) + "→" + best.slice(2, 4) : "";
    btns.p.disabled = btns.f.disabled = idx === 0; btns.n.disabled = btns.l.disabled = idx === d.moves.length;
  }
  show(false);
}
