import { h, $, tg, toast } from "./util.js";
import { SPRITE } from "./pieces.js";
import { t, setLang, detectLang } from "./i18n.js";
import { net } from "./net.js";
import { S, loadPrefs, applyTheme } from "./state.js";
import { setSound, unlock } from "./sound.js";
import { openGame, bindNet, setHooks, isActive } from "./game.js";
import { renderPlay, closeDlg } from "./play.js";
import { renderLeaderboard, renderProfile, renderDonate, renderRegister, setListHooks } from "./lists.js";
import { openAnalysis } from "./analysis.js";
import { renderSub } from "./subscribe.js";
import { bindCheckers, isActiveC } from "./checkers.js";

const ICONS = {
  play: '<path d="M8 21h8M9 21c0-3 1-5 3-7-3-1-4-4-3-7 1-2 3-3 5-3 2 1 3 3 2 6l-2 3c2 1 3 3 3 8"/>',
  rank: '<path d="M7 4h10v5a5 5 0 0 1-10 0zM7 6H4v2a3 3 0 0 0 3 3M17 6h3v2a3 3 0 0 1-3 3M12 14v4M8 21h8"/>',
  profile: '<circle cx="12" cy="8" r="4"/><path d="M4 21c1-5 4-7 8-7s7 2 8 7"/>',
  donate: '<path d="M12 21s-8-5-8-11a4.5 4.5 0 0 1 8-2.5A4.5 4.5 0 0 1 20 10c0 6-8 11-8 11z"/>',
};
const SCREENS = { play: renderPlay, rank: renderLeaderboard, profile: renderProfile, donate: renderDonate };
let joinedCode = null, started = false;

function renderTabs() {
  const nav = $("#tabs"); nav.innerHTML = "";
  Object.keys(SCREENS).forEach((k) => {
    const b = h("button", { class: S.tab === k ? "on" : "", onclick: () => { unlock(); showTab(k); } });
    b.innerHTML = `<svg viewBox="0 0 24 24">${ICONS[k]}</svg><span>${t(k)}</span>`;
    nav.append(b);
  });
}
function showTab(k) {
  if (isActive() || isActiveC()) return;
  S.tab = k; closeDlg(); renderTabs();
  const sc = $("#screen"); sc.className = ""; sc.innerHTML = ""; sc.scrollTop = 0;
  SCREENS[k](sc);
}
function showRegister() {
  document.body.classList.add("ingame");
  const sc = $("#screen"); sc.className = ""; sc.innerHTML = "";
  renderRegister(sc, () => { let n = 0; const iv = setInterval(() => { if (++n > 12 || net.status === "on") return clearInterval(iv); net.reconnectNow(); }, 2000); });
}
function showMsg(text) {
  document.body.classList.add("ingame");
  const sc = $("#screen"); sc.className = ""; sc.innerHTML = "";
  sc.append(h("div", { class: "stack", style: { textAlign: "center", marginTop: "25vh" } }, h("div", { style: { fontSize: "56px" } }, "♟"), h("h2", {}, text)));
}

function boot() {
  loadPrefs();
  const tgUser = tg && tg.initDataUnsafe && tg.initDataUnsafe.user;
  if (!S.langSet) S.lang = detectLang(tgUser && tgUser.language_code || navigator.language);
  if (!localStorage.getItem("chess_prefs") && tg) S.theme = tg.colorScheme === "light" ? "day" : "night";
  setLang(S.lang); net.setLang(S.lang); applyTheme(); setSound(S.sound);
  document.body.insertAdjacentHTML("afterbegin", SPRITE);
  try {
    if (tg) {
      tg.ready(); tg.expand();
      if (tg.isVersionAtLeast && tg.isVersionAtLeast("8.0") && tg.requestFullscreen && !tg.isFullscreen) tg.requestFullscreen();
      if (tg.disableVerticalSwipes) tg.disableVerticalSwipes();
    }
  } catch (e) {}
  setHooks({
    leave: () => showTab("play"),
    analyze: (id) => openAnalysis(id, () => showTab("profile")),
  });
  setListHooks({ analyze: (id) => openAnalysis(id, () => showTab("profile")), rerender: () => { renderTabs(); showTab(S.tab); } });
  bindNet();
  bindCheckers({ leave: () => showTab("play") });
  const vis = () => net.send({ t: "vis", v: !document.hidden });
  document.addEventListener("visibilitychange", vis);
  try { tg && tg.onEvent("activated", () => net.send({ t: "vis", v: true })); tg && tg.onEvent("deactivated", () => net.send({ t: "vis", v: false })); } catch (e) {}
  window.addEventListener("online", () => net.reconnectNow());
  document.addEventListener("pointerdown", unlock, { once: true });

  net.on("offline", () => { const b = $("#netbar"); b.textContent = t("offline"); b.hidden = false; });
  net.on("hello_ok", (m) => {
    S.me = m.me; S.cfg = m.cfg; S.offline = false; $("#netbar").hidden = true;
    if (m.me.lang && !S.langSet) { S.lang = m.me.lang; setLang(S.lang); }
    const first = !started; started = true;
    if (m.game) { closeDlg(); openGame(m.game); return; }
    if (first) { document.body.classList.remove("ingame"); renderTabs(); showTab("play"); }
    const sp = (m.start_param || "").startsWith("ch_") ? m.start_param.slice(3) : null;
    const code = new URLSearchParams(location.search).get("ch") || sp;
    if (code && code !== joinedCode) { joinedCode = code; net.send({ t: "challenge_join", code }); }
    const inv = new URLSearchParams(location.search).get("inv") || (/^i[ck]_/.test(m.start_param || "") ? m.start_param : null);
    if (inv && inv !== joinedCode) { joinedCode = inv; net.send({ t: "inline_join", token: inv }); }
  });
  net.on("hello_err", (m) => { if (m.code === "not_registered") showRegister(); else if (m.code === "banned") showMsg(t("banned")); else if (m.code === "not_subscribed") { document.body.classList.add("ingame"); const sc = $("#screen"); sc.className = ""; sc.innerHTML = ""; renderSub(sc, m.channels || []); } else showMsg("Open from Telegram"); });
  net.on("me", (m) => { S.me = m.me; });
  net.on("game", () => closeDlg());
  net.on("err", (m) => { if (m.code !== "no_game" && m.code !== "not_your_turn") toast(t("err_" + m.code)); });
  if (!net.init() && !new URLSearchParams(location.search).get("dev")) return showMsg("Open from Telegram");
  net.connect();
}
boot();
