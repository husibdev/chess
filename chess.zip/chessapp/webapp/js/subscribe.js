// Majburiy obuna ekrani: obuna bo'lgach avtomatik davom etadi.
import { h, tg } from "./util.js";
import { t } from "./i18n.js";
import { net } from "./net.js";

export function renderSub(sc, channels) {
  const open = (u) => { try { tg ? tg.openTelegramLink(u) : window.open(u); } catch (e) { window.open(u); } };
  sc.append(h("div", { class: "stack", style: { textAlign: "center", marginTop: "14vh" } }, h("div", { style: { fontSize: "56px" } }, "📢"),
    h("h1", {}, t("subTitle")), h("div", { class: "sub" }, t("subText")),
    ...channels.map((c) => h("button", { class: "btn block", onclick: () => open(c.link) }, "📢 " + c.title)),
    h("div", { class: "sub" }, t("subAuto"))));
  let n = 0;
  const iv = setInterval(() => { if (!sc.isConnected || ++n > 400 || net.status === "on") return clearInterval(iv); net.reconnectNow(); }, 3000);
  document.addEventListener("visibilitychange", () => { if (!document.hidden && sc.isConnected) net.reconnectNow(); });
}
