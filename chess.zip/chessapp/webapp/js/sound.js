let ctx = null, enabled = true;
export function setSound(v) { enabled = v; }
export function unlock() {
  try { if (!ctx) ctx = new (window.AudioContext || window.webkitAudioContext)(); if (ctx.state === "suspended") ctx.resume(); } catch (e) {}
}
function tone(freq, dur, type = "sine", vol = 0.18, delay = 0, slide = 0) {
  if (!enabled || !ctx) return;
  const t0 = ctx.currentTime + delay, o = ctx.createOscillator(), g = ctx.createGain();
  o.type = type; o.frequency.setValueAtTime(freq, t0);
  if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(30, freq + slide), t0 + dur);
  g.gain.setValueAtTime(vol, t0); g.gain.exponentialRampToValueAtTime(0.001, t0 + dur);
  o.connect(g).connect(ctx.destination); o.start(t0); o.stop(t0 + dur + 0.02);
}
function noise(dur, vol, delay = 0, hp = 800) {
  if (!enabled || !ctx) return;
  const n = Math.floor(ctx.sampleRate * dur), buf = ctx.createBuffer(1, n, ctx.sampleRate), d = buf.getChannelData(0);
  for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / n, 3);
  const s = ctx.createBufferSource(), f = ctx.createBiquadFilter(), g = ctx.createGain();
  f.type = "bandpass"; f.frequency.value = hp; g.gain.value = vol; s.buffer = buf;
  s.connect(f).connect(g).connect(ctx.destination); s.start(ctx.currentTime + delay);
}
export const sfx = {
  move() { tone(180, 0.08, "triangle", 0.25, 0, -80); noise(0.05, 0.5, 0, 1800); },
  capture() { tone(130, 0.14, "triangle", 0.32, 0, -70); noise(0.09, 0.9, 0, 1200); },
  check() { tone(740, 0.12, "square", 0.08); tone(980, 0.16, "square", 0.08, 0.1); },
  start() { tone(392, 0.15, "sine", 0.15); tone(523, 0.2, "sine", 0.15, 0.12); },
  win() { [523, 659, 784, 1046].forEach((f, i) => tone(f, 0.25, "triangle", 0.16, i * 0.12)); },
  lose() { [392, 330, 262].forEach((f, i) => tone(f, 0.3, "sine", 0.15, i * 0.16)); },
  draw() { tone(440, 0.25, "sine", 0.14); tone(440, 0.3, "sine", 0.14, 0.2); },
  low() { tone(1000, 0.05, "square", 0.05); },
  click() { tone(600, 0.03, "sine", 0.06); },
};
