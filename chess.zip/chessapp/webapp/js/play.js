import { h, tg, toast, sheet, tcLabel } from "./util.js";
import { t } from "./i18n.js";
import { net } from "./net.js";
import { S } from "./state.js";
import { unlock } from "./sound.js";

export function setDlg(s) { if (S.dlg) S.dlg.close(); S.dlg = s; }
export function closeDlg() { if (S.dlg) { S.dlg.close(); S.dlg = null; } }

function tcPicker(def) {
  const st = { mode: def, idx: 1, min: 15, inc: 10 };
  const wrap = h("div", { class: "stack" });
  const chips = h("div", { class: "chips" }), custom = h("div", { class: "stack" });
  const redraw = () => {
    chips.innerHTML = "";
    S.cfg.presets.forEach((p, i) => chips.append(h("button", { class: "chip" + (st.mode === "p" && st.idx === i ? " on" : ""), onclick: () => { st.mode = "p"; st.idx = i; redraw(); } }, tcLabel(p))));
    chips.append(h("button", { class: "chip" + (st.mode === "c" ? " on" : ""), onclick: () => { st.mode = "c"; redraw(); } }, t("custom")));
    chips.append(h("button", { class: "chip" + (st.mode === "i" ? " on" : ""), onclick: () => { st.mode = "i"; redraw(); } }, "∞"));
    custom.innerHTML = ""; custom.hidden = st.mode !== "c";
    const step = (label, key, min, max) => {
      const out = h("output", {}, String(st[key]));
      return h("div", { class: "row" }, h("span", { class: "sub sp" }, label), h("div", { class: "stepper" },
        h("button", { onclick: () => { st[key] = Math.max(min, st[key] - 1); out.textContent = st[key]; } }, "−"), out,
        h("button", { onclick: () => { st[key] = Math.min(max, st[key] + 1); out.textContent = st[key]; } }, "+")));
    };
    custom.append(step(t("minutes"), "min", 1, Math.floor(S.cfg.maxBase / 60)), step(t("increment"), "inc", 0, S.cfg.maxInc));
  };
  redraw();
  wrap.append(h("div", { class: "sub" }, t("time")), chips, custom);
  return { el: wrap, get: () => st.mode === "i" ? { base: 0, inc: 0 } : st.mode === "c" ? { base: st.min * 60, inc: st.inc } : S.cfg.presets[st.idx] };
}
function colorSeg() {
  let v = "random";
  const el = h("div", { class: "seg" });
  const draw = () => { el.innerHTML = ""; [["random", "random"], ["white", "white"], ["black", "black"]].forEach(([k, l]) => el.append(h("button", { class: v === k ? "on" : "", onclick: () => { v = k; draw(); } }, t(l)))); };
  draw(); return { el, get: () => v };
}
function modeBtn(icon, title, sub, fn) {
  return h("button", { class: "mode", onclick: () => { unlock(); fn(); } },
    h("div", { class: "ic", html: icon }), h("div", { class: "sp" }, h("b", {}, title), h("span", { class: "sub" }, sub)));
}
const IC = {
  bolt: '<svg viewBox="0 0 24 24"><path d="M13 2L4 14h7l-1 8 9-12h-7z"/></svg>',
  users: '<svg viewBox="0 0 24 24"><circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.5-4 3-6 6.5-6s6 2 6.5 6"/><circle cx="17.5" cy="9" r="2.5"/><path d="M17 14c2.5 0 4 1.5 4.5 5"/></svg>',
  cpu: '<svg viewBox="0 0 24 24"><rect x="6" y="6" width="12" height="12" rx="2"/><path d="M9 2v4M15 2v4M9 18v4M15 18v4M2 9h4M2 15h4M18 9h4M18 15h4"/></svg>',
};
export function renderPlay(sc) {
  sc.append(h("h1", {}, "♟ Chess"), h("div", { class: "sub", style: { margin: "4px 0 16px" } }, S.me.name + " · " + S.me.rating),
    h("div", { class: "stack" },
      modeBtn(IC.bolt, t("quick"), t("quickSub"), quick),
      modeBtn(IC.users, t("friend"), t("friendSub"), friend),
      modeBtn(IC.cpu, t("computer"), t("computerSub"), computer),
      modeBtn(IC.disc, t("checkers"), t("checkersSub"), checkers)));
}
function quick() {
  const tc = tcPicker("p"), body = h("div", { class: "stack" }, h("h2", {}, t("quick")), tc.el);
  const s = sheet(body);
  body.append(h("button", { class: "btn block", onclick: () => {
    const v = tc.get(); s.close(); net.send({ t: "queue", tc: v });
  } }, t("start")));
}
net.on("queue_on", (m) => {
  const hint = h("div", { class: "sub", style: { minHeight: "18px" } });
  const body = h("div", { class: "stack" }, h("div", { class: "radar" }, "♞"), h("h2", {}, t("searching")), h("div", { class: "sub" }, tcLabel(m.tc)), hint,
    h("button", { class: "btn sec block", onclick: () => { net.send({ t: "queue_cancel" }); closeDlg(); } }, t("cancel")));
  setDlg(sheet(body, { center: true }));
  setTimeout(() => { if (hint.isConnected) hint.textContent = t("searchHint"); }, 20000);
});
net.on("queue_off", closeDlg);
function friend() {
  const tc = tcPicker("p"), col = colorSeg(), body = h("div", { class: "stack" }, h("h2", {}, t("friend")), tc.el, h("div", { class: "sub" }, t("color")), col.el);
  const s = sheet(body);
  body.append(h("button", { class: "btn block", onclick: () => { s.close(); S.chGame = null; net.send({ t: "challenge_create", tc: tc.get(), color: col.get() }); } }, t("start")));
}
net.on("challenge_on", (m) => {
  const share = "https://t.me/share/url?url=" + encodeURIComponent(m.link) + "&text=" + encodeURIComponent(S.chGame === "checkers" ? t("inviteTextCh") : t("inviteText"));
  const body = h("div", { class: "stack" }, h("div", { class: "radar" }, "🤝"), h("h2", {}, t("waitInvite")), h("div", { class: "sub" }, tcLabel(m.tc)),
    h("button", { class: "btn block", onclick: () => { try { tg ? tg.openTelegramLink(share) : window.open(share); } catch (e) { window.open(share); } } }, "📨 " + t("share")),
    h("button", { class: "btn sec block", onclick: async () => { try { await navigator.clipboard.writeText(m.link); toast(t("copied")); } catch (e) { prompt("", m.link); } } }, t("copyLink")),
    h("button", { class: "btn sec block", onclick: () => { net.send({ t: "challenge_cancel" }); closeDlg(); } }, t("cancel")));
  setDlg(sheet(body, { center: true }));
});
net.on("challenge_off", closeDlg);
function computer() {
  if (!S.cfg.engine) return toast(t("err_engine_off"));
  let level = "normal";
  const tc = tcPicker("i"), col = colorSeg(), lv = h("div", { class: "chips" });
  const draw = () => { lv.innerHTML = ""; Object.keys(S.cfg.levels).forEach((k) => lv.append(h("button", { class: "chip" + (level === k ? " on" : ""), onclick: () => { level = k; draw(); } }, t("lv_" + k) + " ≈" + S.cfg.levels[k]))); };
  draw();
  const body = h("div", { class: "stack" }, h("h2", {}, t("computer")), h("div", { class: "sub" }, t("level")), lv, tc.el, h("div", { class: "sub" }, t("color")), col.el);
  const s = sheet(body);
  body.append(h("button", { class: "btn block", onclick: () => { s.close(); net.send({ t: "bot_start", level, tc: tc.get(), color: col.get() }); } }, t("start")));
}


IC.disc = '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="4.5"/></svg>';
function checkers() {
  let tcv = { base: 600, inc: 0 };
  const chips = h("div", { class: "chips" }), col = colorSeg();
  const draw = () => { chips.innerHTML = ""; [[{ base: 600, inc: 0 }, "10 " + t("min")], [{ base: 0, inc: 0 }, "∞"]].forEach(([v, l]) => chips.append(h("button", { class: "chip" + (tcv.base === v.base ? " on" : ""), onclick: () => { tcv = v; draw(); } }, l))); };
  draw();
  const body = h("div", { class: "stack" }, h("h2", {}, t("checkers")), h("div", { class: "sub" }, t("checkersSub")), h("div", { class: "sub" }, t("time")), chips, h("div", { class: "sub" }, t("color")), col.el);
  const s = sheet(body);
  body.append(h("button", { class: "btn block", onclick: () => { s.close(); S.chGame = "checkers"; net.send({ t: "challenge_create", tc: tcv, color: col.get(), game: "checkers" }); } }, t("start")));
}
