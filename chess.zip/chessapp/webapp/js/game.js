import { h, $, tg, avatar, nameEl, haptic, fmtClock, fmtDur, toast, sheet, confirmBox, tcLabel } from "./util.js";
import { Board, parseFen, pieceSvg } from "./board.js";
import { t } from "./i18n.js";
import { net } from "./net.js";
import { sfx, unlock } from "./sound.js";
import { S } from "./state.js";
import { openCheckers } from "./checkers.js";

let G = null, B = null, recvAt = 0, flipped = false, optimistic = null, ui = null, timer = null, lowSec = -1, overShown = false;
let hooks = { leave() {}, analyze() {} };
export function setHooks(x) { hooks = x; }
export const isActive = () => !!G && G.status === "active";
const VAL = { P: 1, N: 3, B: 3, R: 5, Q: 9 }, START = { P: 8, N: 2, B: 2, R: 2, Q: 1 };
const other = (c) => (c === "w" ? "b" : "w");

function probe() {
  const p = h("div", { style: { position: "fixed", top: 0, left: 0, visibility: "hidden", paddingTop: "var(--sat)", paddingBottom: "var(--sab)" } });
  document.body.append(p); const v = p.offsetHeight; p.remove(); return v;
}
export function boardSize(reserved) {
  const w = window.innerWidth - 16, hh = window.innerHeight - probe() - reserved;
  return Math.max(220, Math.floor(Math.min(w, hh, 560)));
}
function sizeBoard() { document.documentElement.style.setProperty("--bs", boardSize(330) + "px"); }

function bar(color) {
  const clock = h("div", { class: "clock" }, "--:--");
  const info = h("div", { class: "info" });
  const av = h("div");
  const el = h("div", { class: "pbar" }, av, info, clock);
  return { el, clock, info, av, color };
}
function fillBar(b, p) {
  b.av.replaceWith(b.av = avatar(p)); b.info.innerHTML = "";
  b.rt = h("div", { class: "rt" }, p.bot ? "≈" + p.rating : String(p.rating));
  b.mat = h("div", { class: "mat" });
  b.info.append(nameEl(p), b.rt, b.mat);
}
function material(fen) {
  const cnt = { w: { P: 0, N: 0, B: 0, R: 0, Q: 0 }, b: { P: 0, N: 0, B: 0, R: 0, Q: 0 } };
  parseFen(fen).forEach(([, p]) => { if (cnt[p[0]][p[1]] !== undefined) cnt[p[0]][p[1]]++; });
  const val = (c) => Object.keys(VAL).reduce((s, k) => s + VAL[k] * cnt[c][k], 0);
  return { cnt, diff: val("w") - val("b") };
}
function renderMaterial() {
  const m = material(G.fen);
  [["w", ui.bars.w], ["b", ui.bars.b]].forEach(([c, b]) => {
    const o = other(c); b.mat.innerHTML = "";
    for (const k of ["Q", "R", "B", "N", "P"]) for (let i = 0; i < Math.max(0, START[k] - m.cnt[o][k]); i++) b.mat.insertAdjacentHTML("beforeend", pieceSvg(o + k));
    const d = c === "w" ? m.diff : -m.diff;
    if (d > 0) b.mat.append(h("span", {}, "+" + d));
  });
}
function renderMoves() {
  const box = ui.moves; box.innerHTML = "";
  G.sans.forEach((s, i) => {
    if (i % 2 === 0) box.append(h("span", { class: "n" }, (i / 2 + 1) + "."));
    box.append(h("span", i === G.sans.length - 1 ? { class: "cur" } : {}, s));
  });
  box.scrollLeft = box.scrollWidth;
}
function clockMs(c) {
  let ms = G.clocks[c];
  if (G.status === "active" && G.tc.base > 0 && G.ply >= 2 && G.turn === c) ms -= performance.now() - recvAt;
  return ms;
}
function tick() {
  if (!G) return;
  const me = G.you || "w";
  for (const c of ["w", "b"]) {
    const b = ui.bars[c], timed = G.tc.base > 0, ms = clockMs(c), active = G.status === "active" && G.turn === c;
    b.clock.textContent = timed ? fmtClock(ms) : "∞";
    b.clock.classList.toggle("run", active);
    b.clock.classList.toggle("low", timed && G.ply >= 2 && active && ms < 10000);
    b.el.classList.toggle("turn", active);
    if (c === me && timed && G.ply >= 2 && active && ms < 10000) { const s = Math.ceil(ms / 1000); if (s !== lowSec) { lowSec = s; sfx.low(); } }
  }
  // banner
  const opp = other(me), now = G.ts + (performance.now() - recvAt);
  let msg = "";
  if (G.status === "active") {
    if (S.offline) {
      const r = S.cfg.reconnect, win = G.tc.base ? Math.max(r.min, r.frac * G.tc.base) : r.unl;
      msg = t("youAway", { t: fmtDur(win - (Date.now() - S.offlineSince) / 1000) });
    } else if (G.away[opp]) msg = t("oppAway", { t: fmtDur((G.away[opp] - now) / 1000) });
    else if (G.draw_by === me) msg = t("drawSent");
    else if (G.check && G.turn === me) msg = t("check");
    else if (G.turn === me && G.ply > 0) msg = t("yourTurn");
  }
  if (ui.bannerText.textContent !== msg) ui.bannerText.textContent = msg;
  ui.drawBox.hidden = !(G.status === "active" && G.draw_by === opp);
}
function sendMove(uci) {
  unlock();
  if (!isActive() || G.turn !== G.you) return;
  optimistic = uci; const r = B.applyMove(uci, null);
  B.setMine(G.you, false); B.setLegal([]);
  sfx[r.capture ? "capture" : "move"](); haptic.tap();
  net.send({ t: "move", gid: G.id, uci });
}
function actions(st) {
  const flip = h("button", { class: "btn sec", onclick: () => { flipped = !flipped; B.setFlipped(flipped); swapBars(); } }, "⟲ " + t("flip"));
  const res = h("button", { class: "btn sec", onclick: async () => { if (await confirmBox(t("resignQ"))) net.send({ t: "resign", gid: G.id }); } }, "🏳 " + t("resign"));
  const draw = h("button", { class: "btn sec", onclick: () => { net.send({ t: "draw_offer", gid: G.id }); haptic.tap(); } }, "½ " + t("draw"));
  const undo = h("button", { class: "btn sec", onclick: () => { net.send({ t: "undo", gid: G.id }); haptic.tap(); } }, "↩ " + t("undo"));
  ui.act = h("div", { class: "gact" }, flip, res, draw, st && st.kind === "bot" ? undo : null);
  return ui.act;
}
function swapBars() {
  const bot = flipped ? "b" : "w", top = other(bot);
  ui.root.insertBefore(ui.bars[top].el, B.el);
  ui.root.insertBefore(ui.bars[bot].el, ui.moves);
}
function mount(st) {
  document.body.classList.add("ingame");
  const sc = $("#screen"); sc.className = "nopad"; sc.innerHTML = "";
  const me = st.you || "w"; flipped = me === "b"; overShown = false; lowSec = -1;
  B = new Board({ onMove: sendMove, onTouch: unlock });
  B.setFlipped(flipped);
  ui = { bars: { w: bar("w"), b: bar("b") } };
  fillBar(ui.bars.w, st.players.w); fillBar(ui.bars.b, st.players.b);
  ui.moves = h("div", { class: "moves" });
  ui.bannerText = h("span");
  ui.drawBox = h("span", { hidden: true }, " ",
    h("button", { class: "chip on", onclick: () => net.send({ t: "draw_accept", gid: G.id }) }, "✓ " + t("accept")), " ",
    h("button", { class: "chip", onclick: () => net.send({ t: "draw_decline", gid: G.id }) }, "✕ " + t("decline")));
  ui.banner = h("div", { class: "banner" }, ui.bannerText, ui.drawBox);
  ui.root = h("div", { class: "game" });
  const bot = flipped ? "b" : "w", top = other(bot);
  ui.root.append(ui.bars[top].el, B.el, ui.bars[bot].el, ui.moves, ui.banner, actions(st));
  sc.append(ui.root);
  sizeBoard();
  G = st; recvAt = performance.now();
  B.setPosition(st.fen, { intro: true, last: st.moves.length ? st.moves[st.moves.length - 1] : null, check: st.check });
  B.setMine(me, st.status === "active" && st.turn === me); B.setLegal(st.legal);
  renderMaterial(); renderMoves(); sfx.start();
  try { tg && tg.enableClosingConfirmation(); } catch (e) {}
  clearInterval(timer); timer = setInterval(tick, 100); tick();
}
export function openGame(st) {
  if (!st) return;
  if (st.kind === "checkers") return openCheckers(st);
  if (!G || G.id !== st.id || !ui || !ui.root.isConnected) return mount(st);
  update(st, null);
}
function update(st, mv) {
  const prev = G; G = st; recvAt = performance.now();
  const me = st.you || "w", last = st.moves.length ? st.moves[st.moves.length - 1] : null;
  if (st.ply === prev.ply + 1 && (mv || last)) {
    const u = mv || last;
    if (optimistic && optimistic === u) B.settle(st.fen, st.check);
    else { const r = B.applyMove(u, st.fen, st.check); sfx[r.capture ? "capture" : "move"](); haptic.tap(); }
    if (st.check) setTimeout(() => sfx.check(), 120);
  } else if (st.ply !== prev.ply || st.fen !== B.fen || optimistic) {
    B.setPosition(st.fen, { last, check: st.check });
  }
  optimistic = null;
  B.setMine(me, st.status === "active" && st.turn === me); B.setLegal(st.legal);
  [["w", st.players.w], ["b", st.players.b]].forEach(([c, p]) => { ui.bars[c].rt.textContent = p.bot ? "≈" + p.rating : String(p.rating); });
  renderMaterial(); renderMoves(); tick();
}
function result(m) {
  const me = G.you, r = G.result, won = (r === "1-0" && me === "w") || (r === "0-1" && me === "b");
  const kind = m.aborted || !r ? "ab" : r === "1/2-1/2" ? "d" : won ? "w" : "l";
  const icon = { w: "🏆", l: "💔", d: "🤝", ab: "⛔" }[kind];
  const title = { w: t("win"), l: t("lose"), d: t("drawn"), ab: t("aborted") }[kind];
  sfx[{ w: "win", l: "lose", d: "draw", ab: "draw" }[kind]](); (kind === "w" ? haptic.ok : kind === "l" ? haptic.err : haptic.warn)();
  const body = h("div", { class: "stack" }, h("div", { class: "res-ic" }, icon), h("h1", {}, title), h("div", { class: "sub" }, t("r_" + (G.reason || "aborted"))));
  if (m.rating) {
    const d = m.rating.delta, el = h("div", { class: "delta " + (d > 0 ? "pos" : d < 0 ? "neg" : "") });
    body.append(h("div", { class: "sub" }, t("rating")), el);
    const t0 = performance.now();
    (function step(n) { const k = Math.min(1, (n - t0) / 900), v = Math.round(m.rating.old + (m.rating.new - m.rating.old) * k);
      el.textContent = v + "  (" + (d > 0 ? "+" : "") + d + ")"; if (k < 1) requestAnimationFrame(step); })(t0);
  } else body.append(h("div", { class: "sub" }, G.kind === "bot" ? t("computerSub").split("·")[0] : t("unrated")));
  const sh = sheet(body, { center: true });
  const row = h("div", { class: "row" });
  if (!m.aborted && G.moves.length) row.append(h("button", { class: "btn sp", onclick: () => { const gid = G.id; sh.close(); leave(); hooks.analyze(gid); } }, t("analysis")));
  row.append(h("button", { class: "btn sec sp", onclick: () => { sh.close(); leave(); } }, t("playAgain")));
  body.append(row, h("button", { class: "btn sec block", onclick: () => { sh.close(); showEndActions(); } }, t("close")));
  (m.badges || []).forEach((b, i) => setTimeout(() => toast("🎖 " + t("badNew") + " " + t("b_" + b)), 1400 + i * 1500));
}
function showEndActions() {
  ui.act.innerHTML = "";
  const id = G.id, can = G.moves.length > 0 && G.reason !== "aborted";
  if (can) ui.act.append(h("button", { class: "btn", onclick: () => { leave(); hooks.analyze(id); } }, t("analysis")));
  ui.act.append(h("button", { class: "btn sec", onclick: () => leave() }, t("playAgain")));
}
export function leave() {
  clearInterval(timer); G = null; B = null; ui = null;
  document.body.classList.remove("ingame");
  try { tg && tg.disableClosingConfirmation(); } catch (e) {}
  hooks.leave();
}
export function bindNet() {
  net.on("game", (m) => {
    if (m.g && m.g.kind === "checkers") return;
    if (!m.g) { if (G && G.status === "active") leave(); return; }
    if (!G || G.id !== m.g.id || !ui) { S.game = m.g; return openGame(m.g); }
    update(m.g, m.mv);
  });
  net.on("over", (m) => {
    if (!G || !ui || G.id !== m.g.id) { return; }
    const st = m.g, prev = G;
    if (st.ply === prev.ply + 1) { const u = st.moves[st.moves.length - 1]; const r = B.applyMove(u, st.fen, st.check); sfx[r.capture ? "capture" : "move"](); }
    G = st; recvAt = performance.now();
    B.setMine(G.you, false); B.setLegal([]); renderMaterial(); renderMoves(); tick();
    if (st.reason === "checkmate") B.mateFx(st.result === "1-0" ? "b" : "w");
    if (overShown) return; overShown = true;
    setTimeout(() => { if (ui) { result(m); showEndActions(); } }, st.reason === "checkmate" ? 1300 : 650);
  });
  net.on("draw_declined", () => toast(t("drawDeclined")));
  window.addEventListener("resize", () => { if (ui) sizeBoard(); });
  net.on("offline", () => { S.offline = true; S.offlineSince = Date.now(); });
}
