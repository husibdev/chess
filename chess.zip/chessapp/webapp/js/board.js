import { h } from "./util.js";
export const FILES = "abcdefgh";

export function parseFen(fen) {
  const rows = fen.split(" ")[0].split("/"), out = [];
  for (let r = 0; r < 8; r++) {
    let f = 0;
    for (const ch of rows[r]) {
      if (ch >= "1" && ch <= "8") f += +ch;
      else { out.push([FILES[f] + (8 - r), (ch === ch.toUpperCase() ? "w" : "b") + ch.toUpperCase()]); f++; }
    }
  }
  return out;
}
export function pieceSvg(p) {
  return `<svg class="pc ${p[0] === "w" ? "pw" : "pb"}" viewBox="0 0 100 100"><use href="#${p}"/></svg>`;
}

export class Board {
  constructor(opts) {
    this.opts = opts || {};
    this.flipped = false; this.pieces = new Map(); this.sqEl = new Map();
    this.legal = []; this.myColor = null; this.interactive = false; this.sel = null; this.drag = null;
    this.lastUci = null; this.checkSq = null; this.fen = null;
    this.sqs = h("div", { class: "sqs" });
    this.pcs = h("div", { class: "pieces" });
    this.arrows = h("div", { class: "arrows" });
    this.el = h("div", { class: "board" }, this.sqs, this.pcs, this.arrows);
    this.drawSquares();
    const r = this.el;
    r.addEventListener("pointerdown", (e) => this.down(e));
    r.addEventListener("pointermove", (e) => this.move(e));
    r.addEventListener("pointerup", (e) => this.up(e));
    r.addEventListener("pointercancel", () => this.cancel());
  }
  drawSquares() {
    this.sqs.innerHTML = ""; this.sqEl.clear();
    for (let y = 0; y < 8; y++) for (let x = 0; x < 8; x++) {
      const f = this.flipped ? 7 - x : x, r = this.flipped ? y : 7 - y, sq = FILES[f] + (r + 1);
      const el = h("div", { class: "sq" + ((f + r) % 2 === 0 ? " d" : "") });
      if (y === 7) el.append(h("span", { class: "co f" }, FILES[f]));
      if (x === 0) el.append(h("span", { class: "co r" }, String(r + 1)));
      this.sqEl.set(sq, el); this.sqs.append(el);
    }
  }
  xy(sq) { const f = FILES.indexOf(sq[0]), r = +sq[1] - 1; return this.flipped ? [7 - f, r] : [f, 7 - r]; }
  place(el, sq) { const [x, y] = this.xy(sq); el.style.transform = `translate(${x * 100}%,${y * 100}%)`; el.dataset.sq = sq; }
  mk(sq, p, anim) {
    const el = h("div", { class: "piece" + (anim ? " in" : "") });
    el.innerHTML = pieceSvg(p); el.dataset.p = p; this.place(el, sq);
    this.pcs.append(el); this.pieces.set(sq, el); return el;
  }
  setPosition(fen, o = {}) {
    clearTimeout(this.st);
    this.pcs.innerHTML = ""; this.pieces.clear();
    parseFen(fen).forEach(([sq, p], i) => { const el = this.mk(sq, p, o.intro); if (o.intro) el.style.animationDelay = (i * 18) + "ms"; });
    this.fen = fen; this.setLast(o.last || null); this.markCheck(fen, o.check); this.clearSel(); this.setArrow(null);
  }
  sync(fen) {
    const want = new Map(parseFen(fen));
    for (const [sq, el] of [...this.pieces]) if (want.get(sq) !== el.dataset.p) { el.remove(); this.pieces.delete(sq); }
    for (const [sq, p] of want) if (!this.pieces.has(sq)) this.mk(sq, p, false);
  }
  settle(fen, check) { this.fen = fen; this.markCheck(fen, check); clearTimeout(this.st); this.st = setTimeout(() => this.sync(this.fen), 240); }
  applyMove(uci, fen, check) {
    const from = uci.slice(0, 2), to = uci.slice(2, 4), promo = uci[4], el = this.pieces.get(from);
    if (!el) { if (fen) this.setPosition(fen, { last: uci, check }); return { capture: false }; }
    const p = el.dataset.p; let capSq = null;
    if (this.pieces.has(to)) capSq = to;
    else if (p[1] === "P" && from[0] !== to[0]) capSq = to[0] + from[1];
    const capEl = capSq ? this.pieces.get(capSq) : null;
    if (capEl) {
      this.pieces.delete(capSq); capEl.style.setProperty("--t", capEl.style.transform);
      capEl.classList.add("out"); setTimeout(() => capEl.remove(), 300); this.burst(to);
    }
    this.pieces.delete(from); this.pieces.set(to, el); this.place(el, to);
    if (p[1] === "K" && Math.abs(FILES.indexOf(from[0]) - FILES.indexOf(to[0])) === 2) {
      const ks = to[0] > from[0], rf = (ks ? "h" : "a") + from[1], rt = (ks ? "f" : "d") + from[1], rel = this.pieces.get(rf);
      if (rel) { this.pieces.delete(rf); this.pieces.set(rt, rel); this.place(rel, rt); }
    }
    if (promo) { el.dataset.p = p[0] + promo.toUpperCase(); setTimeout(() => { el.innerHTML = pieceSvg(el.dataset.p); this.burst(to); }, 190); }
    this.setLast(uci); this.clearSel(); this.setArrow(null);
    if (fen) this.settle(fen, check);
    return { capture: !!capEl };
  }
  burst(sq) {
    const b = h("div", { class: "burst" });
    for (let i = 0; i < 8; i++) b.append(h("i", { style: { "--a": i * 45 + "deg" } }));
    this.place(b, sq); this.pcs.append(b); setTimeout(() => b.remove(), 600);
  }
  setLast(uci) {
    if (this.lastUci) { this.lastUci.forEach((s) => this.sqEl.get(s)?.classList.remove("last")); }
    this.lastUci = uci ? [uci.slice(0, 2), uci.slice(2, 4)] : null;
    if (this.lastUci) this.lastUci.forEach((s) => this.sqEl.get(s)?.classList.add("last"));
  }
  markCheck(fen, on) {
    if (this.checkSq) this.sqEl.get(this.checkSq)?.classList.remove("check");
    this.checkSq = null;
    if (!on || !fen) return;
    const side = fen.split(" ")[1];
    const k = parseFen(fen).find(([, p]) => p === side + "K");
    if (k) { this.checkSq = k[0]; this.sqEl.get(k[0]).classList.add("check"); }
  }
  mateFx(loser) {
    const el = [...this.pieces.values()].find((e) => e.dataset.p === loser + "K");
    if (el) el.classList.add("mate");
    this.el.classList.add("shake"); const f = h("div", { class: "flash" }); this.el.append(f);
    setTimeout(() => { this.el.classList.remove("shake"); f.remove(); }, 1100);
  }
  setFlipped(f) {
    this.flipped = f; this.drawSquares();
    this.pieces.forEach((el, sq) => this.place(el, sq));
    const l = this.lastUci; this.lastUci = null; if (l) this.setLast(l[0] + l[1]);
    const c = this.checkSq; this.checkSq = null; if (c) { this.checkSq = c; this.sqEl.get(c).classList.add("check"); }
    this.clearSel(); this.setArrow(this.arrowUci);
  }
  setArrow(uci) {
    this.arrowUci = uci; this.arrows.innerHTML = "";
    if (!uci) return;
    const [x1, y1] = this.xy(uci.slice(0, 2)), [x2, y2] = this.xy(uci.slice(2, 4));
    const ax = x1 + .5, ay = y1 + .5, bx = x2 + .5, by = y2 + .5, d = Math.hypot(bx - ax, by - ay) || 1, ux = (bx - ax) / d, uy = (by - ay) / d;
    const tx = bx - ux * .28, ty = by - uy * .28, px = -uy * .22, py = ux * .22;
    this.arrows.innerHTML = `<svg viewBox="0 0 8 8" width="100%" height="100%"><line x1="${ax}" y1="${ay}" x2="${tx}" y2="${ty}" stroke="rgba(74,222,155,.85)" stroke-width=".17" stroke-linecap="round"/><polygon points="${bx},${by} ${tx + px},${ty + py} ${tx - px},${ty - py}" fill="rgba(74,222,155,.9)"/></svg>`;
  }
  // ---- kiritish ----
  setMine(color, on) { this.myColor = color; this.interactive = !!on; if (!on) this.clearSel(); }
  setLegal(list) { this.legal = list || []; if (this.sel) { if (this.targets(this.sel).length) this.hints(this.sel); else this.clearSel(); } }
  targets(sq) { return this.legal.filter((u) => u.startsWith(sq)).map((u) => u.slice(2, 4)); }
  hints(sq) {
    this.sqEl.forEach((e) => e.classList.remove("dot", "cap"));
    const el = this.pieces.get(sq), pawn = el && el.dataset.p[1] === "P";
    this.targets(sq).forEach((to) => this.sqEl.get(to)?.classList.add(this.pieces.has(to) || (pawn && to[0] !== sq[0]) ? "cap" : "dot"));
  }
  select(sq) { this.clearSel(); this.sel = sq; this.sqEl.get(sq)?.classList.add("sel"); this.hints(sq); }
  clearSel() {
    if (this.sel) this.sqEl.get(this.sel)?.classList.remove("sel");
    this.sel = null; this.sqEl.forEach((e) => e.classList.remove("dot", "cap")); this.closePromo();
  }
  sqAt(e) {
    const b = this.el.getBoundingClientRect(), x = Math.floor((e.clientX - b.left) / b.width * 8), y = Math.floor((e.clientY - b.top) / b.height * 8);
    if (x < 0 || x > 7 || y < 0 || y > 7) return null;
    return FILES[this.flipped ? 7 - x : x] + ((this.flipped ? y : 7 - y) + 1);
  }
  down(e) {
    if (!this.interactive) return;
    if (this.promoEl) { this.closePromo(); return; }
    const sq = this.sqAt(e); if (!sq) return;
    if (this.opts.onTouch) this.opts.onTouch();
    if (this.sel && this.sel !== sq && this.targets(this.sel).includes(sq)) { this.tryMove(this.sel, sq); return; }
    const el = this.pieces.get(sq);
    if (el && el.dataset.p[0] === this.myColor && this.targets(sq).length) {
      const wasSel = this.sel === sq; this.select(sq);
      this.drag = { el, sq, x: e.clientX, y: e.clientY, moved: false, wasSel, id: e.pointerId };
      try { this.el.setPointerCapture(e.pointerId); } catch (x) {}
    } else this.clearSel();
  }
  move(e) {
    const d = this.drag; if (!d) return;
    if (!d.moved && Math.hypot(e.clientX - d.x, e.clientY - d.y) > 8) { d.moved = true; d.el.classList.add("drag"); }
    if (d.moved) {
      const b = this.el.getBoundingClientRect(), s = b.width / 8;
      d.el.style.transform = `translate(${e.clientX - b.left - s / 2}px,${e.clientY - b.top - s / 2 - s * .25}px)`;
    }
  }
  up(e) {
    const d = this.drag; if (!d) return; this.drag = null;
    try { this.el.releasePointerCapture(d.id); } catch (x) {}
    if (d.moved) {
      d.el.classList.remove("drag");
      const to = this.sqAt(e);
      if (to && to !== d.sq && this.targets(d.sq).includes(to)) this.tryMove(d.sq, to, d.el);
      else this.place(d.el, d.sq);
    } else if (d.wasSel) this.clearSel();
  }
  cancel() { if (this.drag) { this.drag.el.classList.remove("drag"); this.place(this.drag.el, this.drag.sq); this.drag = null; } }
  tryMove(from, to, dragEl) {
    const c = this.legal.filter((u) => u.startsWith(from + to));
    if (!c.length) return;
    if (c.some((u) => u.length === 5)) { if (dragEl) this.place(dragEl, from); this.askPromo(from, to); return; }
    this.opts.onMove && this.opts.onMove(c[0]);
  }
  askPromo(from, to) {
    const [x, y] = this.xy(to), top = y < 4 ? y : y - 3;
    const box = h("div", { class: "promo", style: { left: x * 12.5 + "%", top: top * 12.5 + "%" } });
    ["q", "r", "b", "n"].forEach((l) => {
      const b = h("button", {}); b.innerHTML = pieceSvg(this.myColor + l.toUpperCase());
      b.addEventListener("pointerdown", (ev) => { ev.stopPropagation(); this.closePromo(); this.opts.onMove && this.opts.onMove(from + to + l); });
      box.append(b);
    });
    this.promoEl = box; this.el.append(box);
  }
  closePromo() { if (this.promoEl) { this.promoEl.remove(); this.promoEl = null; } }
}
