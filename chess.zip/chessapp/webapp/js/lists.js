import { h, $, tg, avatar, nameEl, sheet, toast, fmtDur, tcLabel } from "./util.js";
import { t, setLang, getLang, LANGS, BADGE_ICON } from "./i18n.js";
import { net } from "./net.js";
import { S, savePrefs, applyTheme } from "./state.js";
import { setSound } from "./sound.js";

let hooks = { analyze() {}, rerender() {} };
export function setListHooks(x) { hooks = x; }
const fail = () => toast("Error");

// ---------- Leaderboard ----------
let lbKind = "week";
export async function renderLeaderboard(sc) {
  const seg = h("div", { class: "seg" });
  const list = h("div", {});
  const head = h("div", { class: "sub", style: { margin: "10px 2px" } });
  const draw = () => { seg.innerHTML = ""; [["week", "week"], ["career", "career"]].forEach(([k, l]) => seg.append(h("button", { class: lbKind === k ? "on" : "", onclick: () => { lbKind = k; draw(); load(); } }, t(l)))); };
  sc.append(h("h1", { style: { marginBottom: "12px" } }, t("rank")), seg, head, list);
  draw();
  async function load() {
    list.innerHTML = ""; head.textContent = "";
    let d; try { d = await net.rest("/api/leaderboard?kind=" + lbKind); } catch (e) { return fail(); }
    if (!list.isConnected) return;
    if (d.kind === "week") {
      const left = d.end - Date.now() / 1000;
      head.innerHTML = ""; head.append(t("resets", { t: fmtDur(left) }), h("br"), t("topNote"));
    }
    if (d.me) list.append(h("div", { class: "lrow me" }, h("div", { class: "rk" }, "#" + d.me.rank), h("div", { class: "sp" }, h("b", {}, t("yourRank"))), h("div", { class: "val" }, d.me.value)));
    if (!d.items.length) list.append(h("div", { class: "card sub", style: { textAlign: "center" } }, t("empty")));
    d.items.forEach((u) => {
      const top = d.kind === "week" && u.rank <= d.top;
      const row = h("button", { class: "lrow" + (u.id === S.me.id ? " me" : "") + (top ? " top" : ""), style: { width: "100%", textAlign: "left" }, onclick: () => showProfile(u.id) },
        h("div", { class: "rk" + (u.rank <= 3 ? " m" + u.rank : "") }, String(u.rank)), avatar(u), h("div", { class: "sp", style: { minWidth: 0 } }, nameEl(u),
          h("div", { class: "sub" }, d.kind === "week" ? (u.net > 0 ? "+" : "") + u.net + " Elo" : u.games + " · " + t("wins") + " " + u.wins)),
        h("div", { class: "val" }, String(u.value)));
      list.append(row);
    });
  }
  load();
}

// ---------- Profile ----------
function chart(hist) {
  if (hist.length < 2) return h("div", { class: "sub", style: { textAlign: "center", padding: "20px" } }, "–");
  const vals = hist.map((x) => x[1]), mn = Math.min(...vals) - 10, mx = Math.max(...vals) + 10, W = 320, H = 110;
  const pts = vals.map((v, i) => (i / (vals.length - 1)) * W + "," + (H - ((v - mn) / (mx - mn)) * H));
  const el = h("div"); el.innerHTML = `<svg class="chart" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none"><defs><linearGradient id="cg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#7C8CFF" stop-opacity=".5"/><stop offset="1" stop-color="#7C8CFF" stop-opacity="0"/></linearGradient></defs><polygon points="0,${H} ${pts.join(" ")} ${W},${H}" fill="url(#cg)"/><polyline points="${pts.join(" ")}" fill="none" stroke="#7C8CFF" stroke-width="2.5" stroke-linejoin="round" vector-effect="non-scaling-stroke"/></svg>`;
  el.append(h("div", { class: "row sub" }, h("span", {}, mn + 10), h("span", { class: "sp" }), h("span", {}, mx - 10)));
  return el;
}
const ALL_BADGES = ["first_win", "wins_10", "wins_50", "wins_100", "games_10", "games_100", "streak_3", "streak_5", "streak_10", "rating_1400", "rating_1600", "rating_1800", "rating_2000", "beat_hard", "beat_max", "quick_mate", "week_top10", "week_champion"];
function profileBody(d, withGames) {
  const u = d.user, s = d.stats, root = h("div", { class: "stack" });
  root.append(h("div", { class: "row", style: { gap: "14px" } }, avatar(u, "lg"), h("div", { class: "sp", style: { minWidth: 0 } }, h("h2", {}, nameEl(u)),
    h("div", { class: "sub" }, u.username ? "@" + u.username : ""), h("div", { class: "row", style: { marginTop: "4px" } }, h("b", { class: "mono", style: { fontSize: "22px" } }, String(u.rating)), d.rank ? h("span", { class: "sub" }, "#" + d.rank) : null))));
  root.append(h("div", { class: "stats" },
    [[s.rated_games, "games"], [s.wins, "wins"], [s.draws, "draws"], [s.losses, "losses"], [d.winrate + "%", "winrate"], [s.best_rating, "bestRating"], [s.best_streak, "streak"], [s.bot_wins + "/" + s.bot_games, "vsBot"]]
      .map(([v, k]) => h("div", { class: "stat" }, h("b", {}, String(v)), h("span", {}, t(k))))));
  root.append(h("div", { class: "card" }, h("h3", { style: { marginBottom: "8px" } }, t("ratingGraph")), chart(d.history)));
  const have = new Set(d.badges.map((b) => b.code));
  root.append(h("h3", {}, t("badges")), h("div", { class: "badges" }, ALL_BADGES.map((c) => h("div", { class: "badge" + (have.has(c) ? "" : " off") }, h("i", {}, BADGE_ICON[c]), t("b_" + c)))));
  if (withGames) {
    root.append(h("h3", {}, t("history")));
    if (!d.games.length) root.append(h("div", { class: "sub" }, t("noHistory")));
    d.games.forEach((g) => {
      const opp = g.bot ? "🤖 Stockfish " + t("lv_" + g.bot) : g.opp ? g.opp.name : "?";
      const dl = g.rated ? (g.delta > 0 ? "+" : "") + g.delta : "";
      root.append(h("button", { class: "hrow", onclick: () => g.kind !== "checkers" && g.ply > 0 && g.reason !== "aborted" && hooks.analyze(g.id) },
        h("div", { class: "res " + g.res }, g.res === "w" ? "W" : g.res === "l" ? "L" : "D"),
        h("div", { class: "sp", style: { minWidth: 0 } }, h("b", {}, (g.kind === "checkers" ? "🔴 " : "") + opp), h("div", { class: "sub" }, tcLabel({ base: g.tc[0], inc: g.tc[1] }) + " · " + t("r_" + g.reason) + " · " + new Date(g.ts * 1000).toLocaleDateString())),
        h("div", { class: "mono " + (g.delta > 0 ? "pos" : g.delta < 0 ? "neg" : "") }, dl)));
    });
  }
  return root;
}
export async function renderProfile(sc) {
  sc.append(h("div", { class: "row" }, h("h1", { class: "sp" }, t("profile")), h("button", { class: "btn sec", style: { minHeight: "40px" }, onclick: settings }, "⚙ " + t("settings"))));
  const box = h("div", { style: { marginTop: "14px" } }); sc.append(box);
  try { const d = await net.rest("/api/profile"); if (box.isConnected) box.append(profileBody(d, true)); } catch (e) { fail(); }
}
export async function showProfile(uid) {
  try { const d = await net.rest("/api/profile?uid=" + uid); sheet(profileBody(d, false)); } catch (e) { fail(); }
}
function settings() {
  const mk = (opts, cur, fn) => { const el = h("div", { class: "seg" }); const dr = () => { el.innerHTML = ""; opts.forEach(([k, l]) => el.append(h("button", { class: cur === k ? "on" : "", onclick: () => { cur = k; fn(k); dr(); } }, l))); }; dr(); return el; };
  const names = { en: "English", uz: "Oʻzbekcha", ru: "Русский" };
  const body = h("div", { class: "stack" }, h("h2", {}, t("settings")),
    h("div", { class: "sub" }, t("language")), mk(LANGS.map((l) => [l, names[l]]), getLang(), (l) => { S.lang = l; setLang(l); net.setLang(l); net.send({ t: "lang", lang: l }); savePrefs(); s.close(); hooks.rerender(); }),
    h("div", { class: "sub" }, t("theme")), mk([["day", "☀ " + t("day")], ["night", "☾ " + t("night")]], S.theme, (v) => { S.theme = v; applyTheme(); savePrefs(); }),
    h("div", { class: "sub" }, t("sound")), mk([[true, t("on")], [false, t("off")]], S.sound, (v) => { S.sound = v; setSound(v); savePrefs(); }));
  const s = sheet(body);
}

// ---------- Donate ----------
export function renderDonate(sc) {
  sc.append(h("h1", {}, t("donate")), h("div", { class: "card", style: { textAlign: "center", marginTop: "16px", padding: "34px 18px" } },
    h("div", { class: "heart" }, "💙"), h("h2", { style: { margin: "14px 0 8px" } }, t("soon")), h("div", { class: "sub" }, t("donateText"))));
}

// ---------- Register ----------
export function renderRegister(sc, retry) {
  const wait = h("div", { class: "sub", style: { minHeight: "20px" } });
  sc.append(h("div", { class: "stack", style: { textAlign: "center", marginTop: "18vh" } }, h("div", { style: { fontSize: "60px" } }, "📱"), h("h1", {}, t("regTitle")), h("div", { class: "sub" }, t("regText")),
    h("button", { class: "btn block", onclick: () => {
      try { if (tg && tg.requestContact) { tg.requestContact((ok) => { if (ok) { wait.textContent = t("regWait"); retry(); } }); return; } } catch (e) {}
      if (tg) tg.close();
    } }, t("regShare")),
    h("button", { class: "btn sec block", onclick: () => tg && tg.close() }, t("regOpen")), wait));
}
