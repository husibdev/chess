const D = {
en: {
 play:"Play", rank:"Ranking", profile:"Profile", donate:"Donate",
 quick:"Quick match", quickSub:"Random opponent · rated", friend:"Play a friend", friendSub:"Send an invite link · casual",
 computer:"Play the computer", computerSub:"Stockfish · choose strength",
 time:"Time control", custom:"Custom", minutes:"Minutes", increment:"Increment (s)", unlimited:"No clock",
 easy:"Easy", medium:"Medium", hard:"Hard", max:"Master", lv_beginner:"Beginner", lv_super_easy:"Super easy", lv_easy:"Easy", lv_normal:"Normal", lv_normal_plus:"Normal +", lv_normal_pro:"Normal pro", lv_hard:"Hard", lv_hard_extra:"Hard extra", lv_hard_max:"Hard max", lv_expert:"Expert", level:"Strength", color:"Your color", random:"Random", white:"White", black:"Black",
 start:"Start", searching:"Looking for an opponent…", cancel:"Cancel", waitInvite:"Waiting for your friend…", share:"Share invite", copyLink:"Copy link", copied:"Link copied",
 inviteText:"Let's play chess!", 
 you:"You", resign:"Resign", draw:"Draw", flip:"Flip", resignQ:"Resign this game?", yes:"Yes", no:"No", ok:"OK", close:"Close",
 drawOffered:"Opponent offers a draw", drawSent:"Draw offer sent", accept:"Accept", decline:"Decline", drawDeclined:"Draw declined",
 oppAway:"Opponent is away — auto-win in {t}", youAway:"Connection lost — you lose in {t}", yourTurn:"Your move", check:"Check", 
 win:"You won!", lose:"You lost", drawn:"Draw", aborted:"Game aborted",
 r_checkmate:"Checkmate", r_resign:"Resignation", r_timeout:"Time out", r_timeout_insufficient:"Time out (insufficient material)", r_stalemate:"Stalemate",
 r_agreement:"Agreement", r_abandon:"Opponent left", r_insufficient:"Insufficient material", r_repetition:"Repetition", r_seventyfive:"75-move rule", r_claim:"Draw claimed", r_draw:"Draw", r_aborted:"Aborted",
 rating:"Rating", analysis:"Analysis", playAgain:"New game", back:"Back", analyzing:"Analyzing…", accuracy:"Accuracy", best:"Best", inaccuracy:"Inaccuracy", mistake:"Mistake", blunder:"Blunder",
 engineBest:"Best was", unrated:"Casual", rated:"Rated",
 week:"This week", career:"Career", wins:"Wins", resets:"Resets in {t}", topNote:"Top 10 get ⭐ and a golden name next week", empty:"No games yet — be the first!", yourRank:"Your rank",
 games:"Games", draws:"Draws", losses:"Losses", winrate:"Win rate", bestRating:"Best rating", streak:"Best streak", vsBot:"Vs computer", badges:"Badges", history:"Games", noHistory:"No games yet", ratingGraph:"Rating",
 settings:"Settings", language:"Language", theme:"Theme", day:"Day", night:"Night", sound:"Sound", on:"On", off:"Off",
 soon:"Coming soon", donateText:"This bot is free. Donations will be added here later.",
 regTitle:"Register in the bot", regText:"Share your Telegram contact with the bot once to start playing.", regShare:"Share contact", regOpen:"Open bot", regWait:"Checking…",
 err_in_game:"You already have a game", err_engine_off:"Computer is not available now", err_challenge_gone:"Invite expired", err_own_challenge:"This is your own invite", err_bad_tc:"Wrong time settings", err_busy:"Server is busy, try later", err_illegal:"Illegal move", err_draw_no:"Can't offer a draw now",
 offline:"Reconnecting…", undo:"Undo", err_undo_no:"Nothing to undo", subTitle:"Subscribe to continue", subText:"To use the game, please join our channel:", subAuto:"The game opens automatically after you subscribe.", checkers:"Play checkers (beta)", checkersSub:"Russian draughts · with a friend · casual", inviteTextCh:"Let's play checkers!", mustCapture:"Capture is mandatory", r_no_moves:"No moves left", r_fifteen:"15-move rule", err_maint:"Maintenance in progress, try again later", banned:"Your account is restricted", badNew:"New badge!",
 b_first_win:"First win", b_wins_10:"10 wins", b_wins_50:"50 wins", b_wins_100:"100 wins", b_games_10:"10 games", b_games_100:"100 games", b_streak_3:"3 in a row", b_streak_5:"5 in a row", b_streak_10:"10 in a row",
 b_rating_1400:"Rating 1400", b_rating_1600:"Rating 1600", b_rating_1800:"Rating 1800", b_rating_2000:"Rating 2000", b_beat_hard:"Beat Hard", b_beat_max:"Beat Master", b_quick_mate:"Mate ≤ 20", b_week_top10:"Weekly top 10", b_week_champion:"Weekly #1",
 searchHint:"No one yet? Try the computer meanwhile.", min:"min"
},
uz: {
 play:"Oʻyin", rank:"Reyting", profile:"Profil", donate:"Donat",
 quick:"Tezkor oʻyin", quickSub:"Tasodifiy raqib · reytingli", friend:"Doʻst bilan", friendSub:"Havola yuboring · reytingsiz",
 computer:"Kompyuterga qarshi", computerSub:"Stockfish · kuchini tanlang",
 time:"Vaqt", custom:"Boshqa", minutes:"Daqiqa", increment:"Qoʻshimcha (s)", unlimited:"Vaqtsiz",
 easy:"Oson", medium:"Oʻrta", hard:"Qiyin", max:"Master", lv_beginner:"Beginner", lv_super_easy:"Super easy", lv_easy:"Easy", lv_normal:"Normal", lv_normal_plus:"Normal +", lv_normal_pro:"Normal pro", lv_hard:"Hard", lv_hard_extra:"Hard extra", lv_hard_max:"Hard max", lv_expert:"Expert", level:"Kuch", color:"Rangingiz", random:"Tasodifiy", white:"Oq", black:"Qora",
 start:"Boshlash", searching:"Raqib qidirilmoqda…", cancel:"Bekor qilish", waitInvite:"Doʻstingiz kutilmoqda…", share:"Taklif yuborish", copyLink:"Havolani nusxalash", copied:"Havola nusxalandi",
 inviteText:"Keling, shaxmat oʻynaymiz!",
 you:"Siz", resign:"Taslim", draw:"Durang", flip:"Aylantirish", resignQ:"Taslim boʻlasizmi?", yes:"Ha", no:"Yoʻq", ok:"OK", close:"Yopish",
 drawOffered:"Raqib durang taklif qilmoqda", drawSent:"Durang taklifi yuborildi", accept:"Qabul", decline:"Rad etish", drawDeclined:"Durang rad etildi",
 oppAway:"Raqib uzildi — {t} da avto-gʻalaba", youAway:"Aloqa uzildi — {t} da yutqazasiz", yourTurn:"Sizning yurishingiz", check:"Shoh",
 win:"Gʻalaba!", lose:"Magʻlubiyat", drawn:"Durang", aborted:"Oʻyin bekor qilindi",
 r_checkmate:"Mat", r_resign:"Taslim", r_timeout:"Vaqt tugadi", r_timeout_insufficient:"Vaqt tugadi (material yetarli emas)", r_stalemate:"Pat",
 r_agreement:"Kelishuv", r_abandon:"Raqib oʻyinni tark etdi", r_insufficient:"Material yetarli emas", r_repetition:"Takrorlanish", r_seventyfive:"75 yurish qoidasi", r_claim:"Durang talab qilindi", r_draw:"Durang", r_aborted:"Bekor qilindi",
 rating:"Reyting", analysis:"Tahlil", playAgain:"Yangi oʻyin", back:"Orqaga", analyzing:"Tahlil qilinmoqda…", accuracy:"Aniqlik", best:"Eng yaxshi", inaccuracy:"Noaniqlik", mistake:"Xato", blunder:"Qobiliyatsiz xato",
 engineBest:"Eng yaxshisi", unrated:"Reytingsiz", rated:"Reytingli",
 week:"Shu hafta", career:"Butun davr", wins:"Gʻalaba", resets:"{t} dan keyin yangilanadi", topNote:"Top 10 keyingi hafta ⭐ va oltin ism oladi", empty:"Hali oʻyin yoʻq — birinchi boʻling!", yourRank:"Sizning oʻrningiz",
 games:"Oʻyinlar", draws:"Durang", losses:"Magʻlubiyat", winrate:"Gʻalaba %", bestRating:"Eng yuqori reyting", streak:"Eng uzun seriya", vsBot:"Kompyuterga qarshi", badges:"Yutuqlar", history:"Oʻyinlar", noHistory:"Hali oʻyin yoʻq", ratingGraph:"Reyting",
 settings:"Sozlamalar", language:"Til", theme:"Mavzu", day:"Kun", night:"Tun", sound:"Ovoz", on:"Yoqilgan", off:"Oʻchiq",
 soon:"Tez orada", donateText:"Bu bot bepul. Donat boʻlimi keyinroq qoʻshiladi.",
 regTitle:"Botda roʻyxatdan oʻting", regText:"Oʻynash uchun Telegram kontaktingizni botga bir marta ulashing.", regShare:"Kontaktni ulashish", regOpen:"Botni ochish", regWait:"Tekshirilmoqda…",
 err_in_game:"Sizda tugamagan oʻyin bor", err_engine_off:"Kompyuter hozir mavjud emas", err_challenge_gone:"Taklif muddati tugagan", err_own_challenge:"Bu sizning taklifingiz", err_bad_tc:"Vaqt sozlamasi notoʻgʻri", err_busy:"Server band, keyinroq urining", err_illegal:"Notoʻgʻri yurish", err_draw_no:"Hozir durang taklif qilib boʻlmaydi",
 offline:"Qayta ulanmoqda…", undo:"Orqaga", err_undo_no:"Qaytaradigan yurish yoʻq", subTitle:"Davom etish uchun obuna boʻling", subText:"Oʻyindan foydalanish uchun kanalimizga obuna boʻling:", subAuto:"Obuna boʻlgach oʻyin avtomatik ochiladi.", checkers:"Shashka (beta)", checkersSub:"Rus shashkasi · doʻst bilan · reytingsiz", inviteTextCh:"Keling, shashka oʻynaymiz!", mustCapture:"Olish majburiy", r_no_moves:"Yurish qolmadi", r_fifteen:"15 yurish qoidasi", err_maint:"Texnik ishlar olib borilmoqda, keyinroq urinib koʻring", banned:"Akkauntingiz cheklangan", badNew:"Yangi yutuq!",
 b_first_win:"Birinchi gʻalaba", b_wins_10:"10 gʻalaba", b_wins_50:"50 gʻalaba", b_wins_100:"100 gʻalaba", b_games_10:"10 oʻyin", b_games_100:"100 oʻyin", b_streak_3:"Ketma-ket 3", b_streak_5:"Ketma-ket 5", b_streak_10:"Ketma-ket 10",
 b_rating_1400:"Reyting 1400", b_rating_1600:"Reyting 1600", b_rating_1800:"Reyting 1800", b_rating_2000:"Reyting 2000", b_beat_hard:"Qiyinni yengdi", b_beat_max:"Masterni yengdi", b_quick_mate:"Mat ≤ 20", b_week_top10:"Haftalik top 10", b_week_champion:"Haftalik #1",
 searchHint:"Hech kim yoʻqmi? Hozircha kompyuter bilan oʻynang.", min:"daq"
},
ru: {
 play:"Игра", rank:"Рейтинг", profile:"Профиль", donate:"Донат",
 quick:"Быстрая игра", quickSub:"Случайный соперник · рейтинговая", friend:"С другом", friendSub:"Отправьте ссылку · без рейтинга",
 computer:"Против компьютера", computerSub:"Stockfish · выберите силу",
 time:"Контроль времени", custom:"Свой", minutes:"Минуты", increment:"Добавка (с)", unlimited:"Без часов",
 easy:"Лёгкий", medium:"Средний", hard:"Сложный", max:"Мастер", lv_beginner:"Бегинер", lv_super_easy:"Супер изи", lv_easy:"Изи", lv_normal:"Нормал", lv_normal_plus:"Нормал +", lv_normal_pro:"Нормал про", lv_hard:"Хард", lv_hard_extra:"Хард экстра", lv_hard_max:"Хард макс", lv_expert:"Эксперт", level:"Сила", color:"Ваш цвет", random:"Случайно", white:"Белые", black:"Чёрные",
 start:"Начать", searching:"Ищем соперника…", cancel:"Отмена", waitInvite:"Ждём друга…", share:"Отправить приглашение", copyLink:"Копировать ссылку", copied:"Ссылка скопирована",
 inviteText:"Давай сыграем в шахматы!",
 you:"Вы", resign:"Сдаться", draw:"Ничья", flip:"Повернуть", resignQ:"Сдаться в этой партии?", yes:"Да", no:"Нет", ok:"ОК", close:"Закрыть",
 drawOffered:"Соперник предлагает ничью", drawSent:"Предложение ничьей отправлено", accept:"Принять", decline:"Отклонить", drawDeclined:"Ничья отклонена",
 oppAway:"Соперник отключился — победа через {t}", youAway:"Нет связи — поражение через {t}", yourTurn:"Ваш ход", check:"Шах",
 win:"Победа!", lose:"Поражение", drawn:"Ничья", aborted:"Партия отменена",
 r_checkmate:"Мат", r_resign:"Сдача", r_timeout:"Время вышло", r_timeout_insufficient:"Время вышло (недостаточно материала)", r_stalemate:"Пат",
 r_agreement:"По согласию", r_abandon:"Соперник ушёл", r_insufficient:"Недостаточно материала", r_repetition:"Повторение", r_seventyfive:"Правило 75 ходов", r_claim:"Ничья по требованию", r_draw:"Ничья", r_aborted:"Отменена",
 rating:"Рейтинг", analysis:"Анализ", playAgain:"Новая игра", back:"Назад", analyzing:"Анализ…", accuracy:"Точность", best:"Лучший", inaccuracy:"Неточность", mistake:"Ошибка", blunder:"Грубая ошибка",
 engineBest:"Лучше было", unrated:"Без рейтинга", rated:"Рейтинговая",
 week:"Эта неделя", career:"Всё время", wins:"Победы", resets:"Сброс через {t}", topNote:"Топ-10 получает ⭐ и золотое имя на следующей неделе", empty:"Игр пока нет — будьте первым!", yourRank:"Ваше место",
 games:"Игры", draws:"Ничьи", losses:"Поражения", winrate:"Побед %", bestRating:"Лучший рейтинг", streak:"Лучшая серия", vsBot:"Против компьютера", badges:"Достижения", history:"Партии", noHistory:"Партий пока нет", ratingGraph:"Рейтинг",
 settings:"Настройки", language:"Язык", theme:"Тема", day:"День", night:"Ночь", sound:"Звук", on:"Вкл", off:"Выкл",
 soon:"Скоро", donateText:"Этот бот бесплатный. Раздел доната появится позже.",
 regTitle:"Зарегистрируйтесь в боте", regText:"Один раз поделитесь контактом Telegram с ботом, чтобы начать играть.", regShare:"Поделиться контактом", regOpen:"Открыть бота", regWait:"Проверяем…",
 err_in_game:"У вас уже есть партия", err_engine_off:"Компьютер сейчас недоступен", err_challenge_gone:"Приглашение устарело", err_own_challenge:"Это ваше приглашение", err_bad_tc:"Неверное время", err_busy:"Сервер занят, попробуйте позже", err_illegal:"Недопустимый ход", err_draw_no:"Сейчас нельзя предложить ничью",
 offline:"Переподключение…", undo:"Отмена", err_undo_no:"Нечего отменять", subTitle:"Подпишитесь, чтобы продолжить", subText:"Чтобы пользоваться игрой, подпишитесь на наш канал:", subAuto:"Игра откроется автоматически после подписки.", checkers:"Шашки (бета)", checkersSub:"Русские шашки · с другом · без рейтинга", inviteTextCh:"Давай сыграем в шашки!", mustCapture:"Бить обязательно", r_no_moves:"Нет ходов", r_fifteen:"Правило 15 ходов", err_maint:"Идут технические работы, попробуйте позже", banned:"Ваш аккаунт ограничен", badNew:"Новое достижение!",
 b_first_win:"Первая победа", b_wins_10:"10 побед", b_wins_50:"50 побед", b_wins_100:"100 побед", b_games_10:"10 партий", b_games_100:"100 партий", b_streak_3:"3 подряд", b_streak_5:"5 подряд", b_streak_10:"10 подряд",
 b_rating_1400:"Рейтинг 1400", b_rating_1600:"Рейтинг 1600", b_rating_1800:"Рейтинг 1800", b_rating_2000:"Рейтинг 2000", b_beat_hard:"Победил сложного", b_beat_max:"Победил мастера", b_quick_mate:"Мат ≤ 20", b_week_top10:"Топ-10 недели", b_week_champion:"№1 недели",
 searchHint:"Никого нет? Пока сыграйте с компьютером.", min:"мин"
}};
let cur = "en";
export const LANGS = ["en", "uz", "ru"];
export function setLang(l) { cur = D[l] ? l : "en"; document.documentElement.lang = cur; }
export function getLang() { return cur; }
export function t(k, v) {
  let s = (D[cur] && D[cur][k]) || D.en[k] || k;
  if (v) for (const x in v) s = s.replace("{" + x + "}", v[x]);
  return s;
}
export function detectLang(code) { code = (code || "").slice(0, 2); return code === "uz" || code === "ru" ? code : "en"; }
export const BADGE_ICON = { first_win:"🏆", wins_10:"🥉", wins_50:"🥈", wins_100:"🥇", games_10:"🎲", games_100:"🎯", streak_3:"🔥", streak_5:"🔥", streak_10:"☄️", rating_1400:"📈", rating_1600:"📈", rating_1800:"🚀", rating_2000:"👑", beat_hard:"🤖", beat_max:"🧠", quick_mate:"⚡", week_top10:"⭐", week_champion:"🌟" };
