export const S = { me: null, cfg: null, game: null, lang: "en", theme: "night", sound: true, tab: "play", offline: false, offlineSince: 0, weekEnd: 0 };
export function loadPrefs() {
  try { const p = JSON.parse(localStorage.getItem("chess_prefs") || "{}"); Object.assign(S, p); } catch (e) {}
}
export function savePrefs() {
  try { localStorage.setItem("chess_prefs", JSON.stringify({ lang: S.lang, theme: S.theme, sound: S.sound, langSet: true })); } catch (e) {}
}
export function applyTheme() {
  document.documentElement.dataset.theme = S.theme;
  try {
    const tg = window.Telegram && window.Telegram.WebApp;
    if (tg) { const c = S.theme === "day" ? "#EEF1FB" : "#12142A"; tg.setHeaderColor(c); tg.setBackgroundColor(c); tg.setBottomBarColor && tg.setBottomBarColor(c); }
  } catch (e) {}
}
