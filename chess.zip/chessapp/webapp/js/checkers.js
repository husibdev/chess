// Rus shashkasi (beta) — mijoz qismi. Server: checkers.py
import { h, $, tg, avatar, nameEl, haptic, fmtClock, fmtDur, toast, sheet, confirmBox } from "./util.js";
import { t } from "./i18n.js";
import { net } from "./net.js";
import { sfx, unlock } from "./sound.js";
import { S } from "./state.js";

const FILES = "abcdefgh";
document.head.append(h("style", {}, `.sq.via{box-shadow:inset 0 0 0 3px var(--warn)}
.cnt{display:flex;align-items:center;gap:5px;font-family:var(--mono);font-size:12px;color:var(--tx2);margin-top:2px}
.cnt i{display:inline-block;width:11px;height:11px;border-radius:50%;background:var(--pf);border:2px solid var(--ps)}`));

const parts = (m) => m.split(/[-:]/);
const idx = (s) => FILES.indexOf(s[0]) + 8 * (+s[1] - 1);
const name = (i) => FILES[i % 8] + (Math.floor(i / 8) + 1);
function disc(p) {
  const w = p === "w" || p === "W", k = p === "W" || p === "B";
  return `<svg class="pc ${w ? "pw" : "pb"}" viewBox="0 0 100 100"><circle cx="50" cy="52" r="39" style="fill:var(--pf);stroke:var(--ps);stroke-width:3.5"/><circle cx="50" cy="52" r="27" style="fill:none;stroke:var(--pd);stroke-width:2.4;opacity:.5"/>` +
    (k ? `<path d="M30 64 L33 40 L43 52 L50 36 L57 52 L67 40 L70 64 Z" style="fill:var(--pd);stroke:none"/>` : "") + "</svg>";
}

class CBoard {
  constructor() {
    this.flipped = false; this.pieces = new Map(); this.sqEl = new Map(); this.sel = null; this.path = []; this.legal = []; this.mine = null; this.on = false; this.last = null; this.str = null;
    this.sqs = h("div", { class: "sqs" }); this.pcs = h("div", { class: "pieces" });
    this.el = h("div", { class: "board" }, this.sqs, this.pcs);
    this.draw();
    this.el.addEventListener("pointerdown", (e) => { const s = this.sqAt(e); if (s) this.tap(s); });
  }
  draw() {
    this.sqs.innerHTML = ""; this.sqEl.clear();
    for (let y = 0; y < 8; y++) for (let x = 0; x < 8; x++) {
      const f = this.flipped ? 7 - x : x, r = this.flipped ? y : 7 - y, sq = FILES[f] + (r + 1);
      const el = h("div", { class: "sq" + ((f + r) % 2 === 0 ? " d" : "") });
      if (y === 7) el.append(h("span", { class: "co f" }, FILES[f]));
      if (x === 0) el.append(h("span", { class: "co r" }, String(r + 1)));
      this.sqEl.set(sq, el); this.sqs.append(el);
    }
  }
  xy(sq) { const f = FILES.indexOf(sq[0]), r = +sq[1] - 1; return this.flipped ? [7 - f, r] : [f, 7 - r]; }
  place(el, sq) { const [x, y] = this.xy(sq); el.style.transform = `translate(${x * 100}%,${y * 100}%)`; el.dataset.sq = sq; }
  mk(sq, p, anim) {
    const el = h("div", { class: "piece" + (anim ? " in" : "") }); el.innerHTML = disc(p); el.dataset.p = p; this.place(el, sq);
    this.pcs.append(el); this.pieces.set(sq, el); return el;
  }
  setPosition(str, last, intro) {
    clearTimeout(this.st); this.pcs.innerHTML = ""; this.pieces.clear();
    let n = 0;
    for (let i = 0; i < 64; i++) if (str[i] !== ".") { const el = this.mk(name(i), str[i], intro); if (intro) el.style.animationDelay = (n++ * 25) + "ms"; }
    this.str = str; this.setLast(last); this.clearSel();
  }
  sync(str) {
    for (const [sq, el] of [...this.pieces]) {
      if (el.dataset.sq !== sq) { this.pieces.delete(sq); continue; }  // eskirgan yozuv (koʻp qadamli yurishdan qolgan)
      if (str[idx(sq)] !== el.dataset.p) { el.remove(); this.pieces.delete(sq); }
    }
    for (let i = 0; i < 64; i++) if (str[i] !== "." && !this.pieces.has(name(i))) this.mk(name(i), str[i], true);
  }
  setLast(path) {
    if (this.last) this.last.forEach((s) => this.sqEl.get(s)?.classList.remove("last"));
    this.last = path ? [parts(path)[0], parts(path).slice(-1)[0]] : null;
    if (this.last) this.last.forEach((s) => this.sqEl.get(s)?.classList.add("last"));
  }
  burst(sq) {
    const b = h("div", { class: "burst" });
    for (let i = 0; i < 8; i++) b.append(h("i", { style: { "--a": i * 45 + "deg" } }));
    this.place(b, sq); this.pcs.append(b); setTimeout(() => b.remove(), 600);
  }
  applyMove(path, str) {
    const ps = parts(path), el = this.pieces.get(ps[0]), cap = path.includes(":");
    if (!el) { this.setPosition(str, path); return { capture: cap }; }
    this.pieces.delete(ps[0]); this.clearSel();
    let cur = ps[0];
    ps.slice(1).forEach((to, k) => setTimeout(() => {
      if (cap) {
        const a = idx(cur), b = idx(to), df = Math.sign(b % 8 - a % 8), dr = Math.sign(Math.floor(b / 8) - Math.floor(a / 8));
        for (let i = a + df + 8 * dr; i !== b; i += df + 8 * dr) {
          const v = this.pieces.get(name(i));
          if (v) { this.pieces.delete(name(i)); v.style.setProperty("--t", v.style.transform); v.classList.add("out"); setTimeout(() => v.remove(), 300); this.burst(name(i)); break; }
        }
      }
      this.pieces.delete(cur); this.pieces.set(to, el); this.place(el, to); cur = to;
    }, k * 280));
    this.setLast(path); this.str = str;
    clearTimeout(this.st); this.st = setTimeout(() => this.sync(str), (ps.length - 1) * 280 + 200);
    return { capture: cap };
  }
  settle(str) { this.str = str; clearTimeout(this.st); this.st = setTimeout(() => this.sync(str), 400); }
  setFlipped(f) {
    this.flipped = f; this.draw(); this.pieces.forEach((el, sq) => this.place(el, sq));
    const l = this.last; this.last = null; if (l) { this.last = l; l.forEach((s) => this.sqEl.get(s)?.classList.add("last")); }
    this.clearSel();
  }
  sqAt(e) {
    const b = this.el.getBoundingClientRect(), x = Math.floor((e.clientX - b.left) / b.width * 8), y = Math.floor((e.clientY - b.top) / b.height * 8);
    if (x < 0 || x > 7 || y < 0 || y > 7) return null;
    return FILES[this.flipped ? 7 - x : x] + ((this.flipped ? y : 7 - y) + 1);
  }
  setMine(c, on) { this.mine = c; this.on = !!on; if (!on) this.clearSel(); }
  setLegal(l) { this.legal = l || []; this.clearSel(); }
  clearSel() { this.sel = null; this.path = []; this.sqEl.forEach((e) => e.classList.remove("sel", "dot", "via")); }
  own(sq) { const el = this.pieces.get(sq); return el && el.dataset.p.toLowerCase() === this.mine && this.legal.some((m) => parts(m)[0] === sq); }
  hints() {
    this.sqEl.forEach((e) => e.classList.remove("dot", "via", "sel"));
    this.sqEl.get(this.sel)?.classList.add("sel");
    this.path.forEach((s) => this.sqEl.get(s)?.classList.add("via"));
    const cur = [this.sel, ...this.path];
    this.legal.forEach((m) => { const p = parts(m); if (cur.every((s, i) => p[i] === s) && p[cur.length]) this.sqEl.get(p[cur.length])?.classList.add("dot"); });
  }
  tap(sq) {
    if (!this.on) return;
    if (this.onTouch) this.onTouch();
    if (!this.sel) { if (this.own(sq)) { this.sel = sq; this.hints(); } return; }
    if (sq === this.sel && !this.path.length) { this.clearSel(); return; }
    const cur = [this.sel, ...this.path, sq];
    const c = this.legal.filter((m) => { const p = parts(m); return cur.every((s, i) => p[i] === s); });
    if (c.length) {
      const done = c.find((m) => parts(m).length === cur.length);
      if (done) { this.clearSel(); this.onMove && this.onMove(done); } else { this.path.push(sq); this.hints(); }
      return;
    }
    if (!this.path.length && this.own(sq)) { this.sel = sq; this.hints(); } else if (!this.path.length) this.clearSel();
  }
}

let G = null, B = null, recvAt = 0, flipped = false, ui = null, timer = null, overShown = false, optimistic = null, hooks = { leave() {} };
export const isActiveC = () => !!G && G.status === "active";
const other = (c) => (c === "w" ? "b" : "w");
function probe() { const p = h("div", { style: { position: "fixed", top: 0, visibility: "hidden", paddingTop: "var(--sat)", paddingBottom: "var(--sab)" } }); document.body.append(p); const v = p.offsetHeight; p.remove(); return v; }
function size() { document.documentElement.style.setProperty("--bs", Math.max(220, Math.floor(Math.min(window.innerWidth - 16, window.innerHeight - probe() - 330, 560))) + "px"); }
function bar() { const clock = h("div", { class: "clock" }, "--"), info = h("div", { class: "info" }), av = h("div"); return { el: h("div", { class: "pbar" }, av, info, clock), clock, info, av }; }
function fillBar(b, p) { b.av.replaceWith(b.av = avatar(p)); b.info.innerHTML = ""; b.cnt = h("div", { class: "cnt" }); b.info.append(nameEl(p), b.cnt); }
function counts() {
  const s = G.fen.split(" ")[0], n = { w: 0, b: 0 };
  for (const ch of s) if (ch.toLowerCase() === "w") n.w++; else if (ch.toLowerCase() === "b") n.b++;
  ["w", "b"].forEach((c) => { const b = ui.bars[c]; b.cnt.innerHTML = ""; b.cnt.append(h("i", { class: c === "w" ? "pw pc" : "pb pc" }), String(n[c])); });
}
function moves() {
  ui.moves.innerHTML = "";
  G.sans.forEach((s, i) => { if (i % 2 === 0) ui.moves.append(h("span", { class: "n" }, i / 2 + 1 + ".")); ui.moves.append(h("span", i === G.sans.length - 1 ? { class: "cur" } : {}, s)); });
  ui.moves.scrollLeft = ui.moves.scrollWidth;
}
function clockMs(c) { let ms = G.clocks[c]; if (G.status === "active" && G.tc.base > 0 && G.ply >= 2 && G.turn === c) ms -= performance.now() - recvAt; return ms; }
function tick() {
  if (!G || !ui) return;
  const me = G.you || "w", opp = other(me), now = G.ts + (performance.now() - recvAt);
  for (const c of ["w", "b"]) {
    const b = ui.bars[c], ms = clockMs(c), act = G.status === "active" && G.turn === c;
    b.clock.textContent = G.tc.base > 0 ? fmtClock(ms) : "∞"; b.clock.classList.toggle("run", act);
    b.clock.classList.toggle("low", G.tc.base > 0 && G.ply >= 2 && act && ms < 10000); b.el.classList.toggle("turn", act);
  }
  let msg = "";
  if (G.status === "active") {
    if (S.offline) { const r = S.cfg.reconnect, win = G.tc.base ? Math.max(r.min, r.frac * G.tc.base) : r.unl; msg = t("youAway", { t: fmtDur(win - (Date.now() - S.offlineSince) / 1000) }); }
    else if (G.away[opp]) msg = t("oppAway", { t: fmtDur((G.away[opp] - now) / 1000) });
    else if (G.draw_by === me) msg = t("drawSent");
    else if (G.turn === me) msg = G.legal.some((m) => m.includes(":")) ? t("mustCapture") : t("yourTurn");
  }
  if (ui.bannerText.textContent !== msg) ui.bannerText.textContent = msg;
  ui.drawBox.hidden = !(G.status === "active" && G.draw_by === opp);
}
function swap() { const bot = flipped ? "b" : "w"; ui.root.insertBefore(ui.bars[other(bot)].el, B.el); ui.root.insertBefore(ui.bars[bot].el, ui.moves); }
function send(m) {
  unlock(); if (!isActiveC() || G.turn !== G.you) return;
  optimistic = m; const r = B.applyMove(m, null); B.setMine(G.you, false); B.setLegal([]);
  sfx[r.capture ? "capture" : "move"](); haptic.tap(); net.send({ t: "move", gid: G.id, uci: m });
}
function mount(st) {
  document.body.classList.add("ingame");
  const sc = $("#screen"); sc.className = "nopad"; sc.innerHTML = "";
  const me = st.you || "w"; flipped = me === "b"; overShown = false;
  B = new CBoard(); B.onMove = send; B.onTouch = unlock; B.setFlipped(flipped);
  ui = { bars: { w: bar(), b: bar() } }; fillBar(ui.bars.w, st.players.w); fillBar(ui.bars.b, st.players.b);
  ui.moves = h("div", { class: "moves" }); ui.bannerText = h("span");
  ui.drawBox = h("span", { hidden: true }, " ", h("button", { class: "chip on", onclick: () => net.send({ t: "draw_accept", gid: G.id }) }, "✓ " + t("accept")), " ",
    h("button", { class: "chip", onclick: () => net.send({ t: "draw_decline", gid: G.id }) }, "✕ " + t("decline")));
  ui.act = h("div", { class: "gact" },
    h("button", { class: "btn sec", onclick: () => { flipped = !flipped; B.setFlipped(flipped); swap(); } }, "⟲ " + t("flip")),
    h("button", { class: "btn sec", onclick: async () => { if (await confirmBox(t("resignQ"))) net.send({ t: "resign", gid: G.id }); } }, "🏳 " + t("resign")),
    h("button", { class: "btn sec", onclick: () => net.send({ t: "draw_offer", gid: G.id }) }, "½ " + t("draw")));
  ui.root = h("div", { class: "game" });
  const bot = flipped ? "b" : "w";
  ui.root.append(ui.bars[other(bot)].el, B.el, ui.bars[bot].el, ui.moves, h("div", { class: "banner" }, ui.bannerText, ui.drawBox), ui.act);
  sc.append(ui.root); size(); G = st; recvAt = performance.now();
  B.setPosition(st.fen.split(" ")[0], st.moves.length ? st.moves[st.moves.length - 1] : null, true);
  B.setMine(me, st.status === "active" && st.turn === me); B.setLegal(st.legal);
  counts(); moves(); sfx.start();
  try { tg && tg.enableClosingConfirmation(); } catch (e) {}
  clearInterval(timer); timer = setInterval(tick, 100); tick();
}
function update(st, mv) {
  const prev = G; G = st; recvAt = performance.now();
  const me = st.you || "w", last = st.moves.length ? st.moves[st.moves.length - 1] : null, str = st.fen.split(" ")[0];
  if (st.ply === prev.ply + 1 && last) {
    if (optimistic && optimistic === last) B.settle(str); else { const r = B.applyMove(last, str); sfx[r.capture ? "capture" : "move"](); haptic.tap(); }
  } else if (st.ply !== prev.ply || optimistic) B.setPosition(str, last);
  optimistic = null;
  B.setMine(me, st.status === "active" && st.turn === me); B.setLegal(st.legal); counts(); moves(); tick();
}
function leaveC() {
  clearInterval(timer); G = null; B = null; ui = null; document.body.classList.remove("ingame");
  try { tg && tg.disableClosingConfirmation(); } catch (e) {}
  hooks.leave();
}
function result(m) {
  const me = G.you, r = G.result, won = (r === "1-0" && me === "w") || (r === "0-1" && me === "b");
  const kind = m.aborted || !r ? "ab" : r === "1/2-1/2" ? "d" : won ? "w" : "l";
  sfx[{ w: "win", l: "lose", d: "draw", ab: "draw" }[kind]](); (kind === "w" ? haptic.ok : kind === "l" ? haptic.err : haptic.warn)();
  const body = h("div", { class: "stack" }, h("div", { class: "res-ic" }, { w: "🏆", l: "💔", d: "🤝", ab: "⛔" }[kind]),
    h("h1", {}, { w: t("win"), l: t("lose"), d: t("drawn"), ab: t("aborted") }[kind]), h("div", { class: "sub" }, t("r_" + (G.reason || "aborted"))));
  const sh = sheet(body, { center: true });
  body.append(h("button", { class: "btn block", onclick: () => { sh.close(); leaveC(); } }, t("playAgain")), h("button", { class: "btn sec block", onclick: () => { sh.close(); endActions(); } }, t("close")));
}
function endActions() { if (!ui) return; ui.act.innerHTML = ""; ui.act.append(h("button", { class: "btn", onclick: () => leaveC() }, t("playAgain"))); }
export function openCheckers(st) { if (!st) return; if (!G || G.id !== st.id || !ui || !ui.root.isConnected) mount(st); else update(st, null); }
export function bindCheckers(hk) {
  hooks = hk;
  net.on("game", (m) => {
    if (!m.g) { if (G && ui) leaveC(); return; }
    if (m.g.kind !== "checkers") return;
    openCheckers(m.g);
  });
  net.on("over", (m) => {
    if (!G || !ui || !m.g || m.g.kind !== "checkers" || G.id !== m.g.id) return;
    const st = m.g, prev = G, str = st.fen.split(" ")[0];
    if (st.ply === prev.ply + 1) { const r = B.applyMove(st.moves[st.moves.length - 1], str); sfx[r.capture ? "capture" : "move"](); }
    G = st; recvAt = performance.now(); B.setMine(G.you, false); B.setLegal([]); counts(); moves(); tick();
    if (overShown) return; overShown = true;
    setTimeout(() => { if (ui) { result(m); endActions(); } }, 700);
  });
  net.on("draw_declined", () => { if (G) toast(t("drawDeclined")); });
  window.addEventListener("resize", () => { if (ui) size(); });
}
