"""Bitta partiya: qoidalar (python-chess), soat, durang/taslim, ulanish uzilishi muddatlari."""
import time

import chess

import config

W, B = chess.WHITE, chess.BLACK


def cs(color):
    return "w" if color == W else "b"


def sc(s):
    return W if s == "w" else B


def away_window_sec(base_ms):
    if base_ms <= 0:
        return config.RECONNECT_UNLIMITED_SEC
    return max(config.RECONNECT_MIN_SEC, config.RECONNECT_FRACTION * base_ms / 1000.0)


class Game:
    def __init__(self, gid, kind, white, black, base_ms, inc_ms, rated, bot_level=None):
        self.id = gid
        self.kind = kind            # 'pvp' | 'bot'
        self.white = white          # uid yoki None (bot)
        self.black = black
        self.base_ms = base_ms
        self.inc_ms = inc_ms
        self.rated = rated
        self.bot_level = bot_level
        self.board = chess.Board()
        self.moves = []
        self.sans = []
        self.clock = {W: base_ms, B: base_ms}
        self.turn_started = time.monotonic()
        self.started_at = int(time.time())
        self.status = "active"
        self.result = None
        self.reason = None
        self.draw_by = None          # kim taklif qildi (True/False) yoki None
        self.can_offer = {W: True, B: True}
        self.away = {W: None, B: None}   # wall-time (s) muddati
        self.away_since = {W: None, B: None}
        self.bot_thinking = False

    # ---- yordamchilar ----
    @property
    def ply(self):
        return len(self.moves)

    @property
    def turn(self):
        return self.board.turn

    @property
    def timed(self):
        return self.base_ms > 0

    def uid_of(self, color):
        return self.white if color == W else self.black

    def color_of(self, uid):
        if uid is not None and self.white == uid:
            return W
        if uid is not None and self.black == uid:
            return B
        return None

    def is_bot(self, color):
        return self.uid_of(color) is None

    def _ticking(self):
        return self.status == "active" and self.timed and self.ply >= 2

    def clock_now(self, color, mono=None):
        mono = time.monotonic() if mono is None else mono
        ms = self.clock[color]
        if self._ticking() and self.board.turn == color:
            ms -= (mono - self.turn_started) * 1000.0
        return max(0, int(ms))

    # ---- harakatlar ----
    def _flag_result(self, loser):
        winner = not loser
        if self.board.has_insufficient_material(winner):
            return "1/2-1/2", "timeout_insufficient"
        return ("0-1" if loser == W else "1-0"), "timeout"

    def play(self, color, uci, mono=None):
        """Yurishni qo'llaydi. Qaytaradi: None (davom) yoki (result, reason). ValueError: noqonuniy."""
        mono = time.monotonic() if mono is None else mono
        if self.status != "active" or self.board.turn != color:
            raise ValueError("not_your_turn")
        try:
            mv = chess.Move.from_uci(uci)
        except ValueError:
            raise ValueError("bad_move")
        if mv not in self.board.legal_moves:
            raise ValueError("illegal")
        first = self.ply < 2
        if self._ticking():
            left = self.clock[color] - (mono - self.turn_started) * 1000.0
            if left <= 0:
                self.clock[color] = 0
                return self._flag_result(color)
            self.clock[color] = int(left) + self.inc_ms
        san = self.board.san(mv)
        self.board.push(mv)
        self.moves.append(mv.uci())
        self.sans.append(san)
        self.turn_started = mono
        self.can_offer[color] = True
        if self.draw_by is not None and self.draw_by != color:
            self.draw_by = None  # raqib yurdi = taklif rad etildi
        out = self.board.outcome()
        if out is not None:
            t = out.termination.name
            reason = {"CHECKMATE": "checkmate", "STALEMATE": "stalemate", "INSUFFICIENT_MATERIAL": "insufficient",
                      "SEVENTYFIVE_MOVES": "seventyfive", "FIVEFOLD_REPETITION": "repetition"}.get(t, "draw")
            res = "1/2-1/2" if out.winner is None else ("1-0" if out.winner == W else "0-1")
            return res, reason
        return None

    def undo_bot(self, human):
        """Botga qarshi o'yinda inson navbatiga qaytaradi (bot yurgan bo'lsa 2 ta, o'ylayotgan bo'lsa 1 ta yarim-yurish)."""
        if self.status != "active" or self.kind != "bot":
            return False
        n = 1 if self.board.turn != human else 2
        if self.ply < n:
            return False
        for _ in range(n):
            self.board.pop()
            self.moves.pop()
            self.sans.pop()
        self.draw_by = None
        self.can_offer = {W: True, B: True}
        self.turn_started = time.monotonic()
        self.ver = getattr(self, "ver", 0) + 1
        self.undos = getattr(self, "undos", 0) + 1
        return True

    def resign(self, color):
        if self.ply < config.ABORT_BEFORE_PLY:
            return None, "aborted"
        return ("0-1" if color == W else "1-0"), "resign"

    def offer_draw(self, color):
        """'claimed' (result tuple bilan), 'offered' yoki 'no'."""
        if self.status != "active" or self.ply < 2:
            return "no", None
        if self.board.can_claim_draw():
            return "claimed", ("1/2-1/2", "claim")
        if not self.can_offer[color] or self.draw_by is not None:
            return "no", None
        self.draw_by = color
        self.can_offer[color] = False
        return "offered", None

    def check(self, wall=None, mono=None):
        """Davriy tekshiruv. Tugagan bo'lsa (result, reason) qaytaradi."""
        if self.status != "active":
            return None
        wall = time.time() if wall is None else wall
        mono = time.monotonic() if mono is None else mono
        if self.ply < config.ABORT_BEFORE_PLY and mono - self.turn_started > config.FIRST_MOVE_TIMEOUT_SEC:
            return None, "aborted"
        if self._ticking() and self.clock_now(self.board.turn, mono) <= 0:
            return self._flag_result(self.board.turn)
        if (not self.timed) and config.UNLIMITED_IDLE_SEC > 0 and self.ply >= 2 and \
                mono - self.turn_started > config.UNLIMITED_IDLE_SEC:
            return ("0-1" if self.board.turn == W else "1-0"), "abandon"
        cand = [(self.away[c], c) for c in (W, B) if self.away[c] is not None and self.away[c] <= wall]
        if cand:
            cand.sort()
            loser = cand[0][1]
            if self.ply < config.ABORT_BEFORE_PLY:
                return None, "aborted"
            return ("0-1" if loser == W else "1-0"), "abandon"
        return None

    def set_away(self, color, is_away, wall=None):
        wall = time.time() if wall is None else wall
        if is_away:
            if self.away[color] is None:
                self.away[color] = wall + away_window_sec(self.base_ms)
        else:
            self.away[color] = None

    # ---- serializatsiya ----
    def legal(self):
        return [m.uci() for m in self.board.legal_moves] if self.status == "active" else []

    def core_state(self):
        return {
            "id": self.id, "kind": self.kind, "rated": self.rated, "bot": self.bot_level,
            "tc": {"base": self.base_ms // 1000, "inc": self.inc_ms // 1000},
            "fen": self.board.fen(), "moves": self.moves, "sans": self.sans,
            "turn": cs(self.board.turn), "ply": self.ply, "status": self.status,
            "result": self.result, "reason": self.reason,
            "clocks": {"w": self.clock_now(W), "b": self.clock_now(B)},
            "ts": int(time.time() * 1000),
            "draw_by": cs(self.draw_by) if self.draw_by is not None else None,
            "check": self.board.is_check(),
            "away": {"w": int(self.away[W] * 1000) if self.away[W] else None,
                     "b": int(self.away[B] * 1000) if self.away[B] else None},
        }

    def dump(self):
        return {"id": self.id, "kind": self.kind, "white": self.white, "black": self.black, "base": self.base_ms,
                "inc": self.inc_ms, "rated": self.rated, "bot": self.bot_level, "moves": self.moves,
                "cw": self.clock[W], "cb": self.clock[B], "started": self.started_at}

    @classmethod
    def load(cls, d):
        g = cls(d["id"], d["kind"], d["white"], d["black"], d["base"], d["inc"], d["rated"], d.get("bot"))
        for u in d["moves"]:
            mv = chess.Move.from_uci(u)
            g.sans.append(g.board.san(mv))
            g.board.push(mv)
            g.moves.append(u)
        g.clock = {W: d["cw"], B: d["cb"]}
        g.started_at = d.get("started", g.started_at)
        g.turn_started = time.monotonic()
        return g
