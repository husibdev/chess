"""Elo, hafta chegaralari, nishonlar (badge) mantig'i."""
import datetime as dt
import config

TZ = dt.timezone(dt.timedelta(hours=config.TZ_OFFSET_HOURS))


def expected(ra, rb):
    return 1.0 / (1.0 + 10 ** ((rb - ra) / 400.0))


def elo_delta(ra, rb, score_a):
    """A uchun o'zgarish (B uchun teskari ishora)."""
    return int(round(config.K_FACTOR * (score_a - expected(ra, rb))))


def week_start(ts=None):
    """Joriy haftaning boshlanishi (UTC epoch), dushanba 00:00 GMT+5."""
    now = dt.datetime.fromtimestamp(ts if ts is not None else dt.datetime.now(dt.timezone.utc).timestamp(), TZ)
    monday = (now - dt.timedelta(days=now.weekday())).replace(hour=0, minute=0, second=0, microsecond=0)
    return int(monday.timestamp())


WEEK = 7 * 86400

# kod -> (shart tavsifi) — matn tarjimalari frontendda
BADGES = [
    "first_win", "wins_10", "wins_50", "wins_100", "games_10", "games_100",
    "streak_3", "streak_5", "streak_10", "rating_1400", "rating_1600", "rating_1800",
    "rating_2000", "beat_hard", "beat_max", "quick_mate", "week_top10", "week_champion",
]


def evaluate_badges(user, extra):
    """user: dict (yangilangan statistika). extra: {'bot_beaten': level|None, 'mate_moves': int|None}.
    Qaytaradi: shu holatda egalik qilinishi kerak bo'lgan kodlar to'plami."""
    s = set()
    w, g = user["wins"], user["rated_games"]
    if w >= 1:
        s.add("first_win")
    for n in (10, 50, 100):
        if w >= n:
            s.add(f"wins_{n}")
    for n in (10, 100):
        if g >= n:
            s.add(f"games_{n}")
    for n in (3, 5, 10):
        if user["best_streak"] >= n:
            s.add(f"streak_{n}")
    for n in (1400, 1600, 1800, 2000):
        if user["best_rating"] >= n:
            s.add(f"rating_{n}")
    if extra.get("bot_beaten") in ("hard", "hard_extra", "hard_max", "expert"):
        s.add("beat_hard")
    if extra.get("bot_beaten") == "expert":
        s.add("beat_max")
    if extra.get("mate_moves") and extra["mate_moves"] <= 20:
        s.add("quick_mate")
    return s
