"""Telegram Bot API (long polling) — ro'yxatdan o'tish (kontakt ulashish) va Mini App tugmalari."""
import asyncio
import logging

import aiohttp

import admin
import config
import db
import subscribe

import inline

log = logging.getLogger("bot")

T = {
    "en": {
        "share": "📱 Share my contact",
        "ask": "Welcome to Chess! ♟\nTo start playing, please share your Telegram contact with the button below. This is required once.",
        "thanks": "✅ Registered! Tap the button below to play.",
        "play": "♟ Play chess",
        "join": "🤝 Join the game",
        "invite": "You've been invited to a chess game! Tap the button to join.",
        "foreign": "Please share your own contact using the button.",
        "help": "Tap ♟ Play chess to open the game. /lang changes the language.",
        "lang": "Choose language:",
        "langset": "Language saved ✅",
        "nourl": "The game server is starting, please try again in a minute.",
    },
    "uz": {
        "share": "📱 Kontaktimni ulashish",
        "ask": "Shaxmatga xush kelibsiz! ♟\nO‘ynashni boshlash uchun pastdagi tugma orqali Telegram kontaktingizni ulashing. Bu faqat bir marta talab qilinadi.",
        "thanks": "✅ Ro‘yxatdan o‘tdingiz! O‘ynash uchun pastdagi tugmani bosing.",
        "play": "♟ Shaxmat o‘ynash",
        "join": "🤝 O‘yinga qo‘shilish",
        "invite": "Sizni shaxmat o‘yiniga taklif qilishdi! Qo‘shilish uchun tugmani bosing.",
        "foreign": "Iltimos, tugma orqali o‘zingizning kontaktingizni ulashing.",
        "help": "O‘yinni ochish uchun ♟ Shaxmat o‘ynash tugmasini bosing. Tilni /lang bilan o‘zgartiring.",
        "lang": "Tilni tanlang:",
        "langset": "Til saqlandi ✅",
        "nourl": "O‘yin serveri ishga tushmoqda, bir daqiqadan so‘ng qayta urinib ko‘ring.",
    },
    "ru": {
        "share": "📱 Поделиться контактом",
        "ask": "Добро пожаловать в шахматы! ♟\nЧтобы начать играть, поделитесь своим контактом Telegram кнопкой ниже. Это нужно один раз.",
        "thanks": "✅ Вы зарегистрированы! Нажмите кнопку ниже, чтобы играть.",
        "play": "♟ Играть в шахматы",
        "join": "🤝 Присоединиться к игре",
        "invite": "Вас пригласили на партию в шахматы! Нажмите кнопку, чтобы присоединиться.",
        "foreign": "Пожалуйста, поделитесь своим контактом с помощью кнопки.",
        "help": "Нажмите ♟ Играть в шахматы, чтобы открыть игру. Язык: /lang.",
        "lang": "Выберите язык:",
        "langset": "Язык сохранён ✅",
        "nourl": "Игровой сервер запускается, попробуйте через минуту.",
    },
}


class Bot:
    def __init__(self, session):
        self.s = session
        self.base = f"https://api.telegram.org/bot{config.BOT_TOKEN}/"
        self.username = ""
        self.webapp_url = config.WEBAPP_URL
        self.offset = 0

    async def call(self, method, **params):
        try:
            async with self.s.post(self.base + method, json=params, timeout=aiohttp.ClientTimeout(total=70)) as r:
                data = await r.json()
        except Exception as e:  # noqa
            log.warning("%s: %s", method, e)
            return None
        if not data.get("ok"):
            log.warning("%s xato: %s", method, data.get("description"))
            return None
        return data["result"]

    async def setup(self):
        me = await self.call("getMe")
        if not me:
            raise RuntimeError("BOT_TOKEN noto'g'ri yoki Telegramga ulanib bo'lmadi")
        self.username = me["username"]
        inline.B = self
        await self.call("deleteWebhook")
        await self.call("setMyCommands", commands=[{"command": "play", "description": "♟ Play / O‘ynash / Играть"},
                                                   {"command": "lang", "description": "🌐 Language / Til / Язык"},
                                                   {"command": "help", "description": "Help"}])
        await self.set_menu()

    async def set_menu(self):
        if self.webapp_url:
            await self.call("setChatMenuButton", menu_button={"type": "web_app", "text": "♟ Play",
                                                              "web_app": {"url": self.webapp_url}})

    def lang(self, uid, tg_user=None):
        u = db.get_user(uid)
        if u and u.get("lang") in T:
            return u["lang"]
        code = ((tg_user or {}).get("language_code") or "en")[:2]
        return code if code in ("uz", "ru") else "en"

    async def play_button(self, chat_id, lang, text, payload=None):
        if not self.webapp_url:
            return await self.call("sendMessage", chat_id=chat_id, text=T[lang]["nourl"])
        url = self.webapp_url + ("/?ch=" + payload[3:] if payload and payload.startswith("ch_") else "/?inv=" + payload if payload and payload[:3] in ("ic_", "ik_") else "")
        label = T[lang]["join"] if payload and payload[:3] in ("ch_", "ic_", "ik_") else T[lang]["play"]
        await self.call("sendMessage", chat_id=chat_id, text=text,
                        reply_markup={"inline_keyboard": [[{"text": label, "web_app": {"url": url}}]]})

    async def handle(self, upd):
        if await admin.handle(upd):
            return
        if await inline.handle(self, upd):
            return
        if await subscribe.handle(self, upd):
            return
        if "callback_query" in upd:
            cq = upd["callback_query"]
            data = cq.get("data", "")
            uid = cq["from"]["id"]
            if data.startswith("lang:"):
                db.upsert_profile(uid, cq["from"].get("first_name", ""), cq["from"].get("last_name", ""), cq["from"].get("username", ""))
                db.set_lang(uid, data[5:])
                await self.call("answerCallbackQuery", callback_query_id=cq["id"], text=T[self.lang(uid)]["langset"])
            return
        m = upd.get("message")
        if not m or "from" not in m:
            return
        f, chat = m["from"], m["chat"]["id"]
        uid = f["id"]
        if chat != uid:
            return  # faqat shaxsiy chat
        db.upsert_profile(uid, f.get("first_name", ""), f.get("last_name", ""), f.get("username", ""))
        u = db.get_user(uid)
        if u["lang"] == "en" and (f.get("language_code") or "")[:2] in ("uz", "ru") and u["registered_at"] is None:
            db.set_lang(uid, f["language_code"][:2])
        lang = self.lang(uid, f)
        if "contact" in m:
            c = m["contact"]
            if c.get("user_id") != uid:
                return await self.call("sendMessage", chat_id=chat, text=T[lang]["foreign"])
            db.set_phone(uid, c["phone_number"])
            await admin.notify_new(uid)
            row = db.conn.execute("SELECT payload FROM pending WHERE user_id=?", (uid,)).fetchone()
            payload = row["payload"] if row else None
            db.conn.execute("DELETE FROM pending WHERE user_id=?", (uid,))
            await self.call("sendMessage", chat_id=chat, text="✅", reply_markup={"remove_keyboard": True})
            return await self.play_button(chat, lang, T[lang]["thanks"], payload)
        text = (m.get("text") or "").strip()
        payload = None
        if text.startswith("/start"):
            parts = text.split(maxsplit=1)
            payload = parts[1] if len(parts) > 1 else None
        if text.startswith("/lang"):
            return await self.call("sendMessage", chat_id=chat, text=T[lang]["lang"], reply_markup={"inline_keyboard": [[
                {"text": "🇬🇧 English", "callback_data": "lang:en"}, {"text": "🇺🇿 Oʻzbekcha", "callback_data": "lang:uz"},
                {"text": "🇷🇺 Русский", "callback_data": "lang:ru"}]]})
        if text.startswith("/help"):
            return await self.call("sendMessage", chat_id=chat, text=T[lang]["help"])
        if not db.is_registered(u):
            if payload:
                db.conn.execute("INSERT OR REPLACE INTO pending VALUES(?,?)", (uid, payload))
            return await self.call("sendMessage", chat_id=chat, text=T[lang]["ask"], reply_markup={
                "keyboard": [[{"text": T[lang]["share"], "request_contact": True}]], "resize_keyboard": True, "one_time_keyboard": True})
        if payload and payload[:3] in ("ch_", "ic_", "ik_"):
            return await self.play_button(chat, lang, T[lang]["invite"], payload)
        await self.play_button(chat, lang, T[lang]["play"] + " ⬇️")

    async def poll(self):
        backoff = 1
        while True:
            try:
                async with self.s.post(self.base + "getUpdates", json={"timeout": 50, "offset": self.offset,
                                                                      "allowed_updates": ["message", "callback_query", "chat_member", "inline_query", "chosen_inline_result"]},
                                       timeout=aiohttp.ClientTimeout(total=70)) as r:
                    data = await r.json()
                backoff = 1
                for upd in data.get("result", []):
                    self.offset = upd["update_id"] + 1
                    try:
                        await self.handle(upd)
                    except Exception:  # noqa
                        log.exception("update xatosi")
            except asyncio.CancelledError:
                raise
            except Exception as e:  # noqa
                log.warning("polling: %s", e)
                await asyncio.sleep(backoff)
                backoff = min(30, backoff * 2)
