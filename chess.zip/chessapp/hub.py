"""Markaziy markaz: WebSocket ulanishlar, matchmaking, takliflar, partiyalar, soat tekshiruvi, natijalar."""
import asyncio
import json
import logging
import random
import secrets
import time

import aiohttp
from aiohttp import web
import chess

import config
import admin
import checkers
import db
import rating as R
import subscribe
from game import Game, W, B, cs, sc, away_window_sec
from tgauth import validate_init_data

import inline

log = logging.getLogger("hub")
ALNUM = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"


class Conn:
    __slots__ = ("ws", "uid", "visible", "tokens", "ts")

    def __init__(self, ws, uid):
        self.ws, self.uid, self.visible = ws, uid, True
        self.tokens, self.ts = 30.0, time.monotonic()


def parse_tc(tc):
    try:
        base, inc = int(tc.get("base", 0)), int(tc.get("inc", 0))
    except (TypeError, ValueError, AttributeError):
        return None
    if base == 0:
        return (0, 0)
    if base < 60 or base > config.MAX_BASE_SEC or inc < 0 or inc > config.MAX_INC_SEC:
        return None
    return (base, inc)


class Hub:
    def __init__(self, engine, bot_info):
        self.engine = engine
        self.bot_info = bot_info      # {'username': ...}
        self.conns = {}               # uid -> [Conn]
        self.games = {}               # gid -> Game
        self.user_game = {}           # uid -> gid
        self.queue = {}               # uid -> dict
        self.challenges = {}          # code -> dict
        self._tasks = set()
        self._champ_cache = (0, 0, {})
        self.analysis_jobs = {}

    # ---------- yordamchilar ----------
    def spawn(self, coro):
        t = asyncio.ensure_future(coro)
        self._tasks.add(t)
        t.add_done_callback(self._tasks.discard)
        return t

    async def _send(self, ws, obj):
        try:
            await ws.send_str(json.dumps(obj, separators=(",", ":"), ensure_ascii=False))
        except Exception:  # noqa
            pass

    def send_user(self, uid, obj):
        for c in list(self.conns.get(uid, [])):
            self.spawn(self._send(c.ws, obj))

    def champs(self):
        prev = R.week_start() - R.WEEK
        now = time.time()
        if self._champ_cache[0] == prev and now - self._champ_cache[1] < 60:
            return self._champ_cache[2]
        db.finalize_week(prev)
        ch = db.champions(prev)
        self._champ_cache = (prev, now, ch)
        return ch

    def me_payload(self, uid):
        u = db.get_user(uid)
        p = db.public_user(u, self.champs())
        p["rank"] = db.career_rank(u)
        p["lang"] = u["lang"]
        return p

    def cfg(self):
        return {"presets": config.PRESETS, "levels": {k: v["disp"] for k, v in config.BOT_LEVELS.items()},
                "bot": self.bot_info.get("username", ""), "app": config.APP_SHORT_NAME,
                "engine": self.engine.available, "engine_name": self.engine.name,
                "reconnect": {"frac": config.RECONNECT_FRACTION, "unl": config.RECONNECT_UNLIMITED_SEC, "min": config.RECONNECT_MIN_SEC},
                "maxBase": config.MAX_BASE_SEC, "maxInc": config.MAX_INC_SEC}

    def player_info(self, g, color):
        uid = g.uid_of(color)
        if uid is None:
            lv = config.norm_level(g.bot_level)
            return {"id": 0, "name": "Stockfish", "bot": True, "level": lv, "rating": config.BOT_LEVELS[lv]["disp"], "champ": 0, "photo": ""}
        return db.public_user(db.get_user(uid), self.champs())

    def state_for(self, g, uid):
        s = g.core_state()
        s["players"] = {"w": self.player_info(g, W), "b": self.player_info(g, B)}
        c = g.color_of(uid)
        s["you"] = cs(c) if c is not None else None
        s["legal"] = g.legal() if (c is not None and g.board.turn == c) else []
        return s

    def push_game(self, g, mv=None, only=None):
        for c in (W, B):
            uid = g.uid_of(c)
            if uid is None or (only is not None and uid != only):
                continue
            self.send_user(uid, {"t": "game", "g": self.state_for(g, uid), "mv": mv})

    def persist(self, g):
        if g.status == "active":
            db.live_save(g.id, g.dump())

    # ---------- ulanish ----------
    async def handle_ws(self, request):
        ws = web.WebSocketResponse(heartbeat=15, max_msg_size=16384)
        await ws.prepare(request)
        conn = None
        try:
            msg = await ws.receive(timeout=15)
            if msg.type != aiohttp.WSMsgType.TEXT:
                return ws
            hello = json.loads(msg.data)
            tg = self.auth(hello.get("init", ""))
            if not tg:
                await self._send(ws, {"t": "hello_err", "code": "bad_init"})
                return ws
            user = tg["user"]
            uid = int(user["id"])
            if admin.is_banned(uid):
                await self._send(ws, {"t": "hello_err", "code": "banned"})
                return ws
            lang = (user.get("language_code") or "en")[:2]
            db.upsert_profile(uid, user.get("first_name", ""), user.get("last_name", ""), user.get("username", ""),
                              user.get("photo_url", ""), lang if lang in ("uz", "ru") else "en")
            if config.DEV_MODE and not db.is_registered(db.get_user(uid)):
                db.set_phone(uid, "dev")
            if not db.is_registered(db.get_user(uid)):
                await self._send(ws, {"t": "hello_err", "code": "not_registered"})
                return ws
            if not await subscribe.ok(uid):
                await self._send(ws, {"t": "hello_err", "code": "not_subscribed", "channels": subscribe.public_channels()})
                return ws
            if hello.get("lang") in ("en", "uz", "ru"):
                db.set_lang(uid, hello["lang"])
            conn = Conn(ws, uid)
            self.conns.setdefault(uid, []).append(conn)
            gid = self.user_game.get(uid)
            g = self.games.get(gid) if gid else None
            await self._send(ws, {"t": "hello_ok", "me": self.me_payload(uid), "cfg": self.cfg(),
                                  "game": self.state_for(g, uid) if g else None,
                                  "week": {"start": R.week_start(), "end": R.week_start() + R.WEEK},
                                  "start_param": tg.get("start_param"), "now": int(time.time() * 1000)})
            self.refresh_presence(uid)
            async for m in ws:
                if m.type != aiohttp.WSMsgType.TEXT:
                    if m.type in (aiohttp.WSMsgType.ERROR, aiohttp.WSMsgType.CLOSE):
                        break
                    continue
                now = time.monotonic()
                conn.tokens = min(30.0, conn.tokens + (now - conn.ts) * 15)
                conn.ts = now
                if conn.tokens < 1:
                    continue
                conn.tokens -= 1
                try:
                    await self.dispatch(conn, json.loads(m.data))
                except Exception:  # noqa
                    log.exception("dispatch xatosi")
        except asyncio.TimeoutError:
            pass
        except Exception:  # noqa
            log.exception("ws xatosi")
        finally:
            if conn:
                lst = self.conns.get(conn.uid, [])
                if conn in lst:
                    lst.remove(conn)
                if not lst:
                    self.conns.pop(conn.uid, None)
                    self.queue.pop(conn.uid, None)
                    self.drop_challenges(conn.uid)
                self.refresh_presence(conn.uid)
        return ws

    def auth(self, init):
        if config.DEV_MODE and isinstance(init, str) and init.startswith("dev:"):
            parts = init.split(":", 2)
            try:
                return {"user": {"id": int(parts[1]), "first_name": parts[2] if len(parts) > 2 else "Dev"}, "start_param": None}
            except ValueError:
                return None
        return validate_init_data(init, config.BOT_TOKEN, config.INITDATA_MAX_AGE)

    def refresh_presence(self, uid):
        gid = self.user_game.get(uid)
        g = self.games.get(gid) if gid else None
        if not g:
            return
        c = g.color_of(uid)
        present = any(x.visible for x in self.conns.get(uid, []))
        was = g.away[c] is not None
        g.set_away(c, not present)
        if was != (not present):
            self.push_game(g)

    # ---------- xabarlar ----------
    async def dispatch(self, conn, m):
        t, uid = m.get("t"), conn.uid
        err = admin.gate(uid, t)
        if err:
            return self.send_user(uid, {"t": "err", "code": err})
        if t == "ping":
            return await self._send(conn.ws, {"t": "pong"})
        if t == "vis":
            conn.visible = bool(m.get("v"))
            return self.refresh_presence(uid)
        if t == "lang":
            return db.set_lang(uid, m.get("lang"))
        if t == "sync":
            g = self.games.get(self.user_game.get(uid))
            return await self._send(conn.ws, {"t": "game", "g": self.state_for(g, uid) if g else None, "mv": None})
        if t == "queue":
            return await self.queue_join(uid, m)
        if t == "queue_cancel":
            self.queue.pop(uid, None)
            return self.send_user(uid, {"t": "queue_off"})
        if t == "challenge_create":
            return await self.challenge_create(uid, m)
        if t == "challenge_cancel":
            self.drop_challenges(uid)
            return self.send_user(uid, {"t": "challenge_off"})
        if t == "challenge_join":
            return await self.challenge_join(uid, str(m.get("code", "")).upper())
        if t == "inline_join":
            return await inline.join(self, uid, str(m.get("token", "")))
        if t == "bot_start":
            return await self.bot_start(uid, m)
        g = self.games.get(m.get("gid"))
        if not g or g.color_of(uid) is None or g.status != "active":
            return self.send_user(uid, {"t": "err", "code": "no_game"})
        c = g.color_of(uid)
        if t == "undo":
            if g.kind == "bot" and g.undo_bot(c):
                self.persist(g)
                self.push_game(g)
            else:
                self.send_user(uid, {"t": "err", "code": "undo_no"})
            return
        if t == "move":
            return self.do_move(g, c, str(m.get("uci", "")))
        if t == "resign":
            r = g.resign(c)
            return self.finish(g, *r)
        if t == "draw_offer":
            st, r = g.offer_draw(c)
            if st == "claimed":
                return self.finish(g, *r)
            if st == "offered":
                self.persist(g)
                self.push_game(g)
                if g.is_bot(not c):
                    self.spawn(self.bot_draw(g, not c))
            else:
                self.send_user(uid, {"t": "err", "code": "draw_no"})
            return
        if t == "draw_accept":
            if g.draw_by is not None and g.draw_by != c:
                return self.finish(g, "1/2-1/2", "agreement")
            return
        if t == "draw_decline":
            if g.draw_by is not None and g.draw_by != c:
                off = g.uid_of(g.draw_by)
                g.draw_by = None
                self.push_game(g)
                if off:
                    self.send_user(off, {"t": "draw_declined"})

    # ---------- partiya yaratish ----------
    def busy(self, uid):
        gid = self.user_game.get(uid)
        if gid and gid in self.games and self.games[gid].status == "active":
            self.send_user(uid, {"t": "err", "code": "in_game"})
            g = self.games[gid]
            self.send_user(uid, {"t": "game", "g": self.state_for(g, uid), "mv": None})
            return True
        return False

    def new_game(self, kind, white, black, tc, rated, bot_level=None):
        gid = secrets.token_hex(4)
        g = (checkers.CGame(gid, white, black, tc[0] * 1000, tc[1] * 1000) if kind == "checkers"
             else Game(gid, kind, white, black, tc[0] * 1000, tc[1] * 1000, rated, bot_level))
        self.games[gid] = g
        for u in (white, black):
            if u is not None:
                self.user_game[u] = gid
                self.queue.pop(u, None)
                self.drop_challenges(u)
        self.persist(g)
        for c in (W, B):
            u = g.uid_of(c)
            if u is not None:
                g.set_away(c, not any(x.visible for x in self.conns.get(u, [])))
        self.push_game(g)
        self.maybe_bot(g)
        return g

    async def queue_join(self, uid, m):
        if self.busy(uid):
            return
        tc = parse_tc(m.get("tc") or {})
        if not tc:
            return self.send_user(uid, {"t": "err", "code": "bad_tc"})
        self.drop_challenges(uid)
        self.queue[uid] = {"tc": tc, "since": time.monotonic(), "rating": db.get_user(uid)["rating"]}
        self.send_user(uid, {"t": "queue_on", "tc": {"base": tc[0], "inc": tc[1]}})
        self.try_match()

    def try_match(self):
        groups = {}
        for uid, e in self.queue.items():
            groups.setdefault(e["tc"], []).append((e["since"], uid))
        now = time.monotonic()
        for tc, lst in groups.items():
            lst.sort()
            used = set()
            for i, (sa, a) in enumerate(lst):
                if a in used:
                    continue
                best = None
                for sb, b in lst[i + 1:]:
                    if b in used:
                        continue
                    wait = max(now - sa, now - sb)
                    diff = abs(self.queue[a]["rating"] - self.queue[b]["rating"])
                    if diff <= 150 + 30 * wait and (best is None or diff < best[0]):
                        best = (diff, b)
                if best:
                    b = best[1]
                    used.update((a, b))
                    w, bl = (a, b) if random.random() < 0.5 else (b, a)
                    self.new_game("pvp", w, bl, tc, True)

    async def challenge_create(self, uid, m):
        if self.busy(uid):
            return
        tc = parse_tc(m.get("tc") or {})
        if not tc or (m.get("game") == "checkers" and tc not in ((600, 0), (0, 0))):
            return self.send_user(uid, {"t": "err", "code": "bad_tc"})
        self.queue.pop(uid, None)
        self.drop_challenges(uid)
        code = "".join(random.choice(ALNUM) for _ in range(6))
        self.challenges[code] = {"uid": uid, "tc": tc, "color": m.get("color", "random"), "ts": time.time(),
                                 "game": "checkers" if m.get("game") == "checkers" else None}
        bot = self.bot_info.get("username", "")
        if config.APP_SHORT_NAME:
            link = f"https://t.me/{bot}/{config.APP_SHORT_NAME}?startapp=ch_{code}"
        else:
            link = f"https://t.me/{bot}?start=ch_{code}"
        self.send_user(uid, {"t": "challenge_on", "code": code, "link": link, "tc": {"base": tc[0], "inc": tc[1]}})

    def drop_challenges(self, uid):
        for k in [k for k, v in self.challenges.items() if v["uid"] == uid]:
            self.challenges.pop(k, None)

    async def challenge_join(self, uid, code):
        if self.busy(uid):
            return
        ch = self.challenges.get(code)
        if not ch or time.time() - ch["ts"] > config.CHALLENGE_TTL_SEC:
            self.challenges.pop(code, None)
            return self.send_user(uid, {"t": "err", "code": "challenge_gone"})
        if ch["uid"] == uid:
            return self.send_user(uid, {"t": "err", "code": "own_challenge"})
        owner = ch["uid"]
        if self.busy_silent(owner):
            return self.send_user(uid, {"t": "err", "code": "challenge_gone"})
        self.challenges.pop(code, None)
        pref = ch["color"]
        if pref == "white":
            w, b = owner, uid
        elif pref == "black":
            w, b = uid, owner
        else:
            w, b = (owner, uid) if random.random() < 0.5 else (uid, owner)
        self.new_game(ch.get("game") or "pvp", w, b, ch["tc"], config.FRIEND_GAMES_RATED)

    def busy_silent(self, uid):
        gid = self.user_game.get(uid)
        return bool(gid and gid in self.games and self.games[gid].status == "active")

    async def bot_start(self, uid, m):
        if self.busy(uid):
            return
        if not self.engine.available:
            return self.send_user(uid, {"t": "err", "code": "engine_off"})
        lv = config.norm_level(m.get("level", "normal"))
        tc = parse_tc(m.get("tc") or {"base": 0})
        if not tc:
            return self.send_user(uid, {"t": "err", "code": "bad_tc"})
        col = m.get("color", "random")
        human_white = random.random() < 0.5 if col == "random" else col == "white"
        self.new_game("bot", uid if human_white else None, None if human_white else uid, tc, False, lv)

    # ---------- yurish ----------
    def do_move(self, g, c, uci):
        try:
            res = g.play(c, uci)
        except ValueError as e:
            uid = g.uid_of(c)
            self.send_user(uid, {"t": "err", "code": str(e)})
            self.push_game(g, only=uid)
            return
        if res is not None and res[1] in ("timeout", "timeout_insufficient"):
            return self.finish(g, *res)
        self.persist(g)
        self.push_game(g, mv=uci)
        if res is not None:
            return self.finish(g, *res)
        self.maybe_bot(g)

    def maybe_bot(self, g):
        if g.status == "active" and g.kind == "bot" and g.is_bot(g.board.turn) and not g.bot_thinking:
            self.spawn(self.bot_turn(g))

    async def bot_turn(self, g):
        g.bot_thinking = True
        try:
            ply0, t0, ver0 = g.ply, time.monotonic(), getattr(g, "ver", 0)
            rem = g.clock_now(g.board.turn) / 1000.0 if (g.timed and g.ply >= 2) else None
            try:
                mv = await self.engine.bot_move(g.board, g.bot_level, g.id, rem)
            except Exception:  # noqa
                log.exception("bot yurishi xato, tasodifiy yurish")
                mv = random.choice(list(g.board.legal_moves))
            await asyncio.sleep(max(0.0, 0.55 - (time.monotonic() - t0)))
            if g.status != "active" or g.ply != ply0 or not g.is_bot(g.board.turn) or getattr(g, "ver", 0) != ver0:
                g.bot_thinking = False
                self.maybe_bot(g)
                return
            res = g.play(g.board.turn, mv.uci())
            if res is not None and res[1] in ("timeout", "timeout_insufficient"):
                return self.finish(g, *res)
            self.persist(g)
            self.push_game(g, mv=mv.uci())
            if res is not None:
                self.finish(g, *res)
        finally:
            g.bot_thinking = False

    async def bot_draw(self, g, bot_color):
        accept = False
        try:
            info = await self.engine.analyse(g.board, g.id + "d", 200)
            cp = info["score"].pov(bot_color).score(mate_score=10000)
            accept = cp is not None and cp <= 30
        except Exception:  # noqa
            accept = False
        await asyncio.sleep(0.8)
        if g.status != "active" or g.draw_by is None:
            return
        if accept:
            self.finish(g, "1/2-1/2", "agreement")
        else:
            g.draw_by = None
            self.push_game(g)
            self.send_user(g.uid_of(not bot_color), {"t": "draw_declined"})

    # ---------- tugatish ----------
    def finish(self, g, result, reason):
        if g.status != "active":
            return
        g.status, g.result, g.reason = "over", result, reason
        g.draw_by = None
        aborted = result is None
        ended = db.now()
        wr = db.get_user(g.white) if g.white else None
        br = db.get_user(g.black) if g.black else None
        w_rt = wr["rating"] if wr else 0
        b_rt = br["rating"] if br else 0
        dw = dbd = 0
        info = {}
        new_badges = {}
        if not aborted:
            sw = 1.0 if result == "1-0" else 0.0 if result == "0-1" else 0.5
            if g.kind == "pvp" and g.rated:
                dw = R.elo_delta(w_rt, b_rt, sw)
                dbd = -dw
            for color, u, rt, delta in ((W, wr, w_rt, dw), (B, br, b_rt, dbd)):
                if not u:
                    continue
                score = sw if color == W else 1 - sw
                self.update_stats(g, u, score, delta)
        db.save_game((g.id, g.kind, int(g.rated), g.white, g.black, g.bot_level, g.base_ms // 1000, g.inc_ms // 1000,
                      " ".join(g.moves), result, reason, g.started_at, ended, w_rt, b_rt, dw, dbd, g.ply))
        db.live_delete(g.id)
        for color in (W, B):
            uid = g.uid_of(color)
            if uid is None:
                continue
            if not aborted:
                new_badges[uid] = self.badges_after(g, uid, color)
            self.user_game.pop(uid, None)
        for color in (W, B):
            uid = g.uid_of(color)
            if uid is None:
                continue
            u = db.get_user(uid)
            delta = dw if color == W else dbd
            old = (w_rt if color == W else b_rt)
            rated_effective = g.kind == "pvp" and g.rated and not aborted
            self.send_user(uid, {"t": "over", "g": self.state_for(g, uid),
                                 "rating": {"old": old, "new": u["rating"], "delta": delta} if rated_effective else None,
                                 "badges": new_badges.get(uid, []), "aborted": aborted})
            self.send_user(uid, {"t": "me", "me": self.me_payload(uid)})
        self.games.pop(g.id, None)
        inline.on_finish(g)

    def update_stats(self, g, u, score, delta):
        if g.kind == "checkers":
            return
        uid = u["id"]
        if g.kind == "bot":
            db.conn.execute("UPDATE users SET bot_games=bot_games+1, bot_wins=bot_wins+? WHERE id=?", (1 if score == 1 and not getattr(g, "undos", 0) else 0, uid))
            return
        if not g.rated:
            db.conn.execute("UPDATE users SET friend_games=friend_games+1 WHERE id=?", (uid,))
            return
        new_r = max(config.RATING_FLOOR, u["rating"] + delta)
        streak = u["streak"] + 1 if score == 1 else (0 if score == 0 else u["streak"])
        db.conn.execute(
            "UPDATE users SET rating=?, best_rating=MAX(best_rating,?), rated_games=rated_games+1, wins=wins+?, draws=draws+?, "
            "losses=losses+?, streak=?, best_streak=MAX(best_streak,?) WHERE id=?",
            (new_r, new_r, 1 if score == 1 else 0, 1 if score == 0.5 else 0, 1 if score == 0 else 0, streak, streak, uid))

    def badges_after(self, g, uid, color):
        u = db.get_user(uid)
        won = (g.result == "1-0" and color == W) or (g.result == "0-1" and color == B)
        extra = {"bot_beaten": config.norm_level(g.bot_level) if (g.kind == "bot" and won and not getattr(g, "undos", 0)) else None,
                 "mate_moves": ((g.ply + 1) // 2) if (won and g.reason == "checkmate") else None}
        new = []
        for code in sorted(R.evaluate_badges(u, extra)):
            if db.award(uid, code):
                new.append(code)
        return new

    # ---------- davriy ish ----------
    async def ticker(self):
        n = 0
        while True:
            await asyncio.sleep(0.5)
            n += 1
            try:
                for g in list(self.games.values()):
                    r = g.check()
                    if r is not None:
                        self.finish(g, *r)
                if n % 4 == 0:
                    self.try_match()
                    now = time.time()
                    for k in [k for k, v in self.challenges.items() if now - v["ts"] > config.CHALLENGE_TTL_SEC]:
                        v = self.challenges.pop(k)
                        self.send_user(v["uid"], {"t": "challenge_off"})
                    mono = time.monotonic()
                    for uid in [u for u, e in self.queue.items() if mono - e["since"] > config.QUEUE_TTL_SEC]:
                        self.queue.pop(uid, None)
                        self.send_user(uid, {"t": "queue_off"})
                if n % 120 == 0:
                    self.champs()
            except Exception:  # noqa
                log.exception("ticker xatosi")

    def restore(self):
        for d in db.live_all():
            try:
                g = checkers.CGame.load(d) if d.get("kind") == "checkers" else Game.load(d)
            except Exception:  # noqa
                db.live_delete(d["id"])
                continue
            self.games[g.id] = g
            for c in (W, B):
                u = g.uid_of(c)
                if u is not None:
                    self.user_game[u] = g.id
                    g.set_away(c, True)
        for g in self.games.values():
            self.maybe_bot(g)
        if self.games:
            log.info("%d ta tugallanmagan partiya tiklandi", len(self.games))
