"""Stockfish (UCI) havzasi: python-chess engine moduli orqali. Bot yurishlari va tahlil."""
import asyncio
import logging
import random
import shutil

import chess
import chess.engine

import config

log = logging.getLogger("engine")


class EnginePool:
    def __init__(self):
        self.path = None
        self.name = ""
        self.q = asyncio.Queue()
        self.size = 0
        self.available = False

    async def start(self):
        path = shutil.which(config.STOCKFISH_PATH) or (config.STOCKFISH_PATH if shutil.which(config.STOCKFISH_PATH) is None and
                                                       __import__("os").path.isfile(config.STOCKFISH_PATH) else None)
        if not path:
            log.warning("Stockfish topilmadi (%s). Bot va tahlil o'chiq. O'rnatish: pkg install stockfish", config.STOCKFISH_PATH)
            return
        self.path = path
        for _ in range(config.ENGINE_POOL):
            try:
                self.q.put_nowait(await self._spawn())
                self.size += 1
            except Exception as e:  # noqa
                log.error("Stockfish ishga tushmadi: %s", e)
        self.available = self.size > 0
        if self.available:
            log.info("Engine tayyor: %s (x%d)", self.name, self.size)

    async def _spawn(self):
        _, eng = await chess.engine.popen_uci(self.path)
        self.name = eng.id.get("name", "Stockfish")
        opts = {}
        if "Threads" in eng.options:
            opts["Threads"] = config.ENGINE_THREADS
        if "Hash" in eng.options:
            opts["Hash"] = config.ENGINE_HASH_MB
        if opts:
            await eng.configure(opts)
        return eng

    async def _run(self, fn):
        eng = await self.q.get()
        try:
            return await fn(eng)
        except (chess.engine.EngineTerminatedError, chess.engine.EngineError, ConnectionError, BrokenPipeError):
            log.warning("Engine qayta ishga tushirilmoqda")
            try:
                await eng.quit()
            except Exception:  # noqa
                pass
            eng = await self._spawn()
            return await fn(eng)
        finally:
            self.q.put_nowait(eng)

    async def bot_move(self, board, level, key, remaining_s=None):
        lv = config.BOT_LEVELS[config.norm_level(level)]
        if lv.get("rnd") and random.random() < lv["rnd"]:
            return random.choice(list(board.legal_moves))
        t = lv["time"]
        if remaining_s is not None:
            t = max(0.05, min(t, remaining_s / 25.0))

        async def go(eng):
            o = eng.options
            cfg = {}
            if lv["elo"] and "UCI_LimitStrength" in o and "UCI_Elo" in o:
                lo, hi = o["UCI_Elo"].min or 1320, o["UCI_Elo"].max or 3190
                cfg["UCI_LimitStrength"] = True
                cfg["UCI_Elo"] = max(lo, min(hi, lv["elo"]))
            elif lv["elo"] and "Skill Level" in o:
                cfg["Skill Level"] = max(0, min(20, (lv["elo"] - 1200) // 80))
            else:
                if "UCI_LimitStrength" in o:
                    cfg["UCI_LimitStrength"] = False
                if "Skill Level" in o:
                    cfg["Skill Level"] = 20
            if cfg:
                await eng.configure(cfg)
            res = await eng.play(board.copy(), chess.engine.Limit(time=t), game=key)
            return res.move

        return await self._run(go)

    async def analyse(self, board, key, ms):
        async def go(eng):
            cfg = {}
            if "UCI_LimitStrength" in eng.options:
                cfg["UCI_LimitStrength"] = False
            if "Skill Level" in eng.options:
                cfg["Skill Level"] = 20
            if cfg:
                await eng.configure(cfg)
            info = await eng.analyse(board.copy(), chess.engine.Limit(time=ms / 1000.0), game=key)
            return info

        return await self._run(go)

    async def stop(self):
        while not self.q.empty():
            e = self.q.get_nowait()
            try:
                await e.quit()
            except Exception:  # noqa
                pass
