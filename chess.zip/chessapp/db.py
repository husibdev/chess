"""SQLite qatlami. Barcha so'rovlar qisqa; WAL rejimi."""
import json
import os
import sqlite3
import time

import config
import rating as R

conn: sqlite3.Connection = None

SCHEMA = """
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY, first_name TEXT DEFAULT '', last_name TEXT DEFAULT '', username TEXT DEFAULT '',
  photo_url TEXT DEFAULT '', phone TEXT, lang TEXT DEFAULT 'en',
  rating INTEGER NOT NULL DEFAULT 1200, best_rating INTEGER NOT NULL DEFAULT 1200,
  rated_games INTEGER NOT NULL DEFAULT 0, wins INTEGER NOT NULL DEFAULT 0, draws INTEGER NOT NULL DEFAULT 0,
  losses INTEGER NOT NULL DEFAULT 0, streak INTEGER NOT NULL DEFAULT 0, best_streak INTEGER NOT NULL DEFAULT 0,
  bot_games INTEGER NOT NULL DEFAULT 0, bot_wins INTEGER NOT NULL DEFAULT 0, friend_games INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL DEFAULT 0, registered_at INTEGER, last_seen INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS games(
  id TEXT PRIMARY KEY, kind TEXT NOT NULL, rated INTEGER NOT NULL, white_id INTEGER, black_id INTEGER,
  bot_level TEXT, tc_base INTEGER NOT NULL, tc_inc INTEGER NOT NULL, moves TEXT NOT NULL DEFAULT '',
  result TEXT, reason TEXT, started_at INTEGER, ended_at INTEGER, w_rating INTEGER, b_rating INTEGER,
  w_delta INTEGER NOT NULL DEFAULT 0, b_delta INTEGER NOT NULL DEFAULT 0, ply INTEGER NOT NULL DEFAULT 0);
CREATE INDEX IF NOT EXISTS g_w ON games(white_id, ended_at);
CREATE INDEX IF NOT EXISTS g_b ON games(black_id, ended_at);
CREATE INDEX IF NOT EXISTS g_end ON games(rated, ended_at);
CREATE TABLE IF NOT EXISTS live_games(id TEXT PRIMARY KEY, data TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS analysis(game_id TEXT PRIMARY KEY, data TEXT NOT NULL, created_at INTEGER);
CREATE TABLE IF NOT EXISTS badges(user_id INTEGER, code TEXT, ts INTEGER, n INTEGER DEFAULT 1, PRIMARY KEY(user_id, code));
CREATE TABLE IF NOT EXISTS weekly_winners(week_start INTEGER, rank INTEGER, user_id INTEGER, wins INTEGER, net INTEGER,
  PRIMARY KEY(week_start, rank));
CREATE TABLE IF NOT EXISTS pending(user_id INTEGER PRIMARY KEY, payload TEXT);
"""


def init():
    global conn
    os.makedirs(os.path.dirname(config.DB_PATH), exist_ok=True)
    conn = sqlite3.connect(config.DB_PATH, check_same_thread=False, isolation_level=None)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.executescript(SCHEMA)


def now():
    return int(time.time())


# ---------- users ----------
def get_user(uid):
    r = conn.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
    return dict(r) if r else None


def upsert_profile(uid, first_name="", last_name="", username="", photo_url="", lang=None):
    t = now()
    if get_user(uid) is None:
        conn.execute("INSERT INTO users(id,first_name,last_name,username,photo_url,lang,rating,best_rating,created_at,last_seen)"
                     " VALUES(?,?,?,?,?,?,?,?,?,?)",
                     (uid, first_name or "", last_name or "", username or "", photo_url or "", lang or "en",
                      config.START_RATING, config.START_RATING, t, t))
    else:
        conn.execute("UPDATE users SET first_name=?,last_name=?,username=?,photo_url=COALESCE(NULLIF(?,''),photo_url),last_seen=? WHERE id=?",
                     (first_name or "", last_name or "", username or "", photo_url or "", t, uid))


def set_phone(uid, phone):
    conn.execute("UPDATE users SET phone=?, registered_at=COALESCE(registered_at,?) WHERE id=?", (phone, now(), uid))


def set_lang(uid, lang):
    if lang in ("en", "uz", "ru"):
        conn.execute("UPDATE users SET lang=? WHERE id=?", (lang, uid))


def is_registered(u):
    return bool(u and u.get("phone"))


def display_name(u):
    n = (u.get("first_name") or "").strip()
    if u.get("last_name"):
        n += " " + u["last_name"].strip()[:1] + "."
    return (n or u.get("username") or f"Player{u['id'] % 10000}")[:22]


def public_user(u, champs=None):
    if not u:
        return None
    return {"id": u["id"], "name": display_name(u), "username": u.get("username") or "", "photo": u.get("photo_url") or "",
            "rating": u["rating"], "champ": (champs or {}).get(u["id"], 0)}


def career_rank(u):
    if u["rated_games"] < 1:
        return 0
    r = conn.execute("SELECT COUNT(*) c FROM users WHERE rated_games>0 AND (rating>? OR (rating=? AND wins>?))",
                     (u["rating"], u["rating"], u["wins"])).fetchone()
    return r["c"] + 1


def career_board(limit=100):
    rows = conn.execute("SELECT * FROM users WHERE rated_games>0 ORDER BY rating DESC, wins DESC, id LIMIT ?", (limit,)).fetchall()
    return [dict(r) for r in rows]


# ---------- games ----------
def save_game(g):
    conn.execute("INSERT OR REPLACE INTO games(id,kind,rated,white_id,black_id,bot_level,tc_base,tc_inc,moves,result,reason,"
                 "started_at,ended_at,w_rating,b_rating,w_delta,b_delta,ply) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", g)


def get_game(gid):
    r = conn.execute("SELECT * FROM games WHERE id=?", (gid,)).fetchone()
    return dict(r) if r else None


def user_games(uid, limit=30, offset=0):
    rows = conn.execute("SELECT * FROM games WHERE (white_id=? OR black_id=?) AND result IS NOT NULL "
                        "ORDER BY ended_at DESC LIMIT ? OFFSET ?", (uid, uid, limit, offset)).fetchall()
    return [dict(r) for r in rows]


def rating_history(uid, limit=60):
    rows = conn.execute("SELECT * FROM games WHERE rated=1 AND result IS NOT NULL AND (white_id=? OR black_id=?) "
                        "ORDER BY ended_at DESC LIMIT ?", (uid, uid, limit)).fetchall()
    out = []
    for r in reversed(rows):
        if r["white_id"] == uid:
            out.append([r["ended_at"], r["w_rating"] + r["w_delta"]])
        else:
            out.append([r["ended_at"], r["b_rating"] + r["b_delta"]])
    return out


# ---------- live ----------
def live_save(gid, data):
    conn.execute("INSERT OR REPLACE INTO live_games(id,data) VALUES(?,?)", (gid, json.dumps(data, separators=(",", ":"))))


def live_delete(gid):
    conn.execute("DELETE FROM live_games WHERE id=?", (gid,))


def live_all():
    return [json.loads(r["data"]) for r in conn.execute("SELECT data FROM live_games")]


# ---------- analysis ----------
def analysis_get(gid):
    r = conn.execute("SELECT data FROM analysis WHERE game_id=?", (gid,)).fetchone()
    return json.loads(r["data"]) if r else None


def analysis_put(gid, data):
    conn.execute("INSERT OR REPLACE INTO analysis VALUES(?,?,?)", (gid, json.dumps(data, separators=(",", ":")), now()))


# ---------- badges ----------
def badges_of(uid):
    return [{"code": r["code"], "ts": r["ts"], "n": r["n"]} for r in
            conn.execute("SELECT * FROM badges WHERE user_id=? ORDER BY ts", (uid,))]


def award(uid, code, n=1):
    """Yangi bo'lsa True qaytaradi."""
    r = conn.execute("SELECT 1 FROM badges WHERE user_id=? AND code=?", (uid, code)).fetchone()
    if r:
        conn.execute("UPDATE badges SET n=? WHERE user_id=? AND code=?", (n, uid, code))
        return False
    conn.execute("INSERT INTO badges(user_id,code,ts,n) VALUES(?,?,?,?)", (uid, code, now(), n))
    return True


# ---------- weekly ----------
def week_table(start):
    """Berilgan haftadagi reytingli g'alabalar: [(uid, wins, draws, losses, net)] saralangan."""
    rows = conn.execute("SELECT white_id,black_id,result,w_delta,b_delta FROM games WHERE rated=1 AND result IS NOT NULL "
                        "AND ended_at>=? AND ended_at<?", (start, start + R.WEEK)).fetchall()
    st = {}
    for r in rows:
        for uid, delta, win_res, lose_res in ((r["white_id"], r["w_delta"], "1-0", "0-1"), (r["black_id"], r["b_delta"], "0-1", "1-0")):
            s = st.setdefault(uid, [0, 0, 0, 0])
            if r["result"] == win_res:
                s[0] += 1
            elif r["result"] == lose_res:
                s[2] += 1
            else:
                s[1] += 1
            s[3] += delta
    out = [(uid, *s) for uid, s in st.items() if s[0] > 0]
    out.sort(key=lambda x: (-x[1], -x[4], x[3], x[0]))
    return out


def finalize_week(start):
    """O'tgan hafta g'oliblarini bir marta saqlaydi (idempotent). Yangi nishon berilganlar ro'yxatini qaytaradi."""
    if conn.execute("SELECT 1 FROM weekly_winners WHERE week_start=? LIMIT 1", (start,)).fetchone():
        return []
    top = week_table(start)[:config.CHAMPION_COUNT]
    for i, (uid, w, d, l, net) in enumerate(top, 1):
        conn.execute("INSERT OR REPLACE INTO weekly_winners VALUES(?,?,?,?,?)", (start, i, uid, w, net))
        n = conn.execute("SELECT COUNT(*) c FROM weekly_winners WHERE user_id=?", (uid,)).fetchone()["c"]
        award(uid, "week_top10", n)
        if i == 1:
            award(uid, "week_champion", conn.execute("SELECT COUNT(*) c FROM weekly_winners WHERE user_id=? AND rank=1", (uid,)).fetchone()["c"])
    return [t[0] for t in top]


def champions(prev_start):
    return {r["user_id"]: r["rank"] for r in conn.execute("SELECT user_id,rank FROM weekly_winners WHERE week_start=?", (prev_start,))}
