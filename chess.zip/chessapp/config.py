"""Barcha sozlamalar. .env fayli yoki muhit o'zgaruvchilari orqali o'zgartiriladi."""
import os
import pathlib

ROOT = pathlib.Path(__file__).resolve().parent


def _load_env():
    p = ROOT / ".env"
    if not p.exists():
        return
    for line in p.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        v = v.split("  #")[0].split(" #")[0].strip().strip('"').strip("'")
        os.environ.setdefault(k.strip(), v)


_load_env()


def _int(name, default):
    try:
        return int(os.environ.get(name, default))
    except ValueError:
        return default


BOT_TOKEN = os.environ.get("BOT_TOKEN", "").strip()
WEBAPP_URL = os.environ.get("WEBAPP_URL", "").strip().rstrip("/")
APP_SHORT_NAME = os.environ.get("APP_SHORT_NAME", "").strip()
HOST = os.environ.get("HOST", "0.0.0.0")
PORT = _int("PORT", 8080)
DB_PATH = os.environ.get("DB_PATH", str(ROOT / "data" / "chess.db"))
WEBAPP_DIR = ROOT / "webapp"
DEV_MODE = _int("DEV_MODE", 0) == 1
DISABLE_BOT = _int("DISABLE_BOT", 0) == 1
DISABLE_TUNNEL = _int("DISABLE_TUNNEL", 0) == 1

# Stockfish
STOCKFISH_PATH = os.environ.get("STOCKFISH_PATH", "stockfish")
ENGINE_POOL = max(1, _int("ENGINE_POOL", 1))
ENGINE_THREADS = max(1, _int("ENGINE_THREADS", 1))
ENGINE_HASH_MB = max(1, _int("ENGINE_HASH_MB", 16))
ANALYSIS_MS = max(30, _int("ANALYSIS_MS", 150))
ANALYSIS_MAX_PENDING = 6

# Bot darajalari (tartib muhim). elo = Stockfish UCI_Elo (None = toʻliq kuch), time = yurish vaqti (s),
# rnd = tasodifiy yurish ehtimoli (eng past darajalar uchun), disp = koʻrsatiladigan taxminiy reyting
BOT_LEVELS = {
    "beginner": {"elo": 1320, "time": 0.05, "rnd": 0.40, "disp": 800},
    "super_easy": {"elo": 1320, "time": 0.05, "rnd": 0.25, "disp": 1050},
    "easy": {"elo": 1320, "time": 0.15, "rnd": 0.0, "disp": 1320},
    "normal": {"elo": 1500, "time": 0.25, "rnd": 0.0, "disp": 1500},
    "normal_plus": {"elo": 1700, "time": 0.30, "rnd": 0.0, "disp": 1700},
    "normal_pro": {"elo": 1900, "time": 0.40, "rnd": 0.0, "disp": 1900},
    "hard": {"elo": 2200, "time": 0.60, "rnd": 0.0, "disp": 2200},
    "hard_extra": {"elo": 2500, "time": 0.80, "rnd": 0.0, "disp": 2500},
    "hard_max": {"elo": 2800, "time": 1.00, "rnd": 0.0, "disp": 2800},
    "expert": {"elo": None, "time": 2.00, "rnd": 0.0, "disp": 3200},
}
LEGACY_LEVELS = {"medium": "normal", "max": "expert"}  # eski partiyalar uchun


def norm_level(lv):
    lv = LEGACY_LEVELS.get(lv, lv)
    return lv if lv in BOT_LEVELS else "normal"

# Reyting
START_RATING = 1200
K_FACTOR = 32
RATING_FLOOR = 100
FRIEND_GAMES_RATED = _int("FRIEND_GAMES_RATED", 0) == 1
ABORT_BEFORE_PLY = 2  # har ikki tomon yurmaguncha o'yin "bekor" (reyting o'zgarmaydi)

# Hafta: dushanba 00:00 dan dushanbagacha, GMT+5
TZ_OFFSET_HOURS = 5
CHAMPION_COUNT = 10

# Vaqt nazorati
PRESETS = [{"base": 300, "inc": 5}, {"base": 600, "inc": 0}, {"base": 1200, "inc": 0}]
MAX_BASE_SEC = 3 * 3600
MAX_INC_SEC = 60

# Ulanish uzilsa
RECONNECT_FRACTION = 0.20     # o'yin vaqtining 20%
RECONNECT_UNLIMITED_SEC = 210  # ∞ o'yinda 3.5 daqiqa
RECONNECT_MIN_SEC = 10
FIRST_MOVE_TIMEOUT_SEC = 45   # birinchi yurish uchun (keyin o'yin bekor)
UNLIMITED_IDLE_SEC = _int("UNLIMITED_IDLE_SEC", 0)

CHALLENGE_TTL_SEC = 900
QUEUE_TTL_SEC = 600
INITDATA_MAX_AGE = 3 * 86400
