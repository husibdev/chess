#!/data/data/com.termux/files/usr/bin/bash
# Serverni ishga tushirish (fonda ishlashi uchun uyqu rejimini o'chiradi va qulflaydi)
cd "$(dirname "$0")"
command -v termux-wake-lock >/dev/null && termux-wake-lock
while true; do
  python main.py
  echo "Server to'xtadi, 3 soniyadan keyin qayta ishga tushadi (Ctrl+C - chiqish)"; sleep 3
done
