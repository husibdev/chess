#!/usr/bin/env python3
"""Admin panel — botning o'zida (/admin). Faqat ADMIN_IDS. Boshqalarga bot JIM turadi.
O'rnatish: shu faylni loyiha papkasiga qo'ying va bir marta:  python admin.py --patch   (keyin serverni qayta ishga tushiring)"""
import asyncio
import collections
import csv
import html
import io
import logging
import os
import sqlite3
import sys
import tempfile
import time
from datetime import datetime

import aiohttp

import config
import db
import rating as R

ADMINS = {6673973610} | {int(x) for x in os.environ.get("ADMIN_IDS", "").replace(" ", "").split(",") if x.isdigit()}
B = H = LOOP = None
S = {"maint": 0, "bot_off": 0, "friend": int(config.FRIEND_GAMES_RATED), "notify": 1}
BANNED = set()
PEND, DRAFT = {}, {}
LOGS = collections.deque(maxlen=20)
LAST = [0.0]
START = time.time()
esc = html.escape
log = logging.getLogger("admin")


# ---------------- hub/api uchun kichik ilgaklar ----------------
def is_banned(uid):
    return uid in BANNED


def gate(uid, t):
    """hub.dispatch uchun: xato kodi yoki None."""
    if t in ("queue", "challenge_create", "challenge_join", "inline_join", "bot_start"):
        if S["maint"] and uid not in ADMINS:
            return "maint"
        if t == "bot_start" and S["bot_off"]:
            return "engine_off"
    return None


# ---------------- yordamchilar ----------------
def ft(ts):
    return datetime.fromtimestamp(ts, R.TZ).strftime("%d.%m.%Y %H:%M") if ts else "—"


def one(sql, *a):
    return db.conn.execute(sql, a).fetchone()[0]


def kv_set(k, v):
    db.conn.execute("INSERT OR REPLACE INTO kv VALUES(?,?)", (k, str(v)))


def btn(text, data):
    return {"text": text, "callback_data": data}


BACK = [btn("⬅️ Menyu", "a:menu")]


def nm(uid):
    if not uid:
        return "🤖 Stockfish"
    u = db.get_user(uid)
    return db.display_name(u) if u else str(uid)


async def api(method, **p):
    try:
        async with B.s.post(B.base + method, json=p, timeout=aiohttp.ClientTimeout(total=60)) as r:
            d = await r.json()
    except Exception as e:  # noqa
        return False, {"description": str(e)}
    return bool(d.get("ok")), d


async def say(chat, text, rows=None):
    p = {"chat_id": chat, "text": text, "parse_mode": "HTML"}
    if rows:
        p["reply_markup"] = {"inline_keyboard": rows}
    return await api("sendMessage", **p)


async def edit(ctx, text, rows=None):
    chat, mid = ctx
    if mid:
        ok, d = await api("editMessageText", chat_id=chat, message_id=mid, text=text, parse_mode="HTML",
                          reply_markup={"inline_keyboard": rows or []})
        if ok or "not modified" in str(d.get("description", "")):
            return
    await say(chat, text, rows)


async def send_doc(chat, name, data, caption=""):
    fd = aiohttp.FormData()
    fd.add_field("chat_id", str(chat))
    fd.add_field("caption", caption)
    fd.add_field("document", data, filename=name)
    try:
        async with B.s.post(B.base + "sendDocument", data=fd, timeout=aiohttp.ClientTimeout(total=120)) as r:
            return (await r.json()).get("ok")
    except Exception:  # noqa
        return False


async def notify(text):
    for a in ADMINS:
        await say(a, text)


class LogH(logging.Handler):
    def emit(self, r):
        try:
            if r.levelno < 30:
                return
            msg = f"{datetime.now(R.TZ):%d.%m %H:%M:%S} {r.levelname} {r.name}: {r.getMessage()}"
            if r.exc_info:
                msg += " | " + repr(r.exc_info[1])
            LOGS.append(msg[:300])
            if r.levelno >= 40 and S["notify"] and time.time() - LAST[0] > 60 and LOOP and not LOOP.is_closed():
                LAST[0] = time.time()
                LOOP.call_soon_threadsafe(lambda: asyncio.ensure_future(notify("⚠️ <b>Xato:</b> " + esc(msg[:300]))))
        except Exception:  # noqa  (o'chish paytida modullar None bo'lishi mumkin)
            pass


def init(bot, hub):
    global B, H, LOOP
    B, H, LOOP = bot, hub, asyncio.get_event_loop()
    c = db.conn
    try:
        c.execute("ALTER TABLE users ADD COLUMN banned INTEGER NOT NULL DEFAULT 0")
    except sqlite3.OperationalError:
        pass
    c.execute("CREATE TABLE IF NOT EXISTS kv(k TEXT PRIMARY KEY, v TEXT)")
    for k, v in c.execute("SELECT k,v FROM kv"):
        if k in S:
            S[k] = int(v)
    config.FRIEND_GAMES_RATED = bool(S["friend"])
    BANNED.update(r[0] for r in c.execute("SELECT id FROM users WHERE banned=1"))
    cb, wt = db.career_board, db.week_table
    db.career_board = lambda limit=100: [u for u in cb(limit + 50) if u["id"] not in BANNED][:limit]
    db.week_table = lambda start: [x for x in wt(start) if x[0] not in BANNED]
    logging.getLogger().addHandler(LogH())
    asyncio.ensure_future(backup_loop())
    asyncio.ensure_future(notify("🟢 Server ishga tushdi. /admin"))


async def notify_new(uid):
    if not S["notify"] or not B:
        return
    u = db.get_user(uid)
    await notify(f"🆕 Yangi foydalanuvchi: {esc(db.display_name(u))} @{esc(u['username'] or '-')} · <code>{uid}</code> · {esc(u['phone'] or '')}\n"
                 f"Jami: {one('SELECT COUNT(*) FROM users WHERE phone IS NOT NULL')}")


# ---------------- kirish nuqtasi ----------------
async def handle(upd):
    """True qaytarsa — update admin tomonidan 'yeb qo'yildi' (botapi qolganini o'tkazib yuboradi)."""
    if not B:
        return False
    cq = upd.get("callback_query")
    if cq:
        d = cq.get("data", "")
        if not d.startswith("a:"):
            return False
        if cq["from"]["id"] in ADMINS:
            await on_cb(cq)
        else:
            await api("answerCallbackQuery", callback_query_id=cq["id"])
        return True
    m = upd.get("message")
    if not m or "from" not in m:
        return False
    uid, chat = m["from"]["id"], m["chat"]["id"]
    text = (m.get("text") or "").strip()
    cmd = text.split()[0].split("@")[0].lower() if text.startswith("/") else ""
    if cmd == "/admin":
        if uid in ADMINS and chat == uid:
            PEND.pop(uid, None)
            await menu((chat, None), uid)
        return True  # oddiy foydalanuvchiga javob yo'q
    if uid in ADMINS and chat == uid and uid in PEND:
        if cmd == "/cancel":
            PEND.pop(uid, None)
            await say(chat, "Bekor qilindi. /admin")
            return True
        if cmd:
            PEND.pop(uid, None)
            return False
        await on_text(uid, chat, m)
        return True
    return False


async def on_cb(cq):
    parts = cq["data"].split(":")
    ctx = (cq["message"]["chat"]["id"], cq["message"]["message_id"])
    await api("answerCallbackQuery", callback_query_id=cq["id"])
    fn = ROUTES.get(parts[1])
    if not fn:
        return
    try:
        await fn(ctx, cq["from"]["id"], *parts[2:])
    except Exception:  # noqa
        log.exception("admin callback xatosi: %s", cq["data"])


# ---------------- menyu va statistika ----------------
async def menu(ctx, aid):
    on = lambda v: "🟢" if v else "⚪️"
    rows = [[btn("📊 Statistika", "a:stats"), btn("📢 Xabar yuborish", "a:bc")],
            [btn("👥 Foydalanuvchilar", "a:u"), btn("🎮 Jonli partiyalar", "a:g")],
            [btn("🏆 Haftalik jadval", "a:w"), btn("💾 Zaxira nusxa", "a:bk")],
            [btn(f"🔧 Texnik rejim {on(S['maint'])}", "a:mt"), btn("⚙️ Sozlamalar", "a:set")],
            [btn("📜 Xatolar", "a:log"), btn("📄 CSV eksport", "a:csv")],
            [btn("📢 Majburiy kanallar", "a:sub")],
            [btn("✖️ Yopish", "a:x")]]
    await edit(ctx, "🛠 <b>Admin panel</b>" + ("\n🔧 Texnik rejim YOQILGAN" if S["maint"] else ""), rows)


async def r_close(ctx, aid):
    await api("deleteMessage", chat_id=ctx[0], message_id=ctx[1])


def stats_text():
    now = db.now()
    day0 = int((time.time() + 5 * 3600) // 86400 * 86400 - 5 * 3600)
    reg = "phone IS NOT NULL"
    try:
        load = "%.2f" % os.getloadavg()[0]
    except Exception:  # noqa
        load = "—"
    top = "\n".join(f"  {i}. {esc(db.display_name(u))} — {u['rating']}" for i, u in enumerate(db.career_board(5), 1)) or "  —"
    eng = H.engine.name if H.engine.available else "o'chiq"
    size = os.path.getsize(config.DB_PATH) / 1048576 if os.path.exists(config.DB_PATH) else 0
    return (f"📊 <b>Statistika</b>\n"
            f"👤 Foydalanuvchilar: <b>{one(f'SELECT COUNT(*) FROM users WHERE {reg}')}</b> (banlangan: {len(BANNED)})\n"
            f"🆕 Bugun: {one(f'SELECT COUNT(*) FROM users WHERE registered_at>=?', day0)} · 7 kun: {one(f'SELECT COUNT(*) FROM users WHERE registered_at>=?', now - 7 * 86400)}\n"
            f"🕒 Faol (24 soat): {one('SELECT COUNT(*) FROM users WHERE last_seen>=?', now - 86400)}\n"
            f"🟢 Hozir onlayn: {len(H.conns)} · jonli partiya: {len(H.games)} · navbatda: {len(H.queue)}\n"
            f"♟ Bugungi oʻyinlar: {one('SELECT COUNT(*) FROM games WHERE ended_at>=? AND result IS NOT NULL AND kind!=?', day0, 'checkers')} · jami: {one('SELECT COUNT(*) FROM games WHERE result IS NOT NULL AND kind!=?', 'checkers')} · reytingli: {one('SELECT COUNT(*) FROM games WHERE rated=1 AND result IS NOT NULL')}\n"
            f"🔴 Shashka oʻyinlari: {one('SELECT COUNT(*) FROM games WHERE kind=? AND result IS NOT NULL', 'checkers')}\n"
            f"🤖 Stockfish: {esc(eng)}\n"
            f"⏱ Ishlash vaqti: {int((time.time() - START) // 3600)} soat {int((time.time() - START) // 60 % 60)} daq · yuklama: {load}\n"
            f"💽 Baza: {size:.1f} MB\n🏅 Top-5:\n{top}")


async def r_stats(ctx, aid):
    await edit(ctx, stats_text(), [[btn("🔄 Yangilash", "a:stats")], BACK])


# ---------------- foydalanuvchilar ----------------
def find(q):
    q, c = q.strip(), db.conn
    d = q.lstrip("+").replace(" ", "")
    if d.isdigit():
        return c.execute("SELECT * FROM users WHERE id=? OR REPLACE(REPLACE(phone,'+',''),' ','') LIKE ? LIMIT 8", (int(d), "%" + d + "%")).fetchall()
    like = "%" + q.lstrip("@") + "%"
    return c.execute("SELECT * FROM users WHERE username LIKE ? OR first_name LIKE ? OR last_name LIKE ? LIMIT 8", (like, like, like)).fetchall()


def list_rows(rows, extra=None):
    kb = [[btn(f"{'🚫 ' if r['banned'] else ''}{db.display_name(dict(r))} · {r['rating']} · {r['id']}", f"a:uc:{r['id']}")] for r in rows]
    return kb + [extra or [btn("⬅️ Orqaga", "a:u")]]


async def r_u(ctx, aid):
    await edit(ctx, "👥 <b>Foydalanuvchilar</b>", [[btn("🔎 Qidirish", "a:us")], [btn("🏅 Top 10", "a:ut:top"), btn("🆕 Oxirgi 10", "a:ut:new")],
                                                  [btn("🚫 Banlanganlar", "a:ut:ban")], BACK])


async def r_us(ctx, aid):
    PEND[aid] = {"k": "search"}
    await edit(ctx, "🔎 ID, @username, ism yoki telefon (oxirgi raqamlari) yuboring.\n/cancel — bekor qilish", [[btn("⬅️ Orqaga", "a:u")]])


async def r_ut(ctx, aid, kind):
    q = {"top": "SELECT * FROM users WHERE phone IS NOT NULL ORDER BY rating DESC LIMIT 10",
         "new": "SELECT * FROM users WHERE phone IS NOT NULL ORDER BY registered_at DESC LIMIT 10",
         "ban": "SELECT * FROM users WHERE banned=1 LIMIT 30"}[kind]
    rows = db.conn.execute(q).fetchall()
    await edit(ctx, "👥 Roʻyxat" if rows else "Hech kim yoʻq", list_rows(rows))


def card(u):
    return (f"👤 <b>{esc(db.display_name(u))}</b> @{esc(u['username'] or '-')}\n🆔 <code>{u['id']}</code> · 📱 {esc(u['phone'] or '—')}\n"
            f"🏅 Reyting: <b>{u['rating']}</b> (eng yuqori {u['best_rating']}) · tili: {u['lang']}\n"
            f"♟ Reytingli: {u['rated_games']} (G {u['wins']} / D {u['draws']} / M {u['losses']}) · botga qarshi: {u['bot_wins']}/{u['bot_games']}\n"
            f"🕒 Oxirgi kirish: {ft(u['last_seen'])} · roʻyxatdan: {ft(u['registered_at'])}\n"
            f"Holat: {'🚫 BAN' if u.get('banned') else '✅ faol'}")


async def r_uc(ctx, aid, uid):
    u = db.get_user(int(uid))
    if not u:
        return await edit(ctx, "Topilmadi", [[btn("⬅️ Orqaga", "a:u")]])
    uid = u["id"]
    await edit(ctx, card(u), [[btn("✅ Unban" if u.get("banned") else "🚫 Ban", f"a:ub:{uid}"), btn("✉️ Xabar", f"a:um:{uid}")],
                              [btn("📈 Reytingni oʻzgartirish", f"a:ur:{uid}"), btn("♻️ 1200 ga", f"a:uz:{uid}")],
                              [btn("🎖 Nishon berish", f"a:ug:{uid}"), btn("📵 Raqamni tozalash", f"a:up:{uid}")],
                              [btn("⬅️ Orqaga", "a:u")]])


async def r_ub(ctx, aid, uid):
    uid = int(uid)
    u = db.get_user(uid)
    flag = 0 if u.get("banned") else 1
    db.conn.execute("UPDATE users SET banned=? WHERE id=?", (flag, uid))
    if flag:
        BANNED.add(uid)
        H.queue.pop(uid, None)
        g = H.games.get(H.user_game.get(uid))
        if g:
            H.finish(g, None, "aborted")
        for c in list(H.conns.get(uid, [])):
            await c.ws.close()
        await say(uid, "🚫 Akkauntingiz cheklangan.")
    else:
        BANNED.discard(uid)
        await say(uid, "✅ Akkauntingizdagi cheklov olib tashlandi.")
    await r_uc(ctx, aid, uid)


async def r_ur(ctx, aid, uid):
    PEND[aid] = {"k": "rate", "uid": int(uid)}
    await edit(ctx, "Yangi reytingni raqam bilan yuboring (masalan 1500). /cancel", [[btn("⬅️ Orqaga", f"a:uc:{uid}")]])


async def r_uz(ctx, aid, uid):
    db.conn.execute("UPDATE users SET rating=? WHERE id=?", (config.START_RATING, int(uid)))
    await r_uc(ctx, aid, uid)


async def r_um(ctx, aid, uid):
    PEND[aid] = {"k": "dm", "uid": int(uid)}
    await edit(ctx, "Foydalanuvchiga yuboriladigan matnni yozing. /cancel", [[btn("⬅️ Orqaga", f"a:uc:{uid}")]])


async def r_ug(ctx, aid, uid, code=None):
    if code:
        db.award(int(uid), code)
        return await r_uc(ctx, aid, uid)
    rows = [[btn(c, f"a:ug:{uid}:{c}") for c in R.BADGES[i:i + 2]] for i in range(0, len(R.BADGES), 2)]
    await edit(ctx, "Qaysi nishon berilsin?", rows + [[btn("⬅️ Orqaga", f"a:uc:{uid}")]])


async def r_up(ctx, aid, uid, yes=None):
    if yes:
        db.conn.execute("UPDATE users SET phone=NULL WHERE id=?", (int(uid),))
        return await r_uc(ctx, aid, uid)
    await edit(ctx, "Raqam oʻchiriladi — foydalanuvchi botda qayta roʻyxatdan oʻtishi kerak boʻladi. Davom etamizmi?",
               [[btn("✅ Ha", f"a:up:{uid}:1"), btn("❌ Yoʻq", f"a:uc:{uid}")]])


# ---------------- matn kiritish (kutilayotgan amallar) ----------------
async def on_text(aid, chat, m):
    p, text = PEND[aid], (m.get("text") or "").strip()
    k = p["k"]
    if k == "subadd":
        import subscribe
        return await subscribe.on_admin_text(aid, chat, text)
    if k == "search":
        PEND.pop(aid, None)
        rows = find(text)
        return await say(chat, f"Topildi: {len(rows)}" if rows else "Hech narsa topilmadi", list_rows(rows) if rows else [[btn("⬅️ Orqaga", "a:u")]])
    if k == "rate":
        if not text.lstrip("-").isdigit():
            return await say(chat, "Faqat raqam yuboring yoki /cancel")
        PEND.pop(aid, None)
        v = max(config.RATING_FLOOR, int(text))
        db.conn.execute("UPDATE users SET rating=?, best_rating=MAX(best_rating,?) WHERE id=?", (v, v, p["uid"]))
        return await say(chat, f"✅ Reyting: {v}", [[btn("👤 Karta", f"a:uc:{p['uid']}")]])
    if k == "dm":
        PEND.pop(aid, None)
        ok, d = await api("sendMessage", chat_id=p["uid"], text=text)
        return await say(chat, "✅ Yuborildi" if ok else "❌ Yuborilmadi: " + esc(str(d.get("description"))), [[btn("👤 Karta", f"a:uc:{p['uid']}")]])
    if k == "bc":
        if m.get("photo"):
            DRAFT[aid] = {"seg": p["seg"], "photo": m["photo"][-1]["file_id"], "cap": m.get("caption", "")}
        elif text:
            DRAFT[aid] = {"seg": p["seg"], "text": text}
        else:
            return await say(chat, "Matn yoki rasm yuboring (yoki /cancel)")
        PEND.pop(aid, None)
        await say(chat, "Xabar ostiga ♟ <b>Oʻynash</b> tugmasi (Mini Appni ochadi) qoʻshilsinmi?",
                  [[btn("✅ Ha", "a:bcb:1"), btn("❌ Yoʻq", "a:bcb:0")]])


# ---------------- xabar yuborish ----------------
def recipients(seg):
    q, a = "SELECT id FROM users WHERE phone IS NOT NULL AND banned=0", []
    if seg in ("uz", "ru", "en"):
        q += " AND lang=?"
        a.append(seg)
    elif seg == "act7":
        q += " AND last_seen>=?"
        a.append(db.now() - 7 * 86400)
    ids = [r[0] for r in db.conn.execute(q, a)]
    if seg == "top":
        ch = set(H.champs())
        ids = [i for i in ids if i in ch]
    return ids


SEGS = [("all", "Hammaga"), ("uz", "🇺🇿 Oʻzbek"), ("ru", "🇷🇺 Rus"), ("en", "🇬🇧 Ingliz"), ("act7", "Faol (7 kun)"), ("top", "⭐ Haftalik top 10")]


async def r_bc(ctx, aid):
    rows = [[btn(f"{n} ({len(recipients(s))})", f"a:bcs:{s}")] for s, n in SEGS]
    await edit(ctx, "📢 <b>Xabar yuborish</b>\nKimga?", rows + [BACK])


async def r_bcs(ctx, aid, seg):
    PEND[aid] = {"k": "bc", "seg": seg}
    await edit(ctx, "Xabarni yuboring: matn yoki rasm (izoh bilan). /cancel — bekor", [[btn("⬅️ Orqaga", "a:bc")]])


async def send_draft(chat, d):
    mk = {"inline_keyboard": [[{"text": "♟ Oʻynash", "web_app": {"url": B.webapp_url}}]]} if d.get("btn") and B.webapp_url else None
    if d.get("photo"):
        m, p = "sendPhoto", {"chat_id": chat, "photo": d["photo"], "caption": d.get("cap", "")}
    else:
        m, p = "sendMessage", {"chat_id": chat, "text": d["text"]}
    if mk:
        p["reply_markup"] = mk
    return await api(m, **p)


async def r_bcb(ctx, aid, v):
    d = DRAFT.get(aid)
    if not d:
        return await menu(ctx, aid)
    d["btn"] = int(v)
    await send_draft(ctx[0], d)  # oldindan ko'rish
    await say(ctx[0], f"👆 Shunday koʻrinadi. Qabul qiluvchilar: <b>{len(recipients(d['seg']))}</b>. Yuborilsinmi?",
              [[btn("🚀 Yuborish", "a:bcgo"), btn("✖️ Bekor", "a:menu")]])


async def r_bcgo(ctx, aid):
    d = DRAFT.pop(aid, None)
    if not d:
        return await menu(ctx, aid)
    ids = recipients(d["seg"])
    await edit(ctx, f"🚀 Yuborish boshlandi: {len(ids)} ta…")
    asyncio.ensure_future(run_bc(ctx[0], d, ids))


async def run_bc(chat, d, ids):
    sent = blocked = fail = 0
    ok_, msg = await say(chat, f"⏳ 0/{len(ids)}")
    mid = msg.get("result", {}).get("message_id")
    for i, uid in enumerate(ids, 1):
        ok, r = await send_draft(uid, d)
        if not ok and r.get("error_code") == 429:
            await asyncio.sleep(r.get("parameters", {}).get("retry_after", 3) + 1)
            ok, r = await send_draft(uid, d)
        if ok:
            sent += 1
        elif r.get("error_code") in (400, 403):
            blocked += 1
        else:
            fail += 1
        if mid and i % 40 == 0:
            await api("editMessageText", chat_id=chat, message_id=mid, text=f"⏳ {i}/{len(ids)}")
        await asyncio.sleep(0.05)
    await say(chat, f"✅ Tugadi\nYetkazildi: <b>{sent}</b>\nBloklagan/yopiq: {blocked}\nXato: {fail}", [BACK])


# ---------------- jonli partiyalar ----------------
async def r_g(ctx, aid):
    rows = [[btn(f"{nm(g.white)} vs {nm(g.black)} · {g.base_ms // 60000 if g.base_ms else '∞'} · {g.ply}", f"a:gc:{g.id}")] for g in list(H.games.values())[:20]]
    await edit(ctx, f"🎮 Jonli partiyalar: {len(H.games)}", rows + [BACK])


async def r_gc(ctx, aid, gid):
    g = H.games.get(gid)
    if not g:
        return await r_g(ctx, aid)
    await edit(ctx, f"♟ {esc(nm(g.white))} vs {esc(nm(g.black))}\nTur: {g.kind} · reytingli: {g.rated} · yurish: {g.ply // 2 + 1}\n" + " ".join(g.sans[-12:]),
               [[btn("⛔ Bekor qilish", f"a:gx:{gid}")], [btn("⬅️ Orqaga", "a:g")]])


async def r_gx(ctx, aid, gid):
    g = H.games.get(gid)
    if g:
        H.finish(g, None, "aborted")
    await r_g(ctx, aid)


# ---------------- haftalik jadval ----------------
async def r_w(ctx, aid):
    start = R.week_start()
    cur = "\n".join(f"{i}. {esc(nm(u))} — {w} g'alaba ({'+' if n > 0 else ''}{n})" for i, (u, w, d, l, n) in enumerate(db.week_table(start)[:10], 1)) or "—"
    prev = "\n".join(f"{r}. {esc(nm(u))}" for u, r in sorted(db.champions(start - R.WEEK).items(), key=lambda x: x[1])) or "—"
    await edit(ctx, f"🏆 <b>Shu hafta</b> (tugaydi: {ft(start + R.WEEK)})\n{cur}\n\n⭐ <b>Hozirgi chempionlar</b>\n{prev}",
               [[btn("🔄 Oʻtgan haftani yakunlash", "a:wf")], BACK])


async def r_wf(ctx, aid):
    n = len(db.finalize_week(R.week_start() - R.WEEK))
    H._champ_cache = (0, 0, {})
    await edit(ctx, f"Yakunlandi: {n} ta (0 boʻlsa — avval yakunlangan yoki gʻolib yoʻq)", [[btn("⬅️ Orqaga", "a:w")]])


# ---------------- zaxira, CSV, loglar ----------------
def make_backup():
    fd, p = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    dst = sqlite3.connect(p)
    db.conn.backup(dst)
    dst.close()
    data = open(p, "rb").read()
    os.remove(p)
    return data


async def r_bk(ctx, aid):
    ok = await send_doc(ctx[0], f"chess-{datetime.now(R.TZ):%Y%m%d-%H%M}.db", make_backup(), "💾 Zaxira nusxa")
    await edit(ctx, "💾 Yuborildi" if ok else "❌ Yuborib boʻlmadi", [BACK])


async def backup_loop():
    while True:
        await asyncio.sleep(86400)
        try:
            for a in ADMINS:
                await send_doc(a, f"chess-{datetime.now(R.TZ):%Y%m%d}.db", make_backup(), "💾 Kunlik avto-zaxira")
        except Exception:  # noqa
            log.exception("avto-zaxira xatosi")


async def r_csv(ctx, aid):
    out = io.StringIO()
    w = csv.writer(out)
    cols = ["id", "username", "first_name", "last_name", "phone", "lang", "rating", "rated_games", "wins", "draws", "losses", "banned", "registered_at", "last_seen"]
    w.writerow(cols)
    for r in db.conn.execute("SELECT * FROM users WHERE phone IS NOT NULL ORDER BY registered_at"):
        w.writerow([ft(r[c]) if c in ("registered_at", "last_seen") else r[c] for c in cols])
    ok = await send_doc(ctx[0], "users.csv", out.getvalue().encode("utf-8-sig"), "📄 Foydalanuvchilar")
    await edit(ctx, "📄 Yuborildi" if ok else "❌ Yuborib boʻlmadi", [BACK])


async def r_log(ctx, aid):
    await edit(ctx, "📜 <b>Oxirgi ogohlantirish/xatolar</b>\n<pre>" + (esc("\n".join(LOGS))[-3500:] or "yoʻq") + "</pre>", [[btn("🔄", "a:log")], BACK])


# ---------------- texnik rejim, sozlamalar ----------------
async def r_mt(ctx, aid):
    S["maint"] ^= 1
    kv_set("maint", S["maint"])
    await menu(ctx, aid)


async def r_set(ctx, aid):
    yn = lambda v: "✅" if v else "❌"
    await edit(ctx, "⚙️ <b>Sozlamalar</b>", [[btn(f"Doʻst oʻyinlari reytingli: {yn(S['friend'])}", "a:st:friend")],
                                           [btn(f"Botga qarshi oʻyin: {'oʻchiq' if S['bot_off'] else 'yoqiq'}", "a:st:bot_off")],
                                           [btn(f"Admin bildirishnomalari: {yn(S['notify'])}", "a:st:notify")], BACK])


async def r_st(ctx, aid, key):
    if key in S:
        S[key] ^= 1
        kv_set(key, S[key])
        config.FRIEND_GAMES_RATED = bool(S["friend"])
    await r_set(ctx, aid)


ROUTES = {"menu": menu, "x": r_close, "stats": r_stats, "u": r_u, "us": r_us, "ut": r_ut, "uc": r_uc, "ub": r_ub, "ur": r_ur, "uz": r_uz,
          "um": r_um, "ug": r_ug, "up": r_up, "bc": r_bc, "bcs": r_bcs, "bcb": r_bcb, "bcgo": r_bcgo, "g": r_g, "gc": r_gc, "gx": r_gx,
          "w": r_w, "wf": r_wf, "bk": r_bk, "csv": r_csv, "log": r_log, "mt": r_mt, "set": r_set, "st": r_st}


# ---------------- boshqa fayllarga ilgaklarni qo'yish: python admin.py --patch ----------------
PATCHES = [
    ("hub.py", "import db\nimport rating as R\n", "import admin\nimport db\nimport rating as R\n"),
    ("hub.py", '            uid = int(user["id"])\n',
     '            uid = int(user["id"])\n            if admin.is_banned(uid):\n                await self._send(ws, {"t": "hello_err", "code": "banned"})\n                return ws\n'),
    ("hub.py", '        t, uid = m.get("t"), conn.uid\n',
     '        t, uid = m.get("t"), conn.uid\n        err = admin.gate(uid, t)\n        if err:\n            return self.send_user(uid, {"t": "err", "code": err})\n'),
    ("api.py", "    if not db.is_registered(u):\n        raise web.HTTPForbidden",
     '    if u and u.get("banned"):\n        raise web.HTTPForbidden(text="banned")\n    if not db.is_registered(u):\n        raise web.HTTPForbidden'),
    ("botapi.py", "import config\nimport db\n", "import admin\nimport config\nimport db\n"),
    ("botapi.py", '    async def handle(self, upd):\n', '    async def handle(self, upd):\n        if await admin.handle(upd):\n            return\n'),
    ("botapi.py", '            db.set_phone(uid, c["phone_number"])\n', '            db.set_phone(uid, c["phone_number"])\n            await admin.notify_new(uid)\n'),
    ("main.py", "import api\nimport config\n", "import admin\nimport api\nimport config\n"),
    ("main.py", "    hub.restore()\n", "    hub.restore()\n    if bot:\n        admin.init(bot, hub)\n"),
    ("webapp/js/i18n.js", 'offline:"Reconnecting…", badNew', 'offline:"Reconnecting…", err_maint:"Maintenance in progress, try again later", banned:"Your account is restricted", badNew'),
    ("webapp/js/i18n.js", 'offline:"Qayta ulanmoqda…", badNew', 'offline:"Qayta ulanmoqda…", err_maint:"Texnik ishlar olib borilmoqda, keyinroq urinib koʻring", banned:"Akkauntingiz cheklangan", badNew'),
    ("webapp/js/i18n.js", 'offline:"Переподключение…", badNew', 'offline:"Переподключение…", err_maint:"Идут технические работы, попробуйте позже", banned:"Ваш аккаунт ограничен", badNew'),
    ("webapp/js/main.js", 'if (m.code === "not_registered") showRegister(); else showMsg("Open from Telegram");',
     'if (m.code === "not_registered") showRegister(); else if (m.code === "banned") showMsg(t("banned")); else showMsg("Open from Telegram");'),
]


def patch():
    base = config.ROOT
    for fn, old, new in PATCHES:
        p = base / fn
        if not p.exists():
            print("YO'Q:", fn)
            continue
        s = p.read_text(encoding="utf-8")
        if new in s:
            print("allaqachon:", fn)
        elif old not in s:
            print("!! TOPILMADI (qo'lda qo'shing):", fn, repr(old[:50]))
        else:
            bak = p.with_name(p.name + ".bak")
            if not bak.exists():
                bak.write_text(s, encoding="utf-8")
            p.write_text(s.replace(old, new, 1), encoding="utf-8")
            print("ok:", fn)
    print("Tayyor. Serverni qayta ishga tushiring.")


if __name__ == "__main__":
    if "--patch" in sys.argv:
        patch()
    else:
        print("Ishlatish: python admin.py --patch")
