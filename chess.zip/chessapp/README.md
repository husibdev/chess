# ♟ Chess Mini App v1.0 (Telegram) — Python 3.10.11 + SQLite + Stockfish

**Ishga tushiriladigan fayl: `main.py`** (yoki `bash run.sh` — qulaganda o'zi qayta ishga tushiradi).

## 1. O'rnatish
### Termux (bir marta)
```
termux-setup-storage
cp ~/storage/downloads/chess-miniapp-v1.0.zip ~ && unzip chess-miniapp-v1.0.zip && cd chessapp
bash scripts/setup_termux.sh
nano .env          # BOT_TOKEN=...
bash run.sh
```
### Oddiy Linux / VPS / Windows (Python 3.10.11)
```
python3.10 -m venv venv && source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env && nano .env                         # BOT_TOKEN=...
python main.py
```
Stockfish alohida o'rnatiladi (`apt install stockfish` / `pkg install stockfish`) yoki eng so'nggi versiya uchun Termuxda
`bash scripts/build_stockfish.sh`; yo'lni `.env` dagi `STOCKFISH_PATH` ga yozing.

## 2. Telegram tomonida (BotFather)
- `/newbot` — token. `/setinline` — inline rejim (placeholder yozing). `/setinlinefeedback` — **Enabled** (xabar o'zi yangilanishi uchun).
- `/newapp` — Mini App qisqa nomi (faqat **doimiy HTTPS manzil** bo'lsa), `.env` ga `APP_SHORT_NAME=...`.
- Bot majburiy kanalda **admin** bo'lishi shart (kanallar `/admin` → 📢 Majburiy kanallar).
- Bot haqida matnlar: `/setabouttext`, `/setdescription`.

## 3. Imkoniyatlar
Shaxmat (tezkor/do'st/kompyuter, 10 daraja, yurishni qaytarish), shashka beta (rus shashkasi, do'st bilan), Elo, haftalik va umumiy reyting
(top 10 ga ⭐ va oltin ism), profil, nishonlar, o'yindan keyin tahlil, inline taklif (@bot), majburiy obuna, admin panel (`/admin`), 3 til.

## 4. Fayllar
| Fayl | Vazifasi |
|---|---|
| `main.py` | kirish nuqtasi: veb-server, bot, Stockfish, tunnel |
| `hub.py` | WebSocket, matchmaking, takliflar, partiyalar, natijalar |
| `game.py`, `checkers.py` | shaxmat va shashka qoidalari, soat, durang, uzilish muddatlari |
| `engine.py`, `analysis.py` | Stockfish havzasi (10 daraja), o'yindan keyingi tahlil |
| `api.py`, `db.py`, `rating.py`, `tgauth.py`, `config.py` | REST, SQLite, Elo/hafta/nishonlar, initData tekshiruvi, sozlamalar |
| `botapi.py` | Telegram bot (kontakt orqali ro'yxatdan o'tish) |
| `admin.py` | admin panel (/admin) |
| `subscribe.py` | majburiy obuna (avtomatik tekshirish) |
| `inline.py` | inline taklif (@bot) |
| `webapp/` | Mini App (build kerak emas) |

`admin.py`, `checkers.py`, `subscribe.py`, `inline.py` ichidagi `--patch` ilgaklari bu versiyada **allaqachon qo'llangan**; ularni qayta ishga tushirish shart emas.

## 5. Muhim qoidalar
- Elo K=32, boshlang'ich 1200. Faqat tasodifiy raqib o'yinlari reytingli (`FRIEND_GAMES_RATED=1` bilan do'st o'yinlari ham).
- Hafta: dushanba 00:00 → dushanba, GMT+5; haftalik jadval g'alabalar soni bo'yicha.
- Ulanish uzilsa: vaqtning 20% (kamida 10 s), ∞ o'yinda 3.5 daqiqa → avto-mag'lubiyat.
- Quick-tunnel manzili har ishga tushganda o'zgaradi; doimiy manzil uchun named tunnel / o'z domeningiz (`WEBAPP_URL`).
- Telegramsiz sinash: `.env` da `DEV_MODE=1`, `DISABLE_BOT=1`, brauzerda `http://localhost:8080/?dev=1&name=Ali` (ishlab chiqarishda DEV_MODE=0!).
