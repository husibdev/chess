#!/usr/bin/env python3
"""ISHGA TUSHIRISH:  python main.py   — barcha narsa (veb-server, bot, Stockfish, tunnel) shu yerdan boshlanadi."""
import asyncio
import logging
import re
import shutil
import sys
import time

import aiohttp
from aiohttp import web

import admin
import api
import config
import subscribe
import db
from botapi import Bot
from engine import EnginePool
from hub import Hub

if sys.version_info < (3, 10):
    sys.exit("Python 3.10 yoki yangiroq kerak (tavsiya: 3.10.11)")

log = logging.getLogger("main")
BUILD = str(int(time.time()))


@web.middleware
async def headers_mw(request, handler):
    resp = await handler(request)
    p = request.path
    if p.startswith(("/js/", "/css/")):
        resp.headers["Cache-Control"] = "no-cache"
    elif p.startswith("/img/"):
        resp.headers["Cache-Control"] = "public, max-age=86400"
    elif p == "/" or p.startswith("/api/"):
        resp.headers["Cache-Control"] = "no-store"
    return resp


async def start_tunnel(port):
    exe = shutil.which("cloudflared")
    if not exe:
        return None, None
    proc = await asyncio.create_subprocess_exec(exe, "tunnel", "--url", f"http://127.0.0.1:{port}", "--no-autoupdate",
                                                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT)
    fut = asyncio.get_event_loop().create_future()

    async def pump():
        while True:
            line = await proc.stdout.readline()
            if not line:
                break
            m = re.search(r"https://(?!api\.)[-a-z0-9]+\.trycloudflare\.com", line.decode(errors="ignore"))
            if m and not fut.done():
                fut.set_result(m.group(0))

    asyncio.ensure_future(pump())
    try:
        return await asyncio.wait_for(fut, 60), proc
    except asyncio.TimeoutError:
        log.error("cloudflared URL bermadi")
        return None, proc


async def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    if not config.BOT_TOKEN and not config.DEV_MODE:
        print("XATO: .env faylida BOT_TOKEN yo'q. .env.example dan nusxa oling.")
        sys.exit(1)
    db.init()
    engine = EnginePool()
    await engine.start()
    session = aiohttp.ClientSession()
    bot = None
    username = ""
    if config.BOT_TOKEN and not config.DISABLE_BOT:
        bot = Bot(session)
        await bot.setup()
        username = bot.username
    hub = Hub(engine, {"username": username})
    hub.restore()
    if bot:
        admin.init(bot, hub)
        subscribe.init(bot, hub)

    index_html = (config.WEBAPP_DIR / "index.html").read_text(encoding="utf-8").replace("__V__", BUILD)

    async def index(request):
        return web.Response(text=index_html, content_type="text/html")

    app = web.Application(middlewares=[headers_mw])
    app.router.add_get("/", index)
    app.router.add_get("/ws", hub.handle_ws)
    app.add_routes(api.make_routes(hub))
    for d in ("js", "css", "img"):
        if (config.WEBAPP_DIR / d).is_dir():
            app.router.add_static(f"/{d}", config.WEBAPP_DIR / d)
    runner = web.AppRunner(app)
    await runner.setup()
    await web.TCPSite(runner, config.HOST, config.PORT).start()
    log.info("Server: http://127.0.0.1:%d", config.PORT)

    tunnel = None
    if bot and not config.WEBAPP_URL and not config.DISABLE_TUNNEL:
        url, tunnel = await start_tunnel(config.PORT)
        if url:
            bot.webapp_url = url
            await bot.set_menu()
    if bot:
        log.info("Mini App URL: %s", bot.webapp_url or "(YO'Q — .env da WEBAPP_URL ni yozing yoki cloudflared o'rnating)")
        log.info("Bot: @%s", bot.username)
    tasks = [asyncio.ensure_future(hub.ticker())]
    if bot:
        tasks.append(asyncio.ensure_future(bot.poll()))
    try:
        await asyncio.Event().wait()
    finally:
        for t in tasks:
            t.cancel()
        if tunnel and tunnel.returncode is None:
            tunnel.terminate()
        await engine.stop()
        await session.close()
        await runner.cleanup()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
