#!/usr/bin/env python3
"""Inline rejim: istalgan chatda @OnlineChessrobot yozib, do'st bilan o'yin boshlash (shaxmat 10+0 / shashka 10+0).
Havola imzolangan va bir martalik, 30 daqiqa amal qiladi. O'yin boshlanganda va tugaganda xabar o'zi yangilanadi.
O'rnatish: shu faylni loyiha papkasiga qo'ying, bir marta:  python inline.py --patch   (BotFather sozlamalari README ostida)"""
import asyncio
import hashlib
import hmac
import random
import secrets
import sys
import time

import aiohttp

import admin
import config
import db
import subscribe

B = None                      # botapi.Bot (setup() da o'rnatiladi)
TTL = 1800
USED, MSG, GAME_MSG = {}, {}, {}
SECRET = hashlib.sha256(("inline:" + config.BOT_TOKEN).encode()).digest()
ICON = {"c": "♟", "k": "🔴"}

T = {
    "uz": {"c": "shaxmat", "k": "shashka", "tc": "10+0", "title": "{i} {g} · 10+0", "desc": "Doʻst bilan oʻynash — tanlang va chatga yuboring",
           "inv": "{i} {n} sizni {g} oʻyiniga taklif qilmoqda (10+0).\nQoʻshilish uchun tugmani bosing.", "join": "🤝 Qoʻshilish",
           "start": "{i} {a} vs {b} — oʻyin boshlandi", "win": "🏆 {n} gʻalaba qozondi", "draw": "🤝 Durang", "abort": "⛔ Bekor qilindi",
           "btn": "Avval botga kiring", "joined": "🤝 Doʻstingiz oʻyinga qoʻshildi! Oʻyinni ochish uchun tugmani bosing.", "play": "♟ Oʻynash"},
    "ru": {"c": "шахматы", "k": "шашки", "tc": "10+0", "title": "{i} {g} · 10+0", "desc": "Игра с другом — выберите и отправьте в чат",
           "inv": "{i} {n} приглашает вас сыграть в {g} (10+0).\nНажмите кнопку, чтобы присоединиться.", "join": "🤝 Присоединиться",
           "start": "{i} {a} vs {b} — партия началась", "win": "🏆 Победил {n}", "draw": "🤝 Ничья", "abort": "⛔ Партия отменена",
           "btn": "Сначала зайдите в бота", "joined": "🤝 Ваш друг присоединился! Нажмите кнопку, чтобы открыть игру.", "play": "♟ Играть"},
    "en": {"c": "chess", "k": "checkers", "tc": "10+0", "title": "{i} {g} · 10+0", "desc": "Play with a friend — pick and send to the chat",
           "inv": "{i} {n} invites you to play {g} (10+0).\nTap the button to join.", "join": "🤝 Join",
           "start": "{i} {a} vs {b} — game started", "win": "🏆 {n} won", "draw": "🤝 Draw", "abort": "⛔ Game aborted",
           "btn": "Open the bot first", "joined": "🤝 Your friend joined! Tap the button to open the game.", "play": "♟ Play"},
}


async def api(method, **p):
    try:
        async with B.s.post(B.base + method, json=p, timeout=aiohttp.ClientTimeout(total=30)) as r:
            d = await r.json()
    except Exception as e:  # noqa
        return False, {"description": str(e)}
    return bool(d.get("ok")), d


# ---------------- imzolangan havola ----------------
def _b36(n):
    s = ""
    while True:
        n, r = divmod(n, 36)
        s = "0123456789abcdefghijklmnopqrstuvwxyz"[r] + s
        if not n:
            return s


def _sign(g, uid, ts, nonce):
    return hmac.new(SECRET, f"{g}|{uid}|{ts}|{nonce}".encode(), hashlib.sha256).hexdigest()[:12]


def make(g, uid):
    ts, nonce = int(time.time()), secrets.token_hex(2)
    return f"i{g}_{_b36(uid)}_{_b36(ts)}_{nonce}_{_sign(g, uid, ts, nonce)}"


def parse(token):
    """{'g','uid','ts'} yoki None (noto'g'ri / eskirgan)."""
    try:
        a, u, t, nonce, tag = token.split("_")
        if a not in ("ic", "ik") or len(token) > 64:
            return None
        g, uid, ts = a[1], int(u, 36), int(t, 36)
    except ValueError:
        return None
    if not hmac.compare_digest(_sign(g, uid, ts, nonce), tag) or time.time() - ts > TTL:
        return None
    return {"g": g, "uid": uid, "ts": ts}


def app_link(token=None):
    if config.APP_SHORT_NAME:
        return f"https://t.me/{B.username}/{config.APP_SHORT_NAME}" + (f"?startapp={token}" if token else "")
    return f"https://t.me/{B.username}" + (f"?start={token}" if token else "")


def _clean():
    now = time.time()
    for d in (USED, MSG):
        for k in [k for k, v in d.items() if now - (v if isinstance(v, float) else v["ts"]) > TTL + 60]:
            d.pop(k, None)


# ---------------- Telegram yangilanishlari ----------------
async def handle(bot, upd):
    global B
    iq, ch = upd.get("inline_query"), upd.get("chosen_inline_result")
    if not iq and not ch:
        return False
    B = bot
    if iq:
        await on_query(iq)
    elif ch.get("inline_message_id") and parse(ch.get("result_id", "")):
        _clean()
        MSG[ch["result_id"]] = {"imid": ch["inline_message_id"], "lang": bot.lang(ch["from"]["id"], ch["from"]), "ts": time.time()}
    return True


async def on_query(iq):
    uid, lang = iq["from"]["id"], B.lang(iq["from"]["id"], iq["from"])
    u = db.get_user(uid)
    ok = u and db.is_registered(u) and not u.get("banned") and not admin.S["maint"]
    if ok:
        ok = (await subscribe.check(uid))[0]
    if not ok:
        return await api("answerInlineQuery", inline_query_id=iq["id"], results=[], cache_time=0, is_personal=True,
                         button={"text": T[lang]["btn"], "start_parameter": "inline"})
    t, res = T[lang], []
    for g in ("c", "k"):
        tok = make(g, uid)
        res.append({"type": "article", "id": tok, "title": t["title"].format(i=ICON[g], g=t[g].capitalize()), "description": t["desc"],
                    "input_message_content": {"message_text": t["inv"].format(i=ICON[g], n=db.display_name(u), g=t[g])},
                    "reply_markup": {"inline_keyboard": [[{"text": t["join"], "url": app_link(tok)}]]}})
    await api("answerInlineQuery", inline_query_id=iq["id"], results=res, cache_time=0, is_personal=True)


# ---------------- qo'shilish (hub.dispatch dan chaqiriladi) ----------------
async def join(hub, uid, token):
    fail = lambda code: hub.send_user(uid, {"t": "err", "code": code})
    d = parse(token)
    if not d or token in USED:
        return fail("challenge_gone")
    if d["uid"] == uid:
        return fail("own_challenge")
    owner = db.get_user(d["uid"])
    if not owner or not db.is_registered(owner) or owner.get("banned") or hub.busy_silent(d["uid"]):
        return fail("challenge_gone")
    if hub.busy(uid):
        return
    USED[token] = time.time()
    w, b = (d["uid"], uid) if random.random() < 0.5 else (uid, d["uid"])
    g = hub.new_game("checkers" if d["g"] == "k" else "pvp", w, b, (600, 0), config.FRIEND_GAMES_RATED)
    info = MSG.get(token)
    lang = (info or {}).get("lang") or owner.get("lang") or "en"
    t = T.get(lang, T["en"])
    if info and B:
        GAME_MSG[g.id] = {**info, "g": d["g"]}
        asyncio.ensure_future(api("editMessageText", inline_message_id=info["imid"], reply_markup={"inline_keyboard": []},
                                  text=t["start"].format(i=ICON[d["g"]], a=db.display_name(db.get_user(w)), b=db.display_name(db.get_user(b)))))
    if B and not hub.conns.get(d["uid"]):
        asyncio.ensure_future(B.play_button(d["uid"], lang, t["joined"]))


def on_finish(g):
    info = GAME_MSG.pop(g.id, None)
    if info and B:
        asyncio.ensure_future(_finish(g, info))


async def _finish(g, info):
    t = T.get(info["lang"], T["en"])
    a, b = db.display_name(db.get_user(g.white)), db.display_name(db.get_user(g.black))
    if g.result is None:
        line = t["abort"]
    elif g.result == "1/2-1/2":
        line = t["draw"]
    else:
        line = t["win"].format(n=a if g.result == "1-0" else b)
    await api("editMessageText", inline_message_id=info["imid"], text=f"{ICON[info['g']]} {a} vs {b}\n{line}",
              reply_markup={"inline_keyboard": [[{"text": t["play"], "url": app_link()}]]})


# ---------------- ilgaklar: python inline.py --patch ----------------
PATCHES = [
    ("hub.py", 'log = logging.getLogger("hub")\n', 'import inline\n\nlog = logging.getLogger("hub")\n'),
    ("hub.py", '        if t == "bot_start":\n            return await self.bot_start(uid, m)\n',
     '        if t == "inline_join":\n            return await inline.join(self, uid, str(m.get("token", "")))\n        if t == "bot_start":\n            return await self.bot_start(uid, m)\n'),
    ("hub.py", "        self.games.pop(g.id, None)\n", "        self.games.pop(g.id, None)\n        inline.on_finish(g)\n"),
    ("botapi.py", 'log = logging.getLogger("bot")\n', 'import inline\n\nlog = logging.getLogger("bot")\n'),
    ("botapi.py", '        self.username = me["username"]\n', '        self.username = me["username"]\n        inline.B = self\n'),
    ("botapi.py", "        if await admin.handle(upd):\n            return\n", "        if await admin.handle(upd):\n            return\n        if await inline.handle(self, upd):\n            return\n"),
    ("botapi.py", ['"allowed_updates": ["message", "callback_query", "chat_member"]', '"allowed_updates": ["message", "callback_query"]'],
     '"allowed_updates": ["message", "callback_query", "chat_member", "inline_query", "chosen_inline_result"]'),
    ("botapi.py", '''url = self.webapp_url + ("/?ch=" + payload[3:] if payload and payload.startswith("ch_") else "")''',
     '''url = self.webapp_url + ("/?ch=" + payload[3:] if payload and payload.startswith("ch_") else "/?inv=" + payload if payload and payload[:3] in ("ic_", "ik_") else "")'''),
    ("botapi.py", '''label = T[lang]["join"] if payload and payload.startswith("ch_") else T[lang]["play"]''',
     '''label = T[lang]["join"] if payload and payload[:3] in ("ch_", "ic_", "ik_") else T[lang]["play"]'''),
    ("botapi.py", '        if payload and payload.startswith("ch_"):\n', '        if payload and payload[:3] in ("ch_", "ic_", "ik_"):\n'),
    ("admin.py", 'if t in ("queue", "challenge_create", "challenge_join", "bot_start"):', 'if t in ("queue", "challenge_create", "challenge_join", "inline_join", "bot_start"):'),
    ("webapp/js/main.js", '    if (code && code !== joinedCode) { joinedCode = code; net.send({ t: "challenge_join", code }); }\n',
     '    if (code && code !== joinedCode) { joinedCode = code; net.send({ t: "challenge_join", code }); }\n    const inv = new URLSearchParams(location.search).get("inv") || (/^i[ck]_/.test(m.start_param || "") ? m.start_param : null);\n    if (inv && inv !== joinedCode) { joinedCode = inv; net.send({ t: "inline_join", token: inv }); }\n'),
]


def patch():
    base = config.ROOT
    for fn, old, new in PATCHES:
        p = base / fn
        if not p.exists():
            print("YO'Q:", fn)
            continue
        s = p.read_text(encoding="utf-8")
        olds = old if isinstance(old, list) else [old]
        if new in s:
            print("allaqachon:", fn)
            continue
        hit = next((o for o in olds if o in s), None)
        if not hit:
            print("!! TOPILMADI (qo'lda):", fn, repr(olds[0][:55]))
            continue
        bak = p.with_name(p.name + ".bak5")
        if not bak.exists():
            bak.write_text(s, encoding="utf-8")
        p.write_text(s.replace(hit, new, 1), encoding="utf-8")
        print("ok:", fn)
    print("Tayyor. Serverni qayta ishga tushiring.")


if __name__ == "__main__":
    if "--patch" in sys.argv:
        patch()
    else:
        print("Ishlatish: python inline.py --patch")
