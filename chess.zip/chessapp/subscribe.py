#!/usr/bin/env python3
"""Majburiy obuna: bot ichida ham, Mini Appda ham. Avtomatik tekshiradi (qo'lda tugma bosish shart emas).
O'rnatish: shu faylni loyiha papkasiga, subscribe.js ni webapp/js/ ga qo'ying, so'ng bir marta:  python subscribe.py --patch
Kanallar admin paneldan boshqariladi (📢 Majburiy kanallar). Bot kanalda ADMIN bo'lishi shart."""
import asyncio
import json
import sys
import time

import aiohttp

import admin
import config
import db

B = H = None
CH = []                      # [{"id","cid","title","link"}]
S = {"on": 1}
CACHE = {}                   # uid -> (ok, ts, missing)
PENDING = {}                 # uid -> {"m": message, "ts", "sent"}
WARNED = {}
MEMBER = ("creator", "administrator", "member")

T = {
    "en": {"ask": "⚠️ To use the bot, please join our channel below. The bot continues automatically once you subscribe.", "chk": "✅ Check", "done": "✅ Subscription confirmed!", "no": "You haven't subscribed yet"},
    "uz": {"ask": "⚠️ Botdan foydalanish uchun quyidagi kanalga obuna boʻling. Obuna boʻlganingizdan soʻng bot avtomatik davom etadi.", "chk": "✅ Tekshirish", "done": "✅ Obuna tasdiqlandi!", "no": "Hali obuna boʻlmagansiz"},
    "ru": {"ask": "⚠️ Чтобы пользоваться ботом, подпишитесь на канал ниже. После подписки бот продолжит автоматически.", "chk": "✅ Проверить", "done": "✅ Подписка подтверждена!", "no": "Вы ещё не подписались"},
}


async def api(method, **p):
    try:
        async with B.s.post(B.base + method, json=p, timeout=aiohttp.ClientTimeout(total=30)) as r:
            d = await r.json()
    except Exception as e:  # noqa
        return False, {"description": str(e)}
    return bool(d.get("ok")), d


def save():
    db.conn.execute("INSERT OR REPLACE INTO kv VALUES('channels',?)", (json.dumps(CH, ensure_ascii=False),))
    db.conn.execute("INSERT OR REPLACE INTO kv VALUES('sub_on',?)", (str(S["on"]),))


def init(bot, hub):
    global B, H
    B, H = bot, hub
    row = db.conn.execute("SELECT v FROM kv WHERE k='channels'").fetchone()
    CH[:] = json.loads(row[0]) if row else [{"id": "@husib_channel", "cid": None, "title": "@husib_channel", "link": "https://t.me/husib_channel"}]
    r = db.conn.execute("SELECT v FROM kv WHERE k='sub_on'").fetchone()
    S["on"] = int(r[0]) if r else 1
    admin.ROUTES.update(sub=r_sub, suba=r_suba, subd=r_subd, subt=r_subt)
    asyncio.ensure_future(pending_loop())


def public_channels():
    return [{"title": c["title"], "link": c["link"]} for c in CH]


# ---------------- tekshirish ----------------
async def check(uid, force=False):
    """(ok, yetishmayotgan_kanallar). Xato bo'lsa (bot admin emas) — foydalanuvchini bloklamaymiz, adminga xabar beramiz."""
    if not S["on"] or not CH or uid in admin.ADMINS or config.DEV_MODE:
        return True, []
    c = CACHE.get(uid)
    if c and not force and time.time() - c[1] < (600 if c[0] else 3):
        return c[0], c[2]
    missing = []
    for ch in CH:
        ok, d = await api("getChatMember", chat_id=ch["id"], user_id=uid)
        if not ok:
            if time.time() - WARNED.get(ch["id"], 0) > 3600:
                WARNED[ch["id"]] = time.time()
                asyncio.ensure_future(admin.notify(f"⚠️ Kanalni tekshirib boʻlmadi: {admin.esc(ch['title'])}\n{admin.esc(str(d.get('description')))}\nBot kanalda admin ekanini tekshiring."))
            continue
        r = d["result"]
        if not (r["status"] in MEMBER or (r["status"] == "restricted" and r.get("is_member"))):
            missing.append(ch)
    CACHE[uid] = (not missing, time.time(), missing)
    return (not missing), missing


async def ok(uid):
    return (await check(uid))[0]


# ---------------- bot ichida ----------------
async def send_gate(uid, missing, lang):
    t = T[lang]
    rows = [[{"text": "📢 " + c["title"], "url": c["link"]}] for c in missing]
    rows.append([{"text": t["chk"], "callback_data": "sub:chk"}])
    await api("sendMessage", chat_id=uid, text=t["ask"], reply_markup={"inline_keyboard": rows})


async def release(uid, lang):
    p = PENDING.pop(uid, None)
    await api("sendMessage", chat_id=uid, text=T[lang]["done"])
    if p:
        await B.handle({"message": p["m"]})  # to'xtatilgan xabarni (masalan /start ch_KOD) qayta ishga tushiramiz
    else:
        await B.play_button(uid, lang, "♟")


async def handle(bot, upd):
    if not B or not CH or not S["on"]:
        return False
    cm = upd.get("chat_member")
    if cm:
        uid = cm["new_chat_member"]["user"]["id"]
        CACHE.pop(uid, None)
        if cm["new_chat_member"]["status"] in MEMBER and uid in PENDING:
            if (await check(uid, True))[0]:
                await release(uid, bot.lang(uid, cm["new_chat_member"]["user"]))
        return True
    cq = upd.get("callback_query")
    if cq and cq.get("data") == "sub:chk":
        uid = cq["from"]["id"]
        lang = bot.lang(uid, cq["from"])
        good = (await check(uid, True))[0]
        await api("answerCallbackQuery", callback_query_id=cq["id"], text=T[lang]["no"] if not good else "✅", show_alert=not good)
        if good:
            await release(uid, lang)
        return True
    m = upd.get("message")
    if not m or "from" not in m or m["chat"]["id"] != m["from"]["id"]:
        return False
    uid = m["from"]["id"]
    good, missing = await check(uid)
    if good:
        return False
    now = time.time()
    p = PENDING.get(uid)
    if not p or (m.get("text") or "").startswith("/start"):
        PENDING[uid] = p = {"m": m, "ts": now, "sent": p["sent"] if p else 0}
    if now - p["sent"] > 20:
        p["sent"] = now
        await send_gate(uid, missing, bot.lang(uid, m["from"]))
    return True


async def pending_loop():
    """Obuna bo'lganlarni avtomatik topish (chat_member kelmasa ham ishlaydi)."""
    while True:
        await asyncio.sleep(10)
        for uid in list(PENDING):
            try:
                p = PENDING.get(uid)
                if not p or time.time() - p["ts"] > 1800:
                    PENDING.pop(uid, None)
                elif (await check(uid, True))[0]:
                    await release(uid, B.lang(uid, p["m"]["from"]))
            except Exception:  # noqa
                pass


# ---------------- admin paneli ----------------
async def r_sub(ctx, aid):
    rows = [[admin.btn("❌ " + c["title"], f"a:subd:{i}")] for i, c in enumerate(CH)]
    rows += [[admin.btn("➕ Kanal qoʻshish", "a:suba")], [admin.btn(f"Tekshiruv: {'🟢 yoqiq' if S['on'] else '⚪️ oʻchiq'}", "a:subt")], admin.BACK]
    await admin.edit(ctx, "📢 <b>Majburiy kanallar</b>\nBot har bir kanalda <b>admin</b> boʻlishi shart. Adminlar tekshiruvdan ozod.", rows)


async def r_suba(ctx, aid):
    admin.PEND[aid] = {"k": "subadd"}
    await admin.edit(ctx, "Kanal @username yoki ID (-100…) yuboring. /cancel", [[admin.btn("⬅️ Orqaga", "a:sub")]])


async def r_subd(ctx, aid, i):
    if 0 <= int(i) < len(CH):
        CH.pop(int(i))
        save()
    await r_sub(ctx, aid)


async def r_subt(ctx, aid):
    S["on"] ^= 1
    save()
    CACHE.clear()
    await r_sub(ctx, aid)


async def on_admin_text(aid, chat, text):
    admin.PEND.pop(aid, None)
    q = text.strip().replace("https://t.me/", "@").replace("t.me/", "@")
    chat_id = q if q.startswith("@") or q.lstrip("-").isdigit() else "@" + q
    ok_, d = await api("getChat", chat_id=chat_id)
    if not ok_:
        return await admin.say(chat, "❌ Kanal topilmadi: " + admin.esc(str(d.get("description"))), [[admin.btn("⬅️ Orqaga", "a:sub")]])
    c = d["result"]
    _, me = await api("getMe")
    ok2, m = await api("getChatMember", chat_id=c["id"], user_id=me["result"]["id"])
    if not ok2 or m["result"]["status"] not in ("administrator", "creator"):
        return await admin.say(chat, "❌ Bot bu kanalda admin emas. Avval botni kanalga admin qiling.", [[admin.btn("⬅️ Orqaga", "a:sub")]])
    link = ("https://t.me/" + c["username"]) if c.get("username") else (c.get("invite_link") or (await api("exportChatInviteLink", chat_id=c["id"]))[1].get("result"))
    ent = {"id": ("@" + c["username"]) if c.get("username") else str(c["id"]), "cid": c["id"], "title": c.get("title") or q, "link": link}
    CH[:] = [x for x in CH if x.get("cid") != c["id"] and x["id"] != ent["id"]] + [ent]
    save()
    CACHE.clear()
    await admin.say(chat, f"✅ Qoʻshildi: {admin.esc(ent['title'])}", [[admin.btn("📢 Kanallar", "a:sub")]])


# ---------------- ilgaklar: python subscribe.py --patch ----------------
def _i18n(en, uz, ru):
    return [("webapp/js/i18n.js", 'offline:"Reconnecting…",', 'offline:"Reconnecting…", ' + en),
            ("webapp/js/i18n.js", 'offline:"Qayta ulanmoqda…",', 'offline:"Qayta ulanmoqda…", ' + uz),
            ("webapp/js/i18n.js", 'offline:"Переподключение…",', 'offline:"Переподключение…", ' + ru)]


PATCHES = [
    ("hub.py", "import db\nimport rating as R\n", "import db\nimport rating as R\nimport subscribe\n"),
    ("hub.py", '            if hello.get("lang") in ("en", "uz", "ru"):\n',
     '            if not await subscribe.ok(uid):\n                await self._send(ws, {"t": "hello_err", "code": "not_subscribed", "channels": subscribe.public_channels()})\n                return ws\n            if hello.get("lang") in ("en", "uz", "ru"):\n'),
    ("botapi.py", "import admin\nimport config\nimport db\n", "import admin\nimport config\nimport db\nimport subscribe\n"),
    ("botapi.py", "        if await admin.handle(upd):\n            return\n", "        if await admin.handle(upd):\n            return\n        if await subscribe.handle(self, upd):\n            return\n"),
    ("botapi.py", '"allowed_updates": ["message", "callback_query"]', '"allowed_updates": ["message", "callback_query", "chat_member"]'),
    ("main.py", "import api\nimport config\n", "import api\nimport config\nimport subscribe\n"),
    ("main.py", "        admin.init(bot, hub)\n", "        admin.init(bot, hub)\n        subscribe.init(bot, hub)\n"),
    ("admin.py", '[btn("📜 Xatolar", "a:log"), btn("📄 CSV eksport", "a:csv")],', '[btn("📜 Xatolar", "a:log"), btn("📄 CSV eksport", "a:csv")],\n            [btn("📢 Majburiy kanallar", "a:sub")],'),
    ("admin.py", '    k = p["k"]\n    if k == "search":', '    k = p["k"]\n    if k == "subadd":\n        import subscribe\n        return await subscribe.on_admin_text(aid, chat, text)\n    if k == "search":'),
    ("webapp/js/main.js", 'import { openAnalysis } from "./analysis.js";\n', 'import { openAnalysis } from "./analysis.js";\nimport { renderSub } from "./subscribe.js";\n'),
    ("webapp/js/main.js", 'else if (m.code === "banned") showMsg(t("banned"));',
     'else if (m.code === "banned") showMsg(t("banned")); else if (m.code === "not_subscribed") { document.body.classList.add("ingame"); const sc = $("#screen"); sc.className = ""; sc.innerHTML = ""; renderSub(sc, m.channels || []); }'),
    ("webapp/js/main.js", '    if (first) { renderTabs(); showTab("play"); }', '    if (first) { document.body.classList.remove("ingame"); renderTabs(); showTab("play"); }'),
] + _i18n('subTitle:"Subscribe to continue", subText:"To use the game, please join our channel:", subAuto:"The game opens automatically after you subscribe.",',
          'subTitle:"Davom etish uchun obuna boʻling", subText:"Oʻyindan foydalanish uchun kanalimizga obuna boʻling:", subAuto:"Obuna boʻlgach oʻyin avtomatik ochiladi.",',
          'subTitle:"Подпишитесь, чтобы продолжить", subText:"Чтобы пользоваться игрой, подпишитесь на наш канал:", subAuto:"Игра откроется автоматически после подписки.",')


def patch():
    base = config.ROOT
    if not (base / "webapp/js/subscribe.js").exists():
        print("!! webapp/js/subscribe.js yo'q — avval uni shu papkaga qo'ying")
        return
    for fn, old, new in PATCHES:
        p = base / fn
        if not p.exists():
            print("YO'Q:", fn)
            continue
        s = p.read_text(encoding="utf-8")
        if new in s:
            print("allaqachon:", fn)
        elif old not in s:
            print("!! TOPILMADI (qo'lda):", fn, repr(old[:55]))
        else:
            bak = p.with_name(p.name + ".bak4")
            if not bak.exists():
                bak.write_text(s, encoding="utf-8")
            p.write_text(s.replace(old, new, 1), encoding="utf-8")
            print("ok:", fn)
    print("Tayyor. Serverni qayta ishga tushiring.")


if __name__ == "__main__":
    if "--patch" in sys.argv:
        patch()
    else:
        print("Ishlatish: python subscribe.py --patch")
