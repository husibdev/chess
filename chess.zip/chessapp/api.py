"""REST: profil, reyting jadvallari, tarix, tahlil, statik fayllar."""
import asyncio
import logging
import time

from aiohttp import web

import analysis
import config
import db
import rating as R
from tgauth import validate_init_data

log = logging.getLogger("api")


def authed(hub, request):
    init = request.headers.get("X-Init-Data", "")
    if config.DEV_MODE and init.startswith("dev:"):
        d = hub.auth(init)
    else:
        d = validate_init_data(init, config.BOT_TOKEN, config.INITDATA_MAX_AGE)
    if not d:
        raise web.HTTPUnauthorized(text="bad init data")
    u = db.get_user(int(d["user"]["id"]))
    if u and u.get("banned"):
        raise web.HTTPForbidden(text="banned")
    if not db.is_registered(u):
        raise web.HTTPForbidden(text="not registered")
    return u


def make_routes(hub):
    routes = web.RouteTableDef()

    def pub(u, ch):
        return db.public_user(u, ch)

    @routes.get("/api/leaderboard")
    async def leaderboard(request):
        me = authed(hub, request)
        ch = hub.champs()
        kind = request.query.get("kind", "week")
        if kind == "career":
            rows = db.career_board(100)
            items = [{**pub(u, ch), "value": u["rating"], "games": u["rated_games"], "wins": u["wins"], "rank": i + 1}
                     for i, u in enumerate(rows)]
            mine = db.career_rank(me)
            my = {"rank": mine, "value": me["rating"]} if mine else None
            return web.json_response({"kind": kind, "items": items, "me": my})
        start = R.week_start()
        tab = db.week_table(start)
        items = []
        my = None
        for i, (uid, w, d, l, net) in enumerate(tab):
            if i < 100:
                u = db.get_user(uid)
                items.append({**pub(u, ch), "value": w, "net": net, "draws": d, "losses": l, "rank": i + 1})
            if uid == me["id"]:
                my = {"rank": i + 1, "value": w, "net": net}
        return web.json_response({"kind": "week", "items": items, "me": my, "start": start, "end": start + R.WEEK,
                                  "top": config.CHAMPION_COUNT})

    @routes.get("/api/profile")
    async def profile(request):
        me = authed(hub, request)
        q = request.query.get("uid", "me")
        uid = me["id"] if q == "me" else int(q)
        u = db.get_user(uid) if uid != me["id"] else me
        if not u or not db.is_registered(u):
            raise web.HTTPNotFound()
        ch = hub.champs()
        games = u["rated_games"]
        out = {
            "user": pub(u, ch),
            "rank": db.career_rank(u),
            "stats": {k: u[k] for k in ("rated_games", "wins", "draws", "losses", "best_rating", "streak", "best_streak",
                                        "bot_games", "bot_wins", "friend_games")},
            "winrate": round(100 * u["wins"] / games) if games else 0,
            "badges": db.badges_of(uid),
            "history": db.rating_history(uid),
            "self": uid == me["id"],
        }
        if uid == me["id"]:
            out["games"] = [game_row(g, uid) for g in db.user_games(uid, 30, int(request.query.get("offset", 0)))]
        return web.json_response(out)

    def game_row(g, uid):
        white = g["white_id"] == uid
        opp_id = g["black_id"] if white else g["white_id"]
        opp = db.get_user(opp_id) if opp_id else None
        r = g["result"]
        res = "d" if r == "1/2-1/2" else ("w" if (r == "1-0") == white else "l")
        return {"id": g["id"], "kind": g["kind"], "ts": g["ended_at"], "color": "w" if white else "b", "res": res, "reason": g["reason"],
                "tc": [g["tc_base"], g["tc_inc"]], "delta": g["w_delta"] if white else g["b_delta"], "rated": bool(g["rated"]),
                "ply": g["ply"], "bot": config.norm_level(g["bot_level"]) if opp_id is None else None,
                "opp": {"id": opp_id, "name": db.display_name(opp)} if opp else None}

    def must_play(g, me):
        if not g or me["id"] not in (g["white_id"], g["black_id"]):
            raise web.HTTPNotFound()

    @routes.get("/api/game/{gid}")
    async def game(request):
        me = authed(hub, request)
        g = db.get_game(request.match_info["gid"])
        must_play(g, me)
        ch = hub.champs()
        players = {}
        for c, k in (("w", "white_id"), ("b", "black_id")):
            if g[k]:
                players[c] = pub(db.get_user(g[k]), ch)
            else:
                players[c] = {"id": 0, "name": "Stockfish", "bot": True, "level": config.norm_level(g["bot_level"]), "rating": 0, "champ": 0, "photo": ""}
        return web.json_response({"id": g["id"], "moves": g["moves"].split() if g["moves"] else [], "result": g["result"],
                                  "reason": g["reason"], "players": players, "you": "w" if g["white_id"] == me["id"] else "b",
                                  "tc": [g["tc_base"], g["tc_inc"]], "rated": bool(g["rated"])})

    @routes.get("/api/analysis/{gid}")
    async def get_analysis(request):
        me = authed(hub, request)
        gid = request.match_info["gid"]
        g = db.get_game(gid)
        must_play(g, me)
        data = db.analysis_get(gid)
        if data:
            return web.json_response({"status": "done", "data": data})
        job = hub.analysis_jobs.get(gid)
        if job:
            return web.json_response({"status": job["status"], "done": job["done"], "total": job["total"], "pos": job.get("pos", 0)})
        return web.json_response({"status": "none"})

    @routes.post("/api/analysis/{gid}")
    async def start_analysis(request):
        me = authed(hub, request)
        gid = request.match_info["gid"]
        g = db.get_game(gid)
        must_play(g, me)
        if db.analysis_get(gid):
            return web.json_response({"status": "done"})
        if not hub.engine.available:
            return web.json_response({"status": "error", "code": "engine_off"})
        if gid in hub.analysis_jobs and hub.analysis_jobs[gid]["status"] == "running":
            return web.json_response({"status": "running"})
        running = [j for j in hub.analysis_jobs.values() if j["status"] == "running"]
        if len(running) >= config.ANALYSIS_MAX_PENDING:
            return web.json_response({"status": "error", "code": "busy"})
        job = {"status": "running", "done": 0, "total": 0, "ts": time.time()}
        hub.analysis_jobs[gid] = job

        async def go():
            try:
                await analysis.run(hub, g, job)
            except Exception:  # noqa
                log.exception("tahlil xatosi")
                job["status"] = "error"
            await asyncio.sleep(120)
            if hub.analysis_jobs.get(gid) is job:
                hub.analysis_jobs.pop(gid, None)

        hub.spawn(go())
        return web.json_response({"status": "running"})

    return routes
