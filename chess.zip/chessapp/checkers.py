#!/usr/bin/env python3
"""Rus shashkasi (beta): qoidalar + partiya. Faqat do'st bilan, reytingga aloqasi yo'q.
O'rnatish: shu faylni loyiha papkasiga, checkers.js ni webapp/js/ ga qo'ying, so'ng bir marta:  python checkers.py --patch"""
import sys
import time

from game import Game, W, B

FILES = "abcdefgh"
DIRS = ((1, 1), (1, -1), (-1, 1), (-1, -1))


def sqname(i):
    return FILES[i % 8] + str(i // 8 + 1)


def step(i, d):
    f, r = i % 8 + d[0], i // 8 + d[1]
    return f + 8 * r if 0 <= f < 8 and 0 <= r < 8 else -1


class Position:
    """b[i]: 0 boʻsh, 1/2 oq oddiy/dama, -1/-2 qora. i = fayl + 8*qator (a1 = 0, qoʻyuq katak)."""

    def __init__(self):
        self.b = [0] * 64
        for i in range(64):
            if (i % 8 + i // 8) % 2 == 0:
                self.b[i] = 1 if i // 8 < 3 else (-1 if i // 8 > 4 else 0)
        self.turn = True  # True = oq yuradi
        self.quiet = 0
        self.seen = {(tuple(self.b), True): 1}
        self._cache = None

    # ---- yurishlarni yaratish ----
    def _seqs(self, b, pos, king, col, taken):
        out, last = [], (7 if col == 1 else 0)
        for d in DIRS:
            if not king:
                m = step(pos, d)
                if m < 0 or b[m] * col >= 0 or m in taken:
                    continue
                l = step(m, d)
                if l < 0 or b[l] != 0:
                    continue
                sub = self._seqs(b, l, l // 8 == last, col, taken | {m})  # oxirgi qatorga yetgan dona darhol dama boʻladi
                out += [([l] + ls, [m] + cs) for ls, cs in sub] if sub else [([l], [m])]
            else:
                s = step(pos, d)
                while s >= 0 and b[s] == 0:
                    s = step(s, d)
                if s < 0 or b[s] * col >= 0 or s in taken:
                    continue
                lands, t = [], step(s, d)
                while t >= 0 and b[t] == 0:
                    lands.append(t)
                    t = step(t, d)
                if not lands:
                    continue
                cont = [(l, self._seqs(b, l, True, col, taken | {s})) for l in lands]
                cont = [(l, sub) for l, sub in cont if sub]
                if cont:  # davom ettirish mumkin boʻlgan joyga qoʻnish majburiy
                    for l, sub in cont:
                        out += [([l] + ls, [s] + cs) for ls, cs in sub]
                else:
                    out += [([l], [s]) for l in lands]
        return out

    def moves(self):
        """{'c3-d4' | 'c3:e5:g7': (from, [landings], [captured])}"""
        if self._cache is None:
            self._cache = self._gen()
        return self._cache

    def _gen(self):
        col = 1 if self.turn else -1
        caps = {}
        for i in range(64):
            p = self.b[i]
            if p * col > 0:
                b = self.b[:]
                b[i] = 0
                for lands, cs in self._seqs(b, i, abs(p) == 2, col, frozenset()):
                    caps[sqname(i) + ":" + ":".join(sqname(l) for l in lands)] = (i, lands, cs)
        if caps:
            return caps
        out = {}
        for i in range(64):
            p = self.b[i]
            if p * col <= 0:
                continue
            dirs = DIRS if abs(p) == 2 else ((1, col), (-1, col))
            for d in dirs:
                j = step(i, d)
                while j >= 0 and self.b[j] == 0:
                    out[sqname(i) + "-" + sqname(j)] = (i, [j], [])
                    if abs(p) != 2:
                        break
                    j = step(j, d)
        return out

    def apply(self, ps):
        mv = self.moves().get(ps)
        if not mv:
            raise ValueError("illegal")
        i, lands, caps = mv
        col = 1 if self.turn else -1
        p = self.b[i]
        self.quiet = 0 if (caps or abs(p) == 1) else self.quiet + 1
        self.b[i] = 0
        for c in caps:
            self.b[c] = 0
        if any(l // 8 == (7 if col == 1 else 0) for l in lands):
            p = 2 * col
        self.b[lands[-1]] = p
        self.turn = not self.turn
        self._cache = None
        k = (tuple(self.b), self.turn)
        self.seen[k] = self.seen.get(k, 0) + 1

    def outcome(self):
        if not self.moves():
            return ("0-1" if self.turn else "1-0"), "no_moves"
        if self.seen[(tuple(self.b), self.turn)] >= 3:
            return "1/2-1/2", "repetition"
        if self.quiet >= 30:
            return "1/2-1/2", "fifteen"
        return None

    # ---- Game bilan moslik ----
    def fen(self):
        return "".join(".wWbB"[0] if v == 0 else ("w" if v == 1 else "W" if v == 2 else "b" if v == -1 else "B") for v in self.b) + (" w" if self.turn else " b")

    def is_check(self):
        return False

    def can_claim_draw(self):
        return False


class CGame(Game):
    def __init__(self, gid, white, black, base_ms, inc_ms):
        super().__init__(gid, "checkers", white, black, base_ms, inc_ms, False)
        self.board = Position()

    def _flag_result(self, loser):
        return ("0-1" if loser == W else "1-0"), "timeout"

    def legal(self):
        return list(self.board.moves()) if self.status == "active" else []

    def play(self, color, uci, mono=None):
        mono = time.monotonic() if mono is None else mono
        if self.status != "active" or self.board.turn != color:
            raise ValueError("not_your_turn")
        uci = str(uci).strip().lower()
        if uci not in self.board.moves():
            raise ValueError("illegal")
        if self._ticking():
            left = self.clock[color] - (mono - self.turn_started) * 1000.0
            if left <= 0:
                self.clock[color] = 0
                return self._flag_result(color)
            self.clock[color] = int(left) + self.inc_ms
        self.board.apply(uci)
        self.moves.append(uci)
        self.sans.append(uci)
        self.turn_started = mono
        self.can_offer[color] = True
        if self.draw_by is not None and self.draw_by != color:
            self.draw_by = None
        return self.board.outcome()

    @classmethod
    def load(cls, d):
        g = cls(d["id"], d["white"], d["black"], d["base"], d["inc"])
        for u in d["moves"]:
            g.board.apply(u)
            g.moves.append(u)
            g.sans.append(u)
        g.clock = {W: d["cw"], B: d["cb"]}
        g.started_at = d.get("started", g.started_at)
        g.turn_started = time.monotonic()
        return g


# ---------------- ilgaklar: python checkers.py --patch ----------------
def _i18n(en, uz, ru):
    return [("webapp/js/i18n.js", 'offline:"Reconnecting…",', 'offline:"Reconnecting…", ' + en),
            ("webapp/js/i18n.js", 'offline:"Qayta ulanmoqda…",', 'offline:"Qayta ulanmoqda…", ' + uz),
            ("webapp/js/i18n.js", 'offline:"Переподключение…",', 'offline:"Переподключение…", ' + ru)]


PATCHES = [
    ("hub.py", "import db\nimport rating as R\n", "import checkers\nimport db\nimport rating as R\n"),
    ("hub.py", "        g = Game(gid, kind, white, black, tc[0] * 1000, tc[1] * 1000, rated, bot_level)\n",
     "        g = (checkers.CGame(gid, white, black, tc[0] * 1000, tc[1] * 1000) if kind == \"checkers\"\n             else Game(gid, kind, white, black, tc[0] * 1000, tc[1] * 1000, rated, bot_level))\n"),
    ("hub.py", '        if not tc:\n            return self.send_user(uid, {"t": "err", "code": "bad_tc"})\n        self.queue.pop(uid, None)\n',
     '        if not tc or (m.get("game") == "checkers" and tc not in ((600, 0), (0, 0))):\n            return self.send_user(uid, {"t": "err", "code": "bad_tc"})\n        self.queue.pop(uid, None)\n'),
    ("hub.py", '"color": m.get("color", "random"), "ts": time.time()}', '"color": m.get("color", "random"), "ts": time.time(),\n                                 "game": "checkers" if m.get("game") == "checkers" else None}'),
    ("hub.py", 'self.new_game("pvp", w, b, ch["tc"], config.FRIEND_GAMES_RATED)', 'self.new_game(ch.get("game") or "pvp", w, b, ch["tc"], config.FRIEND_GAMES_RATED)'),
    ("hub.py", "                g = Game.load(d)\n", '                g = checkers.CGame.load(d) if d.get("kind") == "checkers" else Game.load(d)\n'),
    ("hub.py", "    def update_stats(self, g, u, score, delta):\n", '    def update_stats(self, g, u, score, delta):\n        if g.kind == "checkers":\n            return\n'),
    ("api.py", 'return {"id": g["id"], "ts": g["ended_at"],', 'return {"id": g["id"], "kind": g["kind"], "ts": g["ended_at"],'),
    ("admin.py", "{one('SELECT COUNT(*) FROM games WHERE ended_at>=? AND result IS NOT NULL', day0)}",
     "{one('SELECT COUNT(*) FROM games WHERE ended_at>=? AND result IS NOT NULL AND kind!=?', day0, 'checkers')}"),
    ("admin.py", "{one('SELECT COUNT(*) FROM games WHERE result IS NOT NULL')}", "{one('SELECT COUNT(*) FROM games WHERE result IS NOT NULL AND kind!=?', 'checkers')}"),
    ("admin.py", 'f"🤖 Stockfish: {esc(eng)}\\n"', 'f"🔴 Shashka oʻyinlari: {one(\'SELECT COUNT(*) FROM games WHERE kind=? AND result IS NOT NULL\', \'checkers\')}\\n"\n            f"🤖 Stockfish: {esc(eng)}\\n"'),
    ("webapp/js/play.js", '      modeBtn(IC.cpu, t("computer"), t("computerSub"), computer)));',
     '      modeBtn(IC.cpu, t("computer"), t("computerSub"), computer),\n      modeBtn(IC.disc, t("checkers"), t("checkersSub"), checkers)));'),
    ("webapp/js/play.js", 'net.send({ t: "challenge_create", tc: tc.get(), color: col.get() });', 'S.chGame = null; net.send({ t: "challenge_create", tc: tc.get(), color: col.get() });'),
    ("webapp/js/play.js", 'encodeURIComponent(t("inviteText"))', 'encodeURIComponent(S.chGame === "checkers" ? t("inviteTextCh") : t("inviteText"))'),
    ("webapp/js/game.js", 'import { S } from "./state.js";\n', 'import { S } from "./state.js";\nimport { openCheckers } from "./checkers.js";\n'),
    ("webapp/js/game.js", "export function openGame(st) {\n  if (!st) return;\n", 'export function openGame(st) {\n  if (!st) return;\n  if (st.kind === "checkers") return openCheckers(st);\n'),
    ("webapp/js/game.js", '  net.on("game", (m) => {\n    if (!m.g) {', '  net.on("game", (m) => {\n    if (m.g && m.g.kind === "checkers") return;\n    if (!m.g) {'),
    ("webapp/js/main.js", 'import { openAnalysis } from "./analysis.js";\n', 'import { openAnalysis } from "./analysis.js";\nimport { bindCheckers, isActiveC } from "./checkers.js";\n'),
    ("webapp/js/main.js", "  if (isActive()) return;\n", "  if (isActive() || isActiveC()) return;\n"),
    ("webapp/js/main.js", "  bindNet();\n", '  bindNet();\n  bindCheckers({ leave: () => showTab("play") });\n'),
    ("webapp/js/lists.js", "onclick: () => g.ply > 0 && g.reason !== \"aborted\" && hooks.analyze(g.id)", 'onclick: () => g.kind !== "checkers" && g.ply > 0 && g.reason !== "aborted" && hooks.analyze(g.id)'),
    ("webapp/js/lists.js", 'h("b", {}, opp)', 'h("b", {}, (g.kind === "checkers" ? "🔴 " : "") + opp)'),
] + _i18n('checkers:"Play checkers (beta)", checkersSub:"Russian draughts · with a friend · casual", inviteTextCh:"Let\'s play checkers!", mustCapture:"Capture is mandatory", r_no_moves:"No moves left", r_fifteen:"15-move rule",',
          'checkers:"Shashka (beta)", checkersSub:"Rus shashkasi · doʻst bilan · reytingsiz", inviteTextCh:"Keling, shashka oʻynaymiz!", mustCapture:"Olish majburiy", r_no_moves:"Yurish qolmadi", r_fifteen:"15 yurish qoidasi",',
          'checkers:"Шашки (бета)", checkersSub:"Русские шашки · с другом · без рейтинга", inviteTextCh:"Давай сыграем в шашки!", mustCapture:"Бить обязательно", r_no_moves:"Нет ходов", r_fifteen:"Правило 15 ходов",')

PLAY_EXTRA = '''

IC.disc = '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="4.5"/></svg>';
function checkers() {
  let tcv = { base: 600, inc: 0 };
  const chips = h("div", { class: "chips" }), col = colorSeg();
  const draw = () => { chips.innerHTML = ""; [[{ base: 600, inc: 0 }, "10 " + t("min")], [{ base: 0, inc: 0 }, "∞"]].forEach(([v, l]) => chips.append(h("button", { class: "chip" + (tcv.base === v.base ? " on" : ""), onclick: () => { tcv = v; draw(); } }, l))); };
  draw();
  const body = h("div", { class: "stack" }, h("h2", {}, t("checkers")), h("div", { class: "sub" }, t("checkersSub")), h("div", { class: "sub" }, t("time")), chips, h("div", { class: "sub" }, t("color")), col.el);
  const s = sheet(body);
  body.append(h("button", { class: "btn block", onclick: () => { s.close(); S.chGame = "checkers"; net.send({ t: "challenge_create", tc: tcv, color: col.get(), game: "checkers" }); } }, t("start")));
}
'''


def patch():
    import config
    base = config.ROOT
    if not (base / "webapp/js/checkers.js").exists():
        print("!! webapp/js/checkers.js yo'q — avval uni shu papkaga qo'ying")
        return
    for fn, old, new in PATCHES:
        p = base / fn
        if not p.exists():
            print("YO'Q:", fn)
            continue
        s = p.read_text(encoding="utf-8")
        if new in s:
            print("allaqachon:", fn)
        elif old not in s:
            print("!! TOPILMADI (qo'lda):", fn, repr(old[:55]))
        else:
            bak = p.with_name(p.name + ".bak3")
            if not bak.exists():
                bak.write_text(s, encoding="utf-8")
            p.write_text(s.replace(old, new, 1), encoding="utf-8")
            print("ok:", fn)
    p = base / "webapp/js/play.js"
    s = p.read_text(encoding="utf-8")
    if "function checkers()" not in s:
        p.write_text(s + PLAY_EXTRA, encoding="utf-8")
        print("ok: webapp/js/play.js (checkers oynasi)")
    print("Tayyor. Serverni qayta ishga tushiring.")


if __name__ == "__main__":
    if "--patch" in sys.argv:
        patch()
    else:
        print("Ishlatish: python checkers.py --patch")
