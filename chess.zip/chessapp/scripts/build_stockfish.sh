#!/data/data/com.termux/files/usr/bin/bash
# Stockfishning ENG SO'NGGI rasmiy relizini manbadan quradi (pkg dagi versiya eski bo'lsa).
# Ishlatish:  bash scripts/build_stockfish.sh      (internet kerak, 10-30 daqiqa olishi mumkin)
set -e
pkg install -y git make clang curl wget
TAG=$(curl -s https://api.github.com/repos/official-stockfish/Stockfish/releases/latest | grep -m1 '"tag_name"' | cut -d'"' -f4)
TAG=${TAG:-sf_18}
echo "Reliz: $TAG"
cd "$HOME"; rm -rf Stockfish
git clone --depth 1 --branch "$TAG" https://github.com/official-stockfish/Stockfish.git
cd Stockfish/src
ARCH=armv8
grep -q asimddp /proc/cpuinfo && ARCH=armv8-dotprod
make -j"$(nproc)" net || true
make -j"$(nproc)" build ARCH=$ARCH COMP=clang
mkdir -p "$HOME/bin"; cp stockfish "$HOME/bin/stockfish-latest"
echo
echo "Tayyor. .env ga yozing:  STOCKFISH_PATH=$HOME/bin/stockfish-latest"
"$HOME/bin/stockfish-latest" <<< "uci" | grep -m1 "id name"
