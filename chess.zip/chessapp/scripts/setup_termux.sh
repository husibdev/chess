#!/data/data/com.termux/files/usr/bin/bash
# Termux uchun bir martalik o'rnatish:  bash scripts/setup_termux.sh
set -e
cd "$(dirname "$0")/.."
pkg update -y
pkg install -y python clang make git curl unzip tmux cloudflared stockfish || pkg install -y python clang make git curl unzip tmux stockfish
# aiohttp C-kengaytmalarsiz (Termuxda kompilyatsiya muammolarini oldini oladi)
export AIOHTTP_NO_EXTENSIONS=1 MULTIDICT_NO_EXTENSIONS=1 YARL_NO_EXTENSIONS=1 FROZENLIST_NO_EXTENSIONS=1 PROPCACHE_NO_EXTENSIONS=1
pip install -r requirements.txt
[ -f .env ] || cp .env.example .env
echo
echo "Stockfish: $(command -v stockfish || echo 'TOPILMADI')"
echo "Keyingi qadam: nano .env  (BOT_TOKEN ni yozing), so'ng:  bash run.sh"
