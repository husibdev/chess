"""O'yindan keyingi tahlil: har bir pozitsiyani Stockfish bilan baholab, yurishlarni tasniflaydi."""
import math
import time

import chess

import config
import db

CLAMP = 1000


def win_pct(cp):
    cp = max(-CLAMP, min(CLAMP, cp))
    return 50 + 50 * (2 / (1 + math.exp(-0.00368208 * cp)) - 1)


def judge(loss):
    """loss: yurgan tomon uchun yutish ehtimoli yo'qotilishi (0..100)."""
    if loss >= 15:
        return "blunder"
    if loss >= 10:
        return "mistake"
    if loss >= 5:
        return "inaccuracy"
    return ""


def classify(evals, bests, moves):
    """evals: har pozitsiya uchun oq nuqtai nazaridan cp (len = len(moves)+1). Qaytaradi: judg, acc, counts."""
    judg, accs = [], {"w": [], "b": []}
    counts = {"w": {"best": 0, "inaccuracy": 0, "mistake": 0, "blunder": 0}, "b": {"best": 0, "inaccuracy": 0, "mistake": 0, "blunder": 0}}
    for i, uci in enumerate(moves):
        side = "w" if i % 2 == 0 else "b"
        a, b = win_pct(evals[i]), win_pct(evals[i + 1])
        if side == "b":
            a, b = 100 - a, 100 - b
        loss = max(0.0, a - b)
        j = judge(loss)
        if bests[i] == uci:
            counts[side]["best"] += 1
            j = j if j else "best"
            if j == "best":
                pass
        if j in counts[side] and j != "best":
            counts[side][j] += 1
        judg.append(j)
        acc = 103.1668 * math.exp(-0.04354 * loss) - 3.1668
        accs[side].append(max(0.0, min(100.0, acc)))
    acc = {k: (round(sum(v) / len(v), 1) if v else None) for k, v in accs.items()}
    return judg, acc, counts


async def run(hub, game_row, job):
    gid = game_row["id"]
    moves = game_row["moves"].split() if game_row["moves"] else []
    moves = moves[:300]
    board = chess.Board()
    positions = [board.copy()]
    fens = [board.fen()]
    for u in moves:
        board.push(chess.Move.from_uci(u))
        positions.append(board.copy())
        fens.append(board.fen())
    job["total"] = len(positions)
    evals, bests, mates = [], [], []
    for i, pos in enumerate(positions):
        job["done"] = i
        if pos.is_checkmate():
            evals.append(-CLAMP * 10 if pos.turn == chess.WHITE else CLAMP * 10)
            mates.append(0)
            bests.append("")
            continue
        if pos.is_game_over(claim_draw=False):
            evals.append(0)
            mates.append(None)
            bests.append("")
            continue
        info = await hub.engine.analyse(pos, gid + "a", config.ANALYSIS_MS)
        sc = info["score"].white()
        evals.append(sc.score(mate_score=10000))
        m = sc.mate()
        mates.append(m)
        pv = info.get("pv") or []
        bests.append(pv[0].uci() if pv else "")
    judg, acc, counts = classify(evals, bests, moves)
    data = {"fens": fens, "moves": moves, "sans": san_list(moves), "evals": evals, "mates": mates, "best": bests,
            "judg": judg, "acc": acc, "counts": counts, "engine": hub.engine.name, "ms": config.ANALYSIS_MS}
    db.analysis_put(gid, data)
    job["done"] = len(positions)
    job["status"] = "done"
    return data


def san_list(moves):
    b = chess.Board()
    out = []
    for u in moves:
        mv = chess.Move.from_uci(u)
        out.append(b.san(mv))
        b.push(mv)
    return out
